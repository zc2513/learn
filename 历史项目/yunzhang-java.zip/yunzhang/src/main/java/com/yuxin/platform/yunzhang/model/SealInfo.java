package com.yuxin.platform.yunzhang.model;

import com.fasterxml.jackson.annotation.JsonFormat;

import java.util.Date;
import javax.persistence.*;

@Table(name = "seal_info")
public class SealInfo {
    /**
     * 主键id
     */
    @Id
    private String id;

    /**
     * 印章编码
     */
    private String code;

    /**
     * 印章名称
     */
    private String name;

    /**
     * 序列号
     */
    private String serizlizable;

    /**
     * 企业编码
     */
    private String qybm;

    /**
     * 添加人
     */
    private String adduser;

    /**
     * 添加人名称
     */
    @Column(name = "adduser_name")
    private String adduserName;

    /**
     * 添加时间
     */
    private Date addtime;


    @javax.persistence.Transient
    private Integer page;

    @javax.persistence.Transient
    private Integer size;

    @javax.persistence.Transient
    private String qymc;

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8", locale = "zh")
    @javax.persistence.Transient
    private Date  startTime;

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8", locale = "zh")
    @javax.persistence.Transient
    private Date  endTime;





    /**
     * 获取主键id
     *
     * @return id - 主键id
     */
    public String getId() {
        return id;
    }

    /**
     * 设置主键id
     *
     * @param id 主键id
     */
    public void setId(String id) {
        this.id = id;
    }

    /**
     * 获取印章编码
     *
     * @return code - 印章编码
     */
    public String getCode() {
        return code;
    }

    /**
     * 设置印章编码
     *
     * @param code 印章编码
     */
    public void setCode(String code) {
        this.code = code;
    }

    /**
     * 获取印章名称
     *
     * @return name - 印章名称
     */
    public String getName() {
        return name;
    }

    /**
     * 设置印章名称
     *
     * @param name 印章名称
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * 获取序列号
     *
     * @return serizlizable - 序列号
     */
    public String getSerizlizable() {
        return serizlizable;
    }

    /**
     * 设置序列号
     *
     * @param serizlizable 序列号
     */
    public void setSerizlizable(String serizlizable) {
        this.serizlizable = serizlizable;
    }

    /**
     * 获取企业编码
     *
     * @return qybm - 企业编码
     */
    public String getQybm() {
        return qybm;
    }

    /**
     * 设置企业编码
     *
     * @param qybm 企业编码
     */
    public void setQybm(String qybm) {
        this.qybm = qybm;
    }

    /**
     * 获取添加人
     *
     * @return adduser - 添加人
     */
    public String getAdduser() {
        return adduser;
    }

    /**
     * 设置添加人
     *
     * @param adduser 添加人
     */
    public void setAdduser(String adduser) {
        this.adduser = adduser;
    }

    /**
     * 获取添加人名称
     *
     * @return adduser_name - 添加人名称
     */
    public String getAdduserName() {
        return adduserName;
    }

    /**
     * 设置添加人名称
     *
     * @param adduserName 添加人名称
     */
    public void setAdduserName(String adduserName) {
        this.adduserName = adduserName;
    }

    /**
     * 获取添加时间
     *
     * @return addtime - 添加时间
     */
    public Date getAddtime() {
        return addtime;
    }

    /**
     * 设置添加时间
     *
     * @param addtime 添加时间
     */
    public void setAddtime(Date addtime) {
        this.addtime = addtime;
    }

    public Integer getPage() {
        return page;
    }

    public void setPage(Integer page) {
        this.page = page;
    }

    public Integer getSize() {
        return size;
    }

    public void setSize(Integer size) {
        this.size = size;
    }

    public String getQymc() {
        return qymc;
    }

    public void setQymc(String qymc) {
        this.qymc = qymc;
    }

    public Date getStartTime() {
        return startTime;
    }

    public void setStartTime(Date startTime) {
        this.startTime = startTime;
    }

    public Date getEndTime() {
        return endTime;
    }

    public void setEndTime(Date endTime) {
        this.endTime = endTime;
    }
}