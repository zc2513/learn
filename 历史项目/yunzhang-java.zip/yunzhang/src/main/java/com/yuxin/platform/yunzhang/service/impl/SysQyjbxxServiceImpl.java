package com.yuxin.platform.yunzhang.service.impl;

import com.yuxin.platform.yunzhang.mapper.SysQyjbxxMapper;
import com.yuxin.platform.yunzhang.model.SysQyjbxx;
import com.yuxin.platform.yunzhang.service.SysQyjbxxService;
import com.yuxin.platform.common.core.AbstractService;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;


/**
 * Created by jyh on 2019/05/06.
 */
@Service
@Transactional
public class SysQyjbxxServiceImpl extends AbstractService<SysQyjbxx> implements SysQyjbxxService {

    @Resource
    private SysQyjbxxMapper sysQyjbxxMapper;

}
