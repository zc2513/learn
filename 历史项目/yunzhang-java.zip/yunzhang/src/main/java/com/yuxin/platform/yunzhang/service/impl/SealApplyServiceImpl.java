package com.yuxin.platform.yunzhang.service.impl;

import com.yuxin.platform.yunzhang.mapper.SealApplyMapper;
import com.yuxin.platform.yunzhang.model.SealApply;
import com.yuxin.platform.yunzhang.service.SealApplyService;
import com.yuxin.platform.common.core.AbstractService;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;


/**
 * Created by jyh on 2019/05/06.
 */
@Service
@Transactional
public class SealApplyServiceImpl extends AbstractService<SealApply> implements SealApplyService {

    @Resource
    private SealApplyMapper sealApplyMapper;

}
