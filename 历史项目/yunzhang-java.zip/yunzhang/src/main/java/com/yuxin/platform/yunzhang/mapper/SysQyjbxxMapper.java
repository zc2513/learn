package com.yuxin.platform.yunzhang.mapper;

import com.yuxin.platform.common.core.Mapper;
import com.yuxin.platform.yunzhang.model.SysQyjbxx;

public interface SysQyjbxxMapper extends Mapper<SysQyjbxx> {
}