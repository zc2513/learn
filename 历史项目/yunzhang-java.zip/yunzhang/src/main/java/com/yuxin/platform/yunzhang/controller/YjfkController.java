package com.yuxin.platform.yunzhang.controller;
import com.yuxin.platform.common.core.Result;;
import com.yuxin.platform.common.core.ResultGenerator;
import com.yuxin.platform.yunzhang.model.Yjfk;
import com.yuxin.platform.yunzhang.service.YjfkService;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import org.springframework.web.bind.annotation.*;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import javax.annotation.Resource;
import java.util.List;

/**
* Created by jyh on 2019/05/06.
*/
@Api(value = "Yjfk", description = " ")
@RestController
@RequestMapping("/yjfk")
public class YjfkController {
    @Resource
    private YjfkService yjfkService;

    @ApiOperation(value = "", notes = "")
    @PostMapping("/add")
    public Result add(@RequestBody  @ApiParam(name = "") Yjfk yjfk) {
        yjfkService.save(yjfk);
        return ResultGenerator.genSuccessResult();
    }

    @ApiOperation(value = "", notes = "")
    @PostMapping("/delete")
    public Result delete(@RequestParam String id) {
        yjfkService.deleteById(id);
        return ResultGenerator.genSuccessResult();
    }

    @ApiOperation(value = "", notes = "")
    @PostMapping("/update")
    public Result update(@RequestBody  @ApiParam(name = "") Yjfk yjfk) {
        yjfkService.update(yjfk);
        return ResultGenerator.genSuccessResult();
    }

    @ApiOperation(value = "", notes = "")
    @PostMapping("/detail")
    public Result detail(@RequestParam String id) {
        Yjfk yjfk = yjfkService.findById(id);
        return ResultGenerator.genSuccessResult(yjfk);
    }

    @ApiOperation(value = "", notes = "")
    @PostMapping("/list")
    public Result list(@RequestParam(defaultValue = "0") Integer page, @RequestParam(defaultValue = "0") Integer size) {
        PageHelper.startPage(page, size);
        List<Yjfk> list = yjfkService.findAll();
        PageInfo pageInfo = new PageInfo(list);
        return ResultGenerator.genSuccessResult(pageInfo);
    }
}
