package com.yuxin.platform.yunzhang.schedul;

import com.alibaba.fastjson.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

/**
 * @author jyh
 * @create 2019-06-28-10:02
 */
@Component
public class GetAccessTokenSdu {

    public static String ACCESS_TOKEN;

    @Autowired
    private RestTemplate restTemplate;

    @Scheduled(fixedRate = 2*60*60*1000)
    public void getAccess_token() {
        //获取access_token
        String url = "https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential" +
                "&appid=wx324a18ae9c10f63b"  + "&secret=3bcace0ab88c31f667b2d0e6a711255b";
        if(restTemplate==null){
            restTemplate = new RestTemplate();
        }
        String json = restTemplate.getForObject(url, String.class);
        System.out.println(json);
        JSONObject myJson = JSONObject.parseObject(json);
        ACCESS_TOKEN= myJson.get("access_token").toString();
    }
}
