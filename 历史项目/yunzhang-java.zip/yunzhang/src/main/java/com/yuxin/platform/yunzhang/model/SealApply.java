package com.yuxin.platform.yunzhang.model;

import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModelProperty;

import java.beans.Transient;
import java.util.Date;
import javax.persistence.*;

@Table(name = "seal_apply")
public class SealApply {
    /**
     * 主键id
     */
    @Id
    private String id;

    /**
     * 申请人
     */
    @ApiModelProperty(value="申请人userid")
    @Column(name = "apply_user")
    private String applyUser;

    /**
     * 申请人
     */
    @ApiModelProperty(value="申请人名称")
    @Column(name = "apply_user_name")
    private String applyUserName;

    /**
     * 申请事由
     */
    @ApiModelProperty(value="申请事由")
    @Column(name = "apply_option")
    private String applyOption;

    /**
     * 申请时间
     */
    @ApiModelProperty(value="申请时间")
    @Column(name = "apply_time")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8", locale = "zh")
    private Date applyTime;

    /**
     * 申请用章次数
     */
    @ApiModelProperty(value="申请用章次数")
    private Integer count;

    /**
     * 印章编码
     */
    @ApiModelProperty(value="印章编码")
    private String sealcode;

    /**
     * 有效时间
     */
    @ApiModelProperty(value="有效时间")
    @Column(name = "effective_time")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8", locale = "zh")
    private Date effectiveTime;

    /**
     * 审批人
     */
    @ApiModelProperty(value="审批人")
    private String approver;

    /**
     * 申请人
     */
    @ApiModelProperty(value="审批人")
    @Column(name = "approver_name")
    private String approverName;

    /**
     * 审批时间
     */
    @ApiModelProperty(value="审批时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8", locale = "zh")
    @Column(name = "approver_time")
    private Date approverTime;

    /**
     * 审批意见
     */
    @ApiModelProperty(value="审批意见")
    @Column(name = "approver_opinion")
    private String approverOpinion;

    /**
     * 状态
     */
    @ApiModelProperty(value="状态")
    private Integer status;

    /**
     * 已盖章次数
     */
    @ApiModelProperty(value="已盖章次数")
    private Integer ygzcs;

    /**
     * 盖章前文件图片
     */
    @ApiModelProperty(value="盖章前文件图片")
    private String gzqpic;

    /**
     * 盖章后文件图片
     */
    @ApiModelProperty(value="盖章后文件图片")
    private String gzhpic;

    /**
     * 企业编码
     */
    @ApiModelProperty(value="企业编码")
    private String qybm;

    @javax.persistence.Transient
    private Integer page;

    @javax.persistence.Transient
    private Integer size;

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8", locale = "zh")
    @javax.persistence.Transient
    private Date  startTime;

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8", locale = "zh")
    @javax.persistence.Transient
    private Date  endTime;

    @javax.persistence.Transient
    private String openid;

    @javax.persistence.Transient
    private String sealname;

    @javax.persistence.Transient
    private String formId;





    /**
     * 获取主键id
     *
     * @return id - 主键id
     */
    public String getId() {
        return id;
    }

    /**
     * 设置主键id
     *
     * @param id 主键id
     */
    public void setId(String id) {
        this.id = id;
    }

    /**
     * 获取申请人
     *
     * @return apply_user - 申请人
     */
    public String getApplyUser() {
        return applyUser;
    }

    /**
     * 设置申请人
     *
     * @param applyUser 申请人
     */
    public void setApplyUser(String applyUser) {
        this.applyUser = applyUser;
    }

    /**
     * 获取申请人
     *
     * @return apply_user_name - 申请人
     */
    public String getApplyUserName() {
        return applyUserName;
    }

    /**
     * 设置申请人
     *
     * @param applyUserName 申请人
     */
    public void setApplyUserName(String applyUserName) {
        this.applyUserName = applyUserName;
    }

    /**
     * 获取申请事由
     *
     * @return apply_option - 申请事由
     */
    public String getApplyOption() {
        return applyOption;
    }

    /**
     * 设置申请事由
     *
     * @param applyOption 申请事由
     */
    public void setApplyOption(String applyOption) {
        this.applyOption = applyOption;
    }

    /**
     * 获取申请时间
     *
     * @return apply_time - 申请时间
     */
    public Date getApplyTime() {
        return applyTime;
    }

    /**
     * 设置申请时间
     *
     * @param applyTime 申请时间
     */
    public void setApplyTime(Date applyTime) {
        this.applyTime = applyTime;
    }

    /**
     * 获取申请用章次数
     *
     * @return count - 申请用章次数
     */
    public Integer getCount() {
        return count;
    }

    /**
     * 设置申请用章次数
     *
     * @param count 申请用章次数
     */
    public void setCount(Integer count) {
        this.count = count;
    }

    /**
     * 获取印章编码
     *
     * @return sealcode - 印章编码
     */
    public String getSealcode() {
        return sealcode;
    }

    /**
     * 设置印章编码
     *
     * @param sealcode 印章编码
     */
    public void setSealcode(String sealcode) {
        this.sealcode = sealcode;
    }

    /**
     * 获取有效时间
     *
     * @return effective_time - 有效时间
     */
    public Date getEffectiveTime() {
        return effectiveTime;
    }

    /**
     * 设置有效时间
     *
     * @param effectiveTime 有效时间
     */
    public void setEffectiveTime(Date effectiveTime) {
        this.effectiveTime = effectiveTime;
    }

    /**
     * 获取审批人
     *
     * @return approver - 审批人
     */
    public String getApprover() {
        return approver;
    }

    /**
     * 设置审批人
     *
     * @param approver 审批人
     */
    public void setApprover(String approver) {
        this.approver = approver;
    }

    /**
     * 获取申请人
     *
     * @return approver_name - 申请人
     */
    public String getApproverName() {
        return approverName;
    }

    /**
     * 设置申请人
     *
     * @param approverName 申请人
     */
    public void setApproverName(String approverName) {
        this.approverName = approverName;
    }

    /**
     * 获取审批时间
     *
     * @return approver_time - 审批时间
     */
    public Date getApproverTime() {
        return approverTime;
    }

    /**
     * 设置审批时间
     *
     * @param approverTime 审批时间
     */
    public void setApproverTime(Date approverTime) {
        this.approverTime = approverTime;
    }

    /**
     * 获取审批意见
     *
     * @return approver_opinion - 审批意见
     */
    public String getApproverOpinion() {
        return approverOpinion;
    }

    /**
     * 设置审批意见
     *
     * @param approverOpinion 审批意见
     */
    public void setApproverOpinion(String approverOpinion) {
        this.approverOpinion = approverOpinion;
    }

    /**
     * 获取状态
     *
     * @return status - 状态
     */
    public Integer getStatus() {
        return status;
    }

    /**
     * 设置状态
     *
     * @param status 状态
     */
    public void setStatus(Integer status) {
        this.status = status;
    }

    /**
     * 获取已盖章次数
     *
     * @return ygzcs - 已盖章次数
     */
    public Integer getYgzcs() {
        return ygzcs;
    }

    /**
     * 设置已盖章次数
     *
     * @param ygzcs 已盖章次数
     */
    public void setYgzcs(Integer ygzcs) {
        this.ygzcs = ygzcs;
    }

    /**
     * 获取盖章前文件图片
     *
     * @return gzqpic - 盖章前文件图片
     */
    public String getGzqpic() {
        return gzqpic;
    }

    /**
     * 设置盖章前文件图片
     *
     * @param gzqpic 盖章前文件图片
     */
    public void setGzqpic(String gzqpic) {
        this.gzqpic = gzqpic;
    }

    /**
     * 获取盖章后文件图片
     *
     * @return gzhpic - 盖章后文件图片
     */
    public String getGzhpic() {
        return gzhpic;
    }

    /**
     * 设置盖章后文件图片
     *
     * @param gzhpic 盖章后文件图片
     */
    public void setGzhpic(String gzhpic) {
        this.gzhpic = gzhpic;
    }

    public String getQybm() {
        return qybm;
    }

    public void setQybm(String qybm) {
        this.qybm = qybm;
    }

    public Integer getPage() {
        return page;
    }

    public void setPage(Integer page) {
        this.page = page;
    }

    public Integer getSize() {
        return size;
    }

    public void setSize(Integer size) {
        this.size = size;
    }

    public Date getStartTime() {
        return startTime;
    }

    public void setStartTime(Date startTime) {
        this.startTime = startTime;
    }

    public Date getEndTime() {
        return endTime;
    }

    public void setEndTime(Date endTime) {
        this.endTime = endTime;
    }

    public String getOpenid() {
        return openid;
    }

    public void setOpenid(String openid) {
        this.openid = openid;
    }

    public String getSealname() {
        return sealname;
    }

    public void setSealname(String sealname) {
        this.sealname = sealname;
    }

    public String getFormId() {
        return formId;
    }

    public void setFormId(String formId) {
        this.formId = formId;
    }
}