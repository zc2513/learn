package com.yuxin.platform.yunzhang.service;
import com.yuxin.platform.yunzhang.model.Yjfk;
import com.yuxin.platform.common.core.Service;


/**
 * Created by jyh on 2019/05/06.
 */
public interface YjfkService extends Service<Yjfk> {

}
