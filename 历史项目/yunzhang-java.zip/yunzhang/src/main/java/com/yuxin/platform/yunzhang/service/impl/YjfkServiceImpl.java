package com.yuxin.platform.yunzhang.service.impl;

import com.yuxin.platform.yunzhang.mapper.YjfkMapper;
import com.yuxin.platform.yunzhang.model.Yjfk;
import com.yuxin.platform.yunzhang.service.YjfkService;
import com.yuxin.platform.common.core.AbstractService;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;


/**
 * Created by jyh on 2019/05/06.
 */
@Service
@Transactional
public class YjfkServiceImpl extends AbstractService<Yjfk> implements YjfkService {

    @Resource
    private YjfkMapper yjfkMapper;

}
