package com.yuxin.platform.yunzhang.dto;

/**
 * @author jyh
 * @create 2019-06-26-15:18
 */
public class TemplateDataVo {

    private String value;


    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }
}
