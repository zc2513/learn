package com.yuxin.platform.yunzhang.mapper;

import com.yuxin.platform.common.core.Mapper;
import com.yuxin.platform.yunzhang.model.SealInfo;

import java.util.List;

public interface SealInfoMapper extends Mapper<SealInfo> {


    List<SealInfo>  selectByQybm(SealInfo sealInfo);
}