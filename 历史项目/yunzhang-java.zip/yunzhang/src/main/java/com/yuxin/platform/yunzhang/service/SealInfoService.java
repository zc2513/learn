package com.yuxin.platform.yunzhang.service;
import com.yuxin.platform.yunzhang.model.SealInfo;
import com.yuxin.platform.common.core.Service;


/**
 * Created by jyh on 2019/05/06.
 */
public interface SealInfoService extends Service<SealInfo> {

}
