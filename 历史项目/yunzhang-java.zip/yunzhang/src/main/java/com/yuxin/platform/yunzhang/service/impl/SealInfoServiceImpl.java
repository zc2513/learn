package com.yuxin.platform.yunzhang.service.impl;

import com.yuxin.platform.yunzhang.mapper.SealInfoMapper;
import com.yuxin.platform.yunzhang.model.SealInfo;
import com.yuxin.platform.yunzhang.service.SealInfoService;
import com.yuxin.platform.common.core.AbstractService;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;


/**
 * Created by jyh on 2019/05/06.
 */
@Service
@Transactional
public class SealInfoServiceImpl extends AbstractService<SealInfo> implements SealInfoService {

    @Resource
    private SealInfoMapper sealInfoMapper;

}
