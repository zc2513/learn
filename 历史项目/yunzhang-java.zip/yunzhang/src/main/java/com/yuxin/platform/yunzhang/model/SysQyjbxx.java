package com.yuxin.platform.yunzhang.model;

import java.util.Date;
import javax.persistence.*;

@Table(name = "sys_qyjbxx")
public class SysQyjbxx {
    /**
     * 主键
     */
    @Id
    private String id;

    /**
     * 单位名称
     */
    private String dwmc;

    /**
     * 单位编号
     */
    private String dwbh;

    /**
     * 单位地址
     */
    private String dwdz;

    /**
     * 联系电话
     */
    private String lxdh;

    /**
     * 法定代表人
     */
    private String fddbr;

    /**
     * 法人联系方式
     */
    private String frlxfs;

    /**
     * 统一社会信用代码
     */
    private String tyshxydm;

    /**
     * 营业执照照照片
     */
    private String yyzzzp;

    /**
     * 单位负责人
     */
    private String dwfzr;

    /**
     * 单位负责人联系方式
     */
    private String dwfzrlxfs;

    /**
     * 状态
     */
    private String zt;

    /**
     * 备注
     */
    private String bz;

    /**
     * 登记人
     */
    private String djr;

    /**
     * 登记时间
     */
    private Date djsj;

    /**
     * 获取主键
     *
     * @return id - 主键
     */
    public String getId() {
        return id;
    }

    /**
     * 设置主键
     *
     * @param id 主键
     */
    public void setId(String id) {
        this.id = id;
    }

    /**
     * 获取单位名称
     *
     * @return dwmc - 单位名称
     */
    public String getDwmc() {
        return dwmc;
    }

    /**
     * 设置单位名称
     *
     * @param dwmc 单位名称
     */
    public void setDwmc(String dwmc) {
        this.dwmc = dwmc;
    }

    /**
     * 获取单位编号
     *
     * @return dwbh - 单位编号
     */
    public String getDwbh() {
        return dwbh;
    }

    /**
     * 设置单位编号
     *
     * @param dwbh 单位编号
     */
    public void setDwbh(String dwbh) {
        this.dwbh = dwbh;
    }

    /**
     * 获取单位地址
     *
     * @return dwdz - 单位地址
     */
    public String getDwdz() {
        return dwdz;
    }

    /**
     * 设置单位地址
     *
     * @param dwdz 单位地址
     */
    public void setDwdz(String dwdz) {
        this.dwdz = dwdz;
    }

    /**
     * 获取联系电话
     *
     * @return lxdh - 联系电话
     */
    public String getLxdh() {
        return lxdh;
    }

    /**
     * 设置联系电话
     *
     * @param lxdh 联系电话
     */
    public void setLxdh(String lxdh) {
        this.lxdh = lxdh;
    }

    /**
     * 获取法定代表人
     *
     * @return fddbr - 法定代表人
     */
    public String getFddbr() {
        return fddbr;
    }

    /**
     * 设置法定代表人
     *
     * @param fddbr 法定代表人
     */
    public void setFddbr(String fddbr) {
        this.fddbr = fddbr;
    }

    /**
     * 获取法人联系方式
     *
     * @return frlxfs - 法人联系方式
     */
    public String getFrlxfs() {
        return frlxfs;
    }

    /**
     * 设置法人联系方式
     *
     * @param frlxfs 法人联系方式
     */
    public void setFrlxfs(String frlxfs) {
        this.frlxfs = frlxfs;
    }

    /**
     * 获取统一社会信用代码
     *
     * @return tyshxydm - 统一社会信用代码
     */
    public String getTyshxydm() {
        return tyshxydm;
    }

    /**
     * 设置统一社会信用代码
     *
     * @param tyshxydm 统一社会信用代码
     */
    public void setTyshxydm(String tyshxydm) {
        this.tyshxydm = tyshxydm;
    }

    /**
     * 获取营业执照照照片
     *
     * @return yyzzzp - 营业执照照照片
     */
    public String getYyzzzp() {
        return yyzzzp;
    }

    /**
     * 设置营业执照照照片
     *
     * @param yyzzzp 营业执照照照片
     */
    public void setYyzzzp(String yyzzzp) {
        this.yyzzzp = yyzzzp;
    }

    /**
     * 获取单位负责人
     *
     * @return dwfzr - 单位负责人
     */
    public String getDwfzr() {
        return dwfzr;
    }

    /**
     * 设置单位负责人
     *
     * @param dwfzr 单位负责人
     */
    public void setDwfzr(String dwfzr) {
        this.dwfzr = dwfzr;
    }

    /**
     * 获取单位负责人联系方式
     *
     * @return dwfzrlxfs - 单位负责人联系方式
     */
    public String getDwfzrlxfs() {
        return dwfzrlxfs;
    }

    /**
     * 设置单位负责人联系方式
     *
     * @param dwfzrlxfs 单位负责人联系方式
     */
    public void setDwfzrlxfs(String dwfzrlxfs) {
        this.dwfzrlxfs = dwfzrlxfs;
    }

    /**
     * 获取状态
     *
     * @return zt - 状态
     */
    public String getZt() {
        return zt;
    }

    /**
     * 设置状态
     *
     * @param zt 状态
     */
    public void setZt(String zt) {
        this.zt = zt;
    }

    /**
     * 获取备注
     *
     * @return bz - 备注
     */
    public String getBz() {
        return bz;
    }

    /**
     * 设置备注
     *
     * @param bz 备注
     */
    public void setBz(String bz) {
        this.bz = bz;
    }

    /**
     * 获取登记人
     *
     * @return djr - 登记人
     */
    public String getDjr() {
        return djr;
    }

    /**
     * 设置登记人
     *
     * @param djr 登记人
     */
    public void setDjr(String djr) {
        this.djr = djr;
    }

    /**
     * 获取登记时间
     *
     * @return djsj - 登记时间
     */
    public Date getDjsj() {
        return djsj;
    }

    /**
     * 设置登记时间
     *
     * @param djsj 登记时间
     */
    public void setDjsj(Date djsj) {
        this.djsj = djsj;
    }
}