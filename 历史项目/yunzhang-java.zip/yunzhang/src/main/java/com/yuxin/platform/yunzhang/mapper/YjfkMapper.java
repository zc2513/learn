package com.yuxin.platform.yunzhang.mapper;

import com.yuxin.platform.common.core.Mapper;
import com.yuxin.platform.yunzhang.model.Yjfk;

public interface YjfkMapper extends Mapper<Yjfk> {
}