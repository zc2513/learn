package com.yuxin.platform.yunzhang.mapper;

import com.yuxin.platform.common.core.Mapper;
import com.yuxin.platform.yunzhang.model.SealApply;

import java.util.List;

public interface SealApplyMapper extends Mapper<SealApply> {

    List<SealApply> selectByApplyUser(SealApply sealApply);

    List<SealApply>  selectByUser(SealApply sealApply);

    List<SealApply> selectByApprover(SealApply sealApply);

    List<SealApply> selectByQybm(SealApply sealApply);

    List<SealApply> selectByGaizhang(SealApply sealApply);

    List<SealApply> selectDsp(SealApply sealApply);

    @Override
    List<SealApply> select(SealApply sealApply);

    SealApply selectByid(String id);
}