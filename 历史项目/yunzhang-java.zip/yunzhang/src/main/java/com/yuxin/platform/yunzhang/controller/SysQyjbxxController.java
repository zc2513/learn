package com.yuxin.platform.yunzhang.controller;
import com.yuxin.platform.common.core.Result;;
import com.yuxin.platform.common.core.ResultGenerator;
import com.yuxin.platform.yunzhang.model.SysQyjbxx;
import com.yuxin.platform.yunzhang.service.SysQyjbxxService;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import org.springframework.web.bind.annotation.*;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import javax.annotation.Resource;
import java.util.List;

/**
* Created by jyh on 2019/05/06.
*/
@Api(value = "SysQyjbxx", description = " ")
@RestController
@RequestMapping("/sys/qyjbxx")
public class SysQyjbxxController {
    @Resource
    private SysQyjbxxService sysQyjbxxService;

    @ApiOperation(value = "", notes = "")
    @PostMapping("/add")
    public Result add(@RequestBody  @ApiParam(name = "") SysQyjbxx sysQyjbxx) {
        sysQyjbxxService.save(sysQyjbxx);
        return ResultGenerator.genSuccessResult();
    }

    @ApiOperation(value = "", notes = "")
    @PostMapping("/delete")
    public Result delete(@RequestParam String id) {
        sysQyjbxxService.deleteById(id);
        return ResultGenerator.genSuccessResult();
    }

    @ApiOperation(value = "", notes = "")
    @PostMapping("/update")
    public Result update(@RequestBody  @ApiParam(name = "") SysQyjbxx sysQyjbxx) {
        sysQyjbxxService.update(sysQyjbxx);
        return ResultGenerator.genSuccessResult();
    }

    @ApiOperation(value = "", notes = "")
    @PostMapping("/detail")
    public Result detail(@RequestParam String id) {
        SysQyjbxx sysQyjbxx = sysQyjbxxService.findById(id);
        return ResultGenerator.genSuccessResult(sysQyjbxx);
    }

    @ApiOperation(value = "", notes = "")
    @PostMapping("/list")
    public Result list(@RequestParam(defaultValue = "0") Integer page, @RequestParam(defaultValue = "0") Integer size) {
        PageHelper.startPage(page, size);
        List<SysQyjbxx> list = sysQyjbxxService.findAll();
        PageInfo pageInfo = new PageInfo(list);
        return ResultGenerator.genSuccessResult(pageInfo);
    }
}
