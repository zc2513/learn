package com.yuxin.platform.yunzhang.controller;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.yuxin.platform.common.core.Result;
import com.yuxin.platform.common.core.ResultGenerator;
import com.yuxin.platform.common.util.UuidUtil;
import com.yuxin.platform.yunzhang.mapper.SealApplyMapper;
import com.yuxin.platform.yunzhang.model.SealApply;
import com.yuxin.platform.yunzhang.schedul.GetAccessTokenSdu;
import com.yuxin.platform.yunzhang.service.SealApplyService;
import com.yuxin.platform.yunzhang.service.impl.WeChatService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.Date;
import java.util.List;

;

/**
 * Created by jyh on 2019/05/06.
 */
@Api(value = "SealApply", description = " ")
@RestController
@RequestMapping("/seal/apply")
public class SealApplyController {

    @Resource
    private SealApplyService sealApplyService;

    @Resource
    private SealApplyMapper sealApplyMapper;

    @Resource
    private WeChatService weChatService;

    @Value("${templateId}")
    private String templateId;


    @ApiOperation(value = "用印申请", notes = "发起用印申请")
    @PostMapping("/add")
    public Result add(@RequestBody @ApiParam(name = "") SealApply sealApply) {
        sealApply.setId(UuidUtil.nowDateUuid());
        sealApply.setApplyTime(new Date());
        sealApply.setStatus(0);
        sealApplyService.save(sealApply);
        String values[] ={"用印申请",sealApply.getApplyUserName(),sealApply.getApplyTime().toString(),sealApply.getApplyOption()};
        String result= weChatService.pushOneUser(GetAccessTokenSdu.ACCESS_TOKEN,sealApply.getOpenid(),sealApply.getFormId(),templateId,values);
        System.out.println(result);
        return ResultGenerator.genSuccessResult();
    }

    @ApiOperation(value = "", notes = "")
    @PostMapping("/delete")
    public Result delete(@RequestParam String id) {
        sealApplyService.deleteById(id);
        return ResultGenerator.genSuccessResult();
    }

    @ApiOperation(value = "", notes = "")
    @PostMapping("/update")
    public Result update(@RequestBody @ApiParam(name = "") SealApply sealApply) {
        sealApply.setApproverTime(new Date());
        sealApplyService.update(sealApply);
        return ResultGenerator.genSuccessResult();
    }

    @ApiOperation(value = "", notes = "")
    @PostMapping("/updateGzcishu")
    public Result updateGzcishu(@RequestBody @ApiParam(name = "") SealApply sealApply) {
        sealApplyService.update(sealApply);
        return ResultGenerator.genSuccessResult();
    }

    @ApiOperation(value = "", notes = "")
    @PostMapping("/detail")
    public Result detail(@RequestParam String id) {
        SealApply sealApply = sealApplyMapper.selectByid(id);
        return ResultGenerator.genSuccessResult(sealApply);
    }

    @ApiOperation(value = "", notes = "")
    @PostMapping("/daigaizhang")
    public Result daigaizhang(@RequestBody @ApiParam(name = "") SealApply sealApply) {
        List<SealApply> list =sealApplyMapper.selectByGaizhang(sealApply);
        if (list.size()>0){
            return ResultGenerator.genSuccessResult(list.get(0));
        }
        return ResultGenerator.genSuccessResult(null);
    }

    @ApiOperation(value = "", notes = "")
    @PostMapping("/selectDsp")
    public Result selectDsp(@RequestBody @ApiParam(name = "") SealApply sealApply) {
        PageHelper.startPage(sealApply.getPage(), sealApply.getSize());
        List<SealApply> list =sealApplyMapper.selectDsp(sealApply);
        PageInfo pageInfo = new PageInfo(list);
        return ResultGenerator.genSuccessResult(pageInfo);
    }


    @ApiOperation(value = "", notes = "")
    @PostMapping("/list")
    public Result list(@RequestParam(defaultValue = "0") Integer page, @RequestParam(defaultValue = "0") Integer size) {
        PageHelper.startPage(page, size);
        List<SealApply> list = sealApplyService.findAll();
        PageInfo pageInfo = new PageInfo(list);
        return ResultGenerator.genSuccessResult(pageInfo);
    }



    @ApiOperation(value = "我的申请", notes = "")
    @PostMapping("/selectByApplyUser")
    public Result selectByApplyUser(@RequestBody @ApiParam(name = "查询条件") SealApply sealApply) {
        PageHelper.startPage(sealApply.getPage(), sealApply.getSize());
        List<SealApply> list = sealApplyMapper.selectByApplyUser(sealApply);
        PageInfo pageInfo = new PageInfo(list);
        return ResultGenerator.genSuccessResult(pageInfo);
    }

    @ApiOperation(value = "我的记录", notes = "")
    @PostMapping("/selectByUser")
    public Result selectByUser(@RequestBody @ApiParam(name = "查询条件") SealApply sealApply) {
        PageHelper.startPage(sealApply.getPage(), sealApply.getSize());
        List<SealApply> list = sealApplyMapper.selectByUser(sealApply);
        PageInfo pageInfo = new PageInfo(list);
        return ResultGenerator.genSuccessResult(pageInfo);
    }

    @ApiOperation(value = "我的审批", notes = "")
    @PostMapping("/selectByApprover")
    public Result selectByApprover(@RequestBody @ApiParam(name = "查询条件") SealApply sealApply) {
        PageHelper.startPage(sealApply.getPage(), sealApply.getSize());
        List<SealApply> list = sealApplyMapper.selectByApprover(sealApply);
        PageInfo pageInfo = new PageInfo(list);
        return ResultGenerator.genSuccessResult(pageInfo);
    }

    @ApiOperation(value = "用章查询，查询本企业的所有用章记录", notes = "")
    @PostMapping("/selectByQybm")
    public Result selectByQybm(@RequestBody @ApiParam(name = "查询条件") SealApply sealApply) {
        PageHelper.startPage(sealApply.getPage(), sealApply.getSize());
        List<SealApply> list = sealApplyMapper.selectByQybm(sealApply);
        PageInfo pageInfo = new PageInfo(list);
        return ResultGenerator.genSuccessResult(pageInfo);
    }


}
