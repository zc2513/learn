package com.yuxin.platform.yunzhang.controller;
import com.yuxin.platform.common.core.Result;;
import com.yuxin.platform.common.core.ResultGenerator;
import com.yuxin.platform.common.util.UuidUtil;
import com.yuxin.platform.yunzhang.mapper.SealInfoMapper;
import com.yuxin.platform.yunzhang.model.SealInfo;
import com.yuxin.platform.yunzhang.service.SealInfoService;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import org.springframework.web.bind.annotation.*;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import javax.annotation.Resource;
import java.util.Date;
import java.util.List;

/**
* Created by jyh on 2019/05/06.
*/
@Api(value = "SealInfo", description = " ")
@RestController
@RequestMapping("/seal/info")
public class SealInfoController {
    @Resource
    private SealInfoService sealInfoService;

    @Resource
    private SealInfoMapper sealInfoMapper;

    @ApiOperation(value = "", notes = "")
    @PostMapping("/add")
    public Result add(@RequestBody  @ApiParam(name = "") SealInfo sealInfo) {
        sealInfo.setId(UuidUtil.nowDateUuid());
        sealInfo.setAddtime(new Date());
        sealInfoService.save(sealInfo);
        return ResultGenerator.genSuccessResult();
    }

    @ApiOperation(value = "", notes = "")
    @PostMapping("/delete")
    public Result delete(@RequestParam String id) {
        sealInfoService.deleteById(id);
        return ResultGenerator.genSuccessResult();
    }

    @ApiOperation(value = "", notes = "")
    @PostMapping("/update")
    public Result update(@RequestBody  @ApiParam(name = "") SealInfo sealInfo) {
        sealInfoService.update(sealInfo);
        return ResultGenerator.genSuccessResult();
    }

    @ApiOperation(value = "", notes = "")
    @PostMapping("/detail")
    public Result detail(@RequestParam String id) {
        SealInfo sealInfo = sealInfoService.findById(id);
        return ResultGenerator.genSuccessResult(sealInfo);
    }

    @ApiOperation(value = "", notes = "")
    @PostMapping("/list")
    public Result list(@RequestBody SealInfo sealInfo) {
        PageHelper.startPage(sealInfo.getPage(), sealInfo.getSize());
        List<SealInfo> list = sealInfoMapper.selectByQybm(sealInfo);
        PageInfo pageInfo = new PageInfo(list);
        return ResultGenerator.genSuccessResult(pageInfo);
    }


}
