package com.yuxin.platform.yunzhang;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.servlet.ServletComponentScan;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.web.client.RestTemplate;
import tk.mybatis.spring.annotation.MapperScan;

@SpringBootApplication
@ComponentScan(basePackages = {"com.yuxin.platform"})
@MapperScan(basePackages = {"com.yuxin.platform.*.mapper"})
@EnableScheduling
@ServletComponentScan(basePackages = {"com.yuxin.platform"})
public class YunzhangApplication {

	public static void main(String[] args) {
		SpringApplication.run(YunzhangApplication.class, args);
	}

	@Bean
	public RestTemplate restTemplate() {
		return new RestTemplate();
	}

}
