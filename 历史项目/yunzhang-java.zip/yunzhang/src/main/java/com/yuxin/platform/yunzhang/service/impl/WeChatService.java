package com.yuxin.platform.yunzhang.service.impl;

import com.alibaba.fastjson.JSONObject;
import com.yuxin.platform.yunzhang.dto.TemplateDataVo;
import com.yuxin.platform.yunzhang.dto.WxMssVo;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.HashMap;
import java.util.Map;

/**
 * @author jyh
 * @create 2019-06-26-15:21
 */
@Service
public class WeChatService {

    @Autowired
    private RestTemplate restTemplate;

    @Value("${appid}")
    private String appid;




    @Value("${appsecret}")
    private String appsecret;

    public String pushOneUser(String access_token,String openid, String formId,String templateId,String[] keywords) {
        //如果access_token为空则从新获取
        if(StringUtils.isEmpty(access_token)){
            access_token = getAccess_token();
        }
        String url = "https://api.weixin.qq.com/cgi-bin/message/wxopen/template/send" +
                "?access_token=" + access_token;

        //拼接推送的模版
        WxMssVo wxMssVo = new WxMssVo();
        wxMssVo.setTouser(openid);
        wxMssVo.setForm_id(formId);
        wxMssVo.setTemplate_id(templateId);
        Map<String, TemplateDataVo> m = new HashMap<>();
        //封装数据
        if(keywords.length>0){
            for(int i=1;i<=keywords.length;i++){
                TemplateDataVo keyword = new TemplateDataVo();
                keyword.setValue(keywords[i-1]);
                m.put("keyword"+i, keyword);
            }
            wxMssVo.setData(m);
        }else{
            return null;
        }

        if(restTemplate==null){
            restTemplate = new RestTemplate();
        }
        JSONObject json = (JSONObject) JSONObject.toJSON(wxMssVo);
        System.out.println(json);
        ResponseEntity<String> responseEntity =
                restTemplate.postForEntity(url, json, String.class);
        return responseEntity.getBody();
    }


    public String getAccess_token() {
        //获取access_token
        String url = "https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential" +
                "&appid=wx324a18ae9c10f63b"  + "&secret=3bcace0ab88c31f667b2d0e6a711255b";
        if(restTemplate==null){
            restTemplate = new RestTemplate();
        }
        String json = restTemplate.getForObject(url, String.class);
        System.out.println(json);
        JSONObject myJson = JSONObject.parseObject(json);
        return myJson.get("access_token").toString();
    }


    public static void main(String[] args) {
        //System.out.println(new WeChatService().getAccess_token());
        WeChatService weChatUtil = new WeChatService();
        String values[] ={"用印申请","张三","2019-5-8 10:10:10","签合同"};
        String result= weChatUtil.pushOneUser("22_sD1_ufY0NDse25equlb_2Sn-Fo3BsCHAvQ9Qjrmc5fZ2ci-5_WzqinNtW2HgNQwK9tennNC5T5I3GUSB71N7JhKv0sLwfOR9B7pgrTgShpRSp_b_qw9r2UE21RGPmfbPpArKDUyqo364-LsIJQEdAJAELZ"
                ,"oqFon4_LotnKUYdQTaSBG41LaWB0","cc47c33557c84da9914a1af4e0c4ee40","TFJS16mLLwRw-KB8cNuMsuHNizxPsJOWfP9IwQqceg4"
                ,values);
        System.out.println("返回结果"+result);
    }


}
