package com.yuxin.platform.yunzhang.model;

import java.util.Date;
import javax.persistence.*;

public class Yjfk {
    /**
     * 主键
     */
    @Id
    private String id;

    /**
     * 标题
     */
    private String title;

    /**
     * 内容
     */
    private String context;

    /**
     * 反馈人
     */
    private String user;

    /**
     * 反馈时间
     */
    private Date addtime;

    /**
     * 获取主键
     *
     * @return id - 主键
     */
    public String getId() {
        return id;
    }

    /**
     * 设置主键
     *
     * @param id 主键
     */
    public void setId(String id) {
        this.id = id;
    }

    /**
     * 获取标题
     *
     * @return title - 标题
     */
    public String getTitle() {
        return title;
    }

    /**
     * 设置标题
     *
     * @param title 标题
     */
    public void setTitle(String title) {
        this.title = title;
    }

    /**
     * 获取内容
     *
     * @return context - 内容
     */
    public String getContext() {
        return context;
    }

    /**
     * 设置内容
     *
     * @param context 内容
     */
    public void setContext(String context) {
        this.context = context;
    }

    /**
     * 获取反馈人
     *
     * @return user - 反馈人
     */
    public String getUser() {
        return user;
    }

    /**
     * 设置反馈人
     *
     * @param user 反馈人
     */
    public void setUser(String user) {
        this.user = user;
    }

    /**
     * 获取反馈时间
     *
     * @return addtime - 反馈时间
     */
    public Date getAddtime() {
        return addtime;
    }

    /**
     * 设置反馈时间
     *
     * @param addtime 反馈时间
     */
    public void setAddtime(Date addtime) {
        this.addtime = addtime;
    }
}