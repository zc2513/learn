package com.yuxin.platform.yunzhang.controller;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import static org.junit.Assert.*;

/**
 * @author jyh
 * @create 2019-07-03-9:50
 */
@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest
public class SealInfoControllerTest {

    @Before
    public void setUp() throws Exception {
    }

    @After
    public void tearDown() throws Exception {
    }

    @Test
    public void add() {

    }

    @Test
    public void delete() {
    }

    @Test
    public void update() {
    }

    @Test
    public void detail() {
    }

    @Test
    public void list() {
    }
}