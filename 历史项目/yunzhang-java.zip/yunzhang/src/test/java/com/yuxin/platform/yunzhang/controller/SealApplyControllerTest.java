package com.yuxin.platform.yunzhang.controller;

import static org.junit.Assert.*;

/**
 * @author jyh
 * @create 2019-07-03-9:47
 */
public class SealApplyControllerTest {

}