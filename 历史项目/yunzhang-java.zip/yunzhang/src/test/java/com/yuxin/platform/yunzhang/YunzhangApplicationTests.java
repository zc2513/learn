package com.yuxin.platform.yunzhang;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest
public class YunzhangApplicationTests {

	@Test
	public void contextLoads() {

		float a = 1.0f - 0.9f;
		float b = 0.9f - 0.8f;
		if (a == b) {
			System.out.println("true");
		} else {
			System.out.println("false");
		}
	}


}
