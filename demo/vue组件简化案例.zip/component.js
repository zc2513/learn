Vue.component("pageOne", {
    props:[],
    template: `<div><h1>啦啦啦啦啦啦啦</h1></div>`,
    methods:{

    }

})