<template>
<!-- 我的审批/详情&审批 -->
  <div class="pass-Info-box">
    <div class="pass-Info" v-if="infoData">
      <div>
        <div>印章名称</div>
        <div v-text="infoData.sealname"></div>
      </div>
      <div>
        <div>申请事由</div>
        <div v-text="infoData.applyOption"></div>
      </div>
      <div>
        <div>申请时间</div>
        <div v-text="infoData.applyTime"></div>
      </div>
      <div>
        <div>申请人</div>
        <div v-text="infoData.applyUserName"></div>
      </div>
      <div>
        <div>有效时间</div>
        <div v-text="infoData.effectiveTime"></div>
      </div>
      <div>
        <div>申请用章次数</div>
        <div v-text="infoData.count"></div>
      </div>
      <div class="last-spyj" v-if="this.detailData.type=='详情'">
        <div>审批意见</div>
        <div v-text="infoData.approverOpinion"></div>
      </div>
    </div>
    <div class="approval-opinion" v-if="this.detailData.type=='审批'">
      <div>审批意见</div>
      <div>
        <el-input type="textarea" :rows="1" placeholder="请输入..." v-model="approverOpinion"></el-input>
      </div>
    </div> 
    <div class="add-btn-box add-dialog" v-if="this.detailData.type=='审批'">
      <el-button type="small" class="cancel-cls" @click="submityj(-1)">不 通 过</el-button>
      <el-button type="small" @click="submityj(1)">通 过</el-button>
    </div> 
  </div>
</template>

<script>
  import { getInfo, postUpdata } from 'api/examinelog/myaudit.js'
  export default {
    props: ['detailData'],
    data() {
      return {
        approverOpinion: null, // 审批意见
        infoData: null
      }
    },
    created() {
      this.init(this.detailData.id)
    },
    methods: {
      init(id) {
        getInfo({ id: id }).then(res => {
          if (res.message === 'SUCCESS') {
            res.data.sealname = this.detailData.sealname
            this.infoData = res.data
          }
        })
      },
      submityj(status) { // ---通过&不通过
        const data = {
          id: this.detailData.id,
          status: status,
          approverOpinion: this.approverOpinion
        }
        postUpdata(data).then(res => {
          if (res.message == 'SUCCESS') {
            this.$message.success('操作成功')
            this.$emit('addEvent', false)
          } else {
            console.warn(res)
          }
        })
      }
    }
  }
</script>

<style lang="scss" scoped>
@import '../../../styles/particulars.scss';
.pass-Info-box{
  .approval-opinion{//---审批意见
    margin: 20px 0;
    display: flex;
    >div:first-of-type{
      box-sizing: border-box;
      width: 10%;
      min-width: 100px;
      line-height: 30px;
      text-align: center;
    }
    >div:last-of-type{
      width: 90%;
    }
  }
  .add-dialog{//---按钮位置
    text-align: right;
  }
}
</style>