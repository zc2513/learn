/* eslint-disable no-undef */
// 我的审批
import { getList } from 'api/examinelog/myaudit.js'
var changPageSizeNum = { // 一共多少数据
  type: false,
  total: 0
}
export function btnconfig() {
  const btn = {
    title: '操作',
    width: '160',
    btnlist: [
      {
        con: '详情',
        type: 'text',
        size: 'small'
      },
      {
        con: '审批',
        type: 'text',
        size: 'small'
      }
    ]
  }
  return btn
}
export var titles = [
  { name: '印章名称', data: 'sealname' },
  { name: '申请人', data: 'applyUserName' },
  { name: '申请事由', data: 'applyOption' },
  { name: '状态', data: 'status' },
  { name: '审批时间', data: 'approverTime' }
]

export function tabalInfo(data) { // 表单数据
  let tableData = []
  return new Promise((reslove, reject) => {
    getList(data).then(res => {
      if (res.message === 'SUCCESS') {
        const data = res.data
        if (data.list) {
          for (const item of data.list) {
            item.status = item.status === 0 ? '待审批' : (item.status === 1 ? '审批通过' : (item.status === -1 ? '未通过' : '已完成'))
          }
        }
        tableData = data.list || []
        changPageSizeNum.total = data.total || 0
        reslove({ changPageSizeNum, tableData })
      } else {
        reject(res)
      }
    })
  })
}
