// 我的申请
import { getList } from 'api/examinelog/pass.js'
import { dateFormat } from '@/utils/tools.js'
var changPageSizeNum = { // 一共多少数据
  type: false,
  total: 0
}

export var titles = [
  { name: '印章编码', data: 'sealname' },
  { name: '申请人名称', data: 'applyUserName' },
  { name: '申请事由', data: 'applyOption' },
  { name: '状态', data: 'status' },
  { name: '申请时间', data: 'applyTime' }
]

export function tabalInfo(data) { // 表单数据
  let tableData = []
  return new Promise((reslove, reject) => {
    getList(data).then(res => {
      if (res.message === 'SUCCESS') {
        const data = res.data
        if (data.list) {
          for (const item of data.list) {
            // item.applyTime = dateFormat(item.applyTime)
            item.status = item.status === 0 ? '待审批' : (item.status === 1 ? '审批通过' : (item.status === -1 ? '未通过' : '已完成'))
          }
        }
        tableData = data.list || []
        changPageSizeNum.total = data.total || 0
        reslove({ changPageSizeNum, tableData })
      } else {
        reject(res)
      }
    })
  })
}
