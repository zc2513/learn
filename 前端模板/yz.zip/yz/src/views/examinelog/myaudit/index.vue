 <template>
<!-- 我的申请 -->
   <div>
     <el-card >
        <div class="search_box">
            <el-form :inline="true" :model="searchForm"  class="demo-dynamic" size="small">
              <!-- <el-form-item label='企业编码:'>
                <el-input v-model="searchForm.qybm" placeholder="请输入..."></el-input>
              </el-form-item>
              <el-form-item label='印章编码:'>
                <el-input v-model="searchForm.sealcode" placeholder="请输入..."></el-input>
              </el-form-item>  -->
              <el-form-item label='申请时间'>
                <el-date-picker
                  v-model="searchFormTm"
                  type="daterange"
                  range-separator="~"
                  value-format='yyyy-MM-dd HH:mm:ss'
                  :default-time="['00:00:00', '23:59:59']"
                  start-placeholder="开始日期"
                  end-placeholder="结束日期"
                ></el-date-picker>
                <el-button  @click="searchCompanyFun">查询</el-button>
              </el-form-item> 
            </el-form>
          </div> 
          <div class="table_box">
            <public-table :msg="tableList" @sendVal="getBtnDataFun"></public-table>
            <public-page @pagesend="getPageSizeFun" :changPageSize="changPageSizeNum"></public-page>
          </div>
      </el-card>
   </div>
 </template>
 
 <script>
import publicTable from 'components/Table/tablePlugin';
import publicPage from 'components/Table/page';
import { titles, tabalInfo } from './table.js'
   export default {
  components: {
    publicTable,
    publicPage
  },
  data() {
    return {
      searchForm: {
        // qybm:null,
        // sealcode:null,
        startTime: null,
        endTime: null
      },
      tableList: {// 版本封装问题 修改太多 所以加tableData:[] 是为了去除警告。
        tableData: [] // 表格数据
      }, // 表格数据
      changPageSizeNum: {},
      searchFormTm: null
    }
  },
  created() {
    this.tableList['titles'] = titles 
        this.initData()
  },
  methods: {
    initData(params, page = 0) {
      let data = {
        applyUser: JSON.parse(this.$store.state.user.users).userId,
        page: page,
        size: 10
      }
      if (params) {
        data = { ...data, ...params }
      }
      tabalInfo(data).then(res => {
        this.changPageSizeNum = res.changPageSizeNum
        this.tableList['tableData'] = res.tableData
      })
    },
    getBtnDataFun(val) { // ---按钮
      console.log(val)
    },
    getPageSizeFun(page) { // ---分页
      this.nowPage = page
      this.initData(this.searchForm, page)
    },
    searchCompanyFun() { // ---查询
      this.searchForm.startTime = this.searchFormTm ? this.searchFormTm[0] : null
          this.searchForm.endTime = this.searchFormTm ? this.searchFormTm[1] : null
          this.changPageSizeNum.type = true
      this.initData(this.searchForm)
    }
  }
}
 </script>
 
 <style lang="scss" scoped>
 
 </style>