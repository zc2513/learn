<template>
  <div class="app-wrapper" :class="classObj">
    <div v-if="device==='mobile'&&sidebar.opened" class="drawer-bg" @click="handleClickOutside"></div>
    <div class="header">
      <div>
        <img src="../../assets/logo_index.png" alt="" style="width:10%;">
        <div class="logoText">
          <span>印章安全管控信息平台</span>
        </div>
      </div>
      <div class="set_up">
        <el-dropdown trigger="click">
          <span class="el-dropdown-link">
            账户设置<i class="el-icon-arrow-down el-icon--right"></i>
          </span>
          <el-dropdown-menu slot="dropdown">
            <el-dropdown-item divided  @click.native="accountInformationFun">账户信息</el-dropdown-item>
            <el-dropdown-item divided  @click.native="changePasswordFun">密码修改</el-dropdown-item>
          </el-dropdown-menu>
        </el-dropdown>
        <el-button type="text" @click="logout">退出</el-button>
        <div v-if="addType.state">
            <dialog-view :addData='addType' @cancelEven='getDialog'>
              <div slot="content">
                  <setting-view :pageType='addType.title'></setting-view>
              </div>
            </dialog-view>
        </div>
      </div>
    </div>
    <div class="sidebar">
      <sidebar class="sidebar-container"></sidebar>
      <div class="main-container">
        <navbar></navbar>
        <app-main></app-main>
      </div>
    </div>
  </div>
</template>

<script>
import { Navbar, Sidebar, AppMain } from './components'
import ResizeMixin from './mixin/ResizeHandler'
import dialogView from 'components/dialog/index.vue'
import settingView from '@/views/userSetting/index.vue'
import { updatePassword } from 'api/xitongguanli/user.js'

// 接口
import {
  getAccountIoApi,
  getChangePasswordApi
} from 'api/xitongguanli/role.js'

export default {
  name: 'layout',
  components: {
    Navbar,
    Sidebar,
    AppMain,
    dialogView,
    settingView
  },
  data() {
    return {
      addType: {
        state: false,
        title: '账户信息', // 弹窗标题
        width: '50%'
      }
    }
  },
  mixins: [ResizeMixin],
  computed: {
    sidebar() {
      return this.$store.state.app.sidebar
    },
    device() {
      return this.$store.state.app.device
    },
    classObj() {
      return {
        hideSidebar: !this.sidebar.opened,
        openSidebar: this.sidebar.opened,
        withoutAnimation: this.sidebar.withoutAnimation,
        mobile: this.device === 'mobile'
      }
    }
  },
  methods: {
    handleClickOutside() {
      this.$store.dispatch('CloseSideBar', { withoutAnimation: false })
    },
    logout() {
      this.$confirm('确定退出登录吗?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      })
        .then(() => {
          this.$store.dispatch('LogOut').then(() => {
            location.reload() // 为了重新实例化vue-router对象 避免bug
            this.$message({
              type: 'success',
              message: '退出成功!'
            })
          })
        })
        .catch(() => {
          this.$message({
            type: 'info',
            message: '已取消退出'
          })
        })
    },

    accountInformationFun() { // ---账户信息
      this.addType.title = '账户信息'
      this.addType.state = true
    },
    changePasswordFun() { // ---修改密码
      this.addType.title = '修改密码'
      this.addType.state = true
    },
    getDialog(state) { // 新增弹窗的状态
      this.addType.state = state
    }
  }
}
</script>

<style rel="stylesheet/scss" lang="scss" scoped>
@import "src/styles/mixin.scss";
.app-wrapper {
  @include clearfix;
  position: relative;
  height: 100%;
  width: 100%;
  &.mobile.openSidebar {
    position: fixed;
    top: 0;
  }
}
// .drawer-bg {
//   background: #000;
//   opacity: 0.3;
//   width: 100%;
//   top: 0;
//   height: 100%;
//   position: absolute;
//   z-index: 999;
// }
.header {
  height: 60px;
  background-color: #0951a4;
  font-size: 19px;
  line-height: 60px;
  position: relative;
  img {
    border-width: 0px;
    position: absolute;
    left: 10px;
    top: 0px;
    width: 46px;
    height: 47px;
    margin: 8px;
  }
  .logoText {
    border-width: 0px;
    position: absolute;
    left: 220px;
    // top: 14px;
    width: 477px;
    height: 60px;
    font-family: "Arial Negreta", "Arial Normal", "Arial";
    font-weight: 700;
    font-style: normal;
    font-size: 28px;
    color: #ffffff;
    line-height: 60px;
  }
  .set_up {
    float: right;
    margin-right: 20px;
    .el-dropdown{
      color: #fff;
      position: absolute;
      right: 70px;
      cursor: pointer;
    }
    .el-button{
      color: #fff;
    }
  }
}
.sidebar {
  // float: left;
  height: 100%;
  overflow-y: auto;
}
.info_box{
  width: 100%;
  height: auto;
  background: #369363;
  li{
    width: 50%;
    height: 50px;
    float: left;
    list-style: none;
    label{
      width: 80px;
      display: block;
      text-align: right;
      float: left;
    }
    span{
      float: left;
    }
  }
}
</style>
