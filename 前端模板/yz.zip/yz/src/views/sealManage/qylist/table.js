// 云章列表数据
import { getList } from 'api/sealManage/sealList.js'
import { dateFormat } from '@/utils/tools.js'
var changPageSizeNum = { // 一共多少数据
  type: false,
  total: 0
}
export function btnconfig() {
  const btn = {
    title: '操作',
    // width: '180',
    btnlist: [
      {
        con: '删除',
        type: 'success',
        size: 'mini'
      }
    ]
  }
  return btn
}

export var titles = [
  { name: '企业名称', data: 'qymc' },
  { name: '企业编码', data: 'qybm' },
  { name: '云章名称', data: 'name' },
  { name: '云章编码', data: 'code' },
  { name: '云章序列号', data: 'serizlizable' },
  { name: '新增时间', data: 'addtime' }
]

export function tabalInfo(data) { // 表单数据
  let tableData = []
  return new Promise((reslove, reject) => {
    getList(data).then(res => {
      if (res.message === 'SUCCESS') {
        const data = res.data
        if (data.list) {
          for (const item of data.list) {
            item.addtime = dateFormat(item.addtime)
          }
        }
        tableData = data.list || []
        changPageSizeNum.total = data.total || 0
        reslove({ changPageSizeNum, tableData })
      } else {
        reject(res)
      }
    })
  })
}

