<template>
  <div>
     <el-card >
          <div class="search_box">
            <el-form :inline="true" :model="searchForm"   class="demo-dynamic" size="small">
              <el-form-item label='企业名称:'>
                <el-input v-model="searchForm.qymc" placeholder="请输入..."></el-input>
              </el-form-item>
              <el-form-item label='企业编码:'>
                <el-input v-model="searchForm.qybm" placeholder="请输入..."></el-input>
              </el-form-item> 
              <el-form-item label>
                <el-date-picker
                  v-model="searchFormTm"
                  type="daterange"
                  range-separator="~"
                  value-format='yyyy-MM-dd HH:mm:ss'
                  :default-time="['00:00:00', '23:59:59']"
                  start-placeholder="开始日期"
                  end-placeholder="结束日期"
                ></el-date-picker>
                <el-button  @click="searchCompanyFun">查询</el-button>
              </el-form-item>  
            </el-form>
          </div> 
          <div class="table_box">
            <public-table :msg="tableList"></public-table>
            <public-page @pagesend="getPageSizeFun" :changPageSize="changPageSizeNum"></public-page>
          </div>
      </el-card> 
   </div>
</template>

<script>
import publicTable from "components/Table/tablePlugin";
import publicPage from "components/Table/page";
import dialogView from "components/dialog/index.vue";
import { deleteTableData } from 'api/sealManage/sealList.js'
import { btnconfig , titles , tabalInfo} from './table.js';
  export default {
     components:{
       publicTable,
       publicPage,
       dialogView,
     },
     data(){
       return{
          searchForm:{
            qymc:null,
            qybm:null,
            startTime:null,
            endTime:null,
          },
          tableList: {//版本封装问题 修改太多 所以加tableData:[] 是为了去除警告。
              tableData: [],//表格数据
          },//表格数据
          changPageSizeNum: {},
          searchFormTm:null, 
          addType:{
            state:false,
            title:'新增',//弹窗标题
            width:'50%',
            id:null
          }
       }
     },
     created() {
        this.tableList['titles'] =titles; 
        // this.tableList['btnconfig'] =btnconfig();  
        this.initData()
     },
     methods: {
       initData(params,page=0){
         let data = {
           qybm: JSON.parse(this.$store.state.user.users).qybm,
           page:page,
           size:10
         }
         if(params){
           data = {...data,...params}
         }
         tabalInfo(data).then(res=>{
           this.changPageSizeNum = res.changPageSizeNum
           this.tableList['tableData'] = res.tableData
         })
       }, 
       getPageSizeFun(page){ // ---分页
         this.nowPage = page
         this.initData(this.searchForm,page)
       },
       searchCompanyFun(){ // ---查询
          this.searchForm.startTime = this.searchFormTm ? this.searchFormTm[0] : null;
          this.searchForm.endTime = this.searchFormTm ? this.searchFormTm[1] : null;
          this.changPageSizeNum.type= true
          this.initData(this.searchForm)
       }, 
     },
   }
</script>

<style lang="scss" scoped>

</style>