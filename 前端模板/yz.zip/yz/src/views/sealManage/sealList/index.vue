 <template>
 <!-- 云章列表 -->
   <div>
     <el-card >
          <!-- <div class="search_box">
            <el-form :inline="true" :model="searchForm"   class="demo-dynamic" size="small">
              <el-form-item label='印章名称:'>
                <el-input v-model="searchForm.name" placeholder="请输入..."></el-input>
              </el-form-item>
              <el-form-item label='印章编码:'>
                <el-input v-model="searchForm.nameOrCode" placeholder="请输入..."></el-input>
              </el-form-item> 
              <el-form-item label>
                <el-date-picker
                  v-model="searchFormTm"
                  type="daterange"
                  range-separator="~"
                  value-format='yyyy-MM-dd HH:mm:ss'
                  :default-time="['00:00:00', '23:59:59']"
                  start-placeholder="开始日期"
                  end-placeholder="结束日期"
                ></el-date-picker>
              </el-form-item>
              <el-form-item>
                <el-button  @click="searchCompanyFun">查询</el-button>
              </el-form-item>
            </el-form>
          </div> -->
          <div class="add-btn-box">
            <el-button type="small" class="index-add" @click="add">新增</el-button>
          </div> 
          <div class="table_box">
            <public-table :msg="tableList" @sendVal="getBtnDataFun"></public-table>
            <public-page @pagesend="getPageSizeFun" :changPageSize="changPageSizeNum"></public-page>
          </div>
      </el-card>
      <div v-if="addType.state">
        <dialog-view :addData='addType' @cancelEven='getDialog'>
          <div slot="content">
              <add-view @addEvent='getDialog' :pageType='addType'></add-view>
          </div>
        </dialog-view>
      </div>
   </div>
 </template>
 
 <script>
import publicTable from "components/Table/tablePlugin";
import publicPage from "components/Table/page";
import dialogView from "components/dialog/index.vue";
import addView from './add';
import { deleteTableData } from 'api/sealManage/sealList.js'
import { btnconfig , titles , tabalInfo} from './table.js';
   export default {
     components:{
       publicTable,
       publicPage,
       dialogView,
       addView
     },
     data(){
       return{
          // searchForm:{
          //   name:null,
          //   nameOrCode:null,
          //   startTime:null,
          //   endTime:null,
          // },
          tableList: {//版本封装问题 修改太多 所以加tableData:[] 是为了去除警告。
              tableData: [],//表格数据
          },//表格数据
          changPageSizeNum: {},
          searchFormTm:null, 
          addType:{
            state:false,
            title:'新增',//弹窗标题
            width:'50%',
            id:null
          }
       }
     },
     created() {
        this.tableList['titles'] =titles; 
        this.tableList['btnconfig'] =btnconfig();  
        this.initData()
     },
     methods: {
       initData(page=0){
         let data = {
           qybm: JSON.parse(this.$store.state.user.users).qybm,
           page:page,
           size:10
         }
        //  if(params){
        //    data = {...data,...params}
        //  }
         tabalInfo(data).then(res=>{
           this.changPageSizeNum = res.changPageSizeNum
           this.tableList['tableData'] = res.tableData
         })
       },
       getBtnDataFun(val){ // ---按钮
         this.addType.title=val.type;
         if(val.type == '修改'){
           this.addType.id=val.data.id;
           this.addType.state=true;
         }
         if(val.type == '删除'){
           this.$confirm('此操作将永久删除, 是否继续?', '提示', {
              confirmButtonText: '确定',
              cancelButtonText: '取消',
              type: 'warning'
            }).then(() => {
              this.deleteTableData(val.data.id)
            }).catch(() => {
              this.$message.info( '已取消' );
            })
         }
       },
       getPageSizeFun(page){ // ---分页
         this.nowPage = page
         this.initData(page)
        //  this.initData(this.searchForm,page)
       },
      //  searchCompanyFun(){ // ---查询
      //     this.searchForm.startTime = this.searchFormTm ? this.searchFormTm[0] : null;
      //     this.searchForm.endTime = this.searchFormTm ? this.searchFormTm[1] : null;
      //     this.changPageSizeNum.type= true
      //     this.initData(this.searchForm)
      //  },
       add(){//---新增
         this.addType.title='新增';
         this.addType.state=true;
       },
       deleteTableData(id){//---删除
         deleteTableData({id:id}).then(res=>{
           if(res.code == 200 && res.message == "SUCCESS"){ 
            if(this.changPageSizeNum.total % 10 == 1){
              this.nowPage = this.nowPage-1;
            } 
            this.initData(this.nowPage)
            this.changPageSizeNum.nowPage = this.nowPage 
            this.$message.success('操作成功')
           }else{ 
             this.$message.error('操作失败')
           }
         })
       },
       getDialog(state){//新增弹窗的状态
          if(!state && this.addType.title == '新增'){ 
            this.changPageSizeNum.nowPage = 1 
            this.initData()
          }
          if(!state && this.addType.title == '修改') this.initData(this.nowPage);
          this.addType.state=state
       }, 
     },
   }
 </script>
 
 <style>
 .from-k .el-form-item{
    box-sizing: border-box;
    width: 100%;
    display: flex;
  }
  .from-k .el-form-item__content{
    box-sizing: border-box;
    flex: 1;
    max-width: 80%;
  }
 </style>