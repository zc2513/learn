<template>
<!-- 云章列表 -->
  <div>
    <el-form :model="ruleForm" 
      :rules="rules" 
      ref="ruleForm" 
      label-width="80px" 
      :inline="true" 
      size="small" 
      class="from-k"
      >
      <el-row :gutter="8">
        <el-col :sm="24" :lg="12">
          <el-form-item label="印章名称" prop="name">
            <el-input v-model="ruleForm.name"      ></el-input>
          </el-form-item>
        </el-col>
        <el-col :sm="24" :lg="12">
          <el-form-item label="印章编码" prop="code">
            <el-input v-model="ruleForm.code" ></el-input>
          </el-form-item>
        </el-col> 
        <el-col :sm="24" :lg="12">
          <el-form-item label="印章序号" prop="serizlizable">
            <el-input v-model="ruleForm.serizlizable" ></el-input>
          </el-form-item>
        </el-col>  
      </el-row> 
    </el-form>
    <div class="add-btn-box add-dialog">
      <el-button type="small" class="cancel-cls" @click="abolish">取 消</el-button>
      <el-button type="small" @click="submitForm('ruleForm')">确 定</el-button>
    </div>
  </div>
</template>
<script>
  import { addData, getInfo } from 'api/sealManage/sealList.js'
  import validateFun from '@/utils/validate.js'
  export default {
    props: ['pageType'],
    data() {
      return {
        ruleForm: {
          // name: '测试' + parseInt(Math.random() * 100),
          // code: (new Date()).getTime() + '',
          // serizlizable: parseInt(Math.random() * 1000)
          name:null,
          code:null,
          serizlizable:null,
        },
        rules: {
          name: [
            { required: true, message: '请输入名称', trigger: 'blur' }
          ],
          code: [
            { required: true, message: '请输入编码', trigger: 'blur' },
            { min: 10, max: 18, message: '长度在 10 到 18 个字符', trigger: 'blur' }
          ],
          serizlizable: [
            { required: true, message: '请输入序列哈', trigger: 'blur' },
            { validator: validateFun.pureNumbers, trigger: 'blur' }
          ]
        }
      }
  },
    created() {
      if (this.pageType.title == '修改') this.init()
  },
    methods: {
      init() {
        getInfo({ id: this.pageType.id }).then(res => {
          if (res.message == 'SUCCESS') {
            const { name, code, serizlizable } = res.data
            this.ruleForm = { name, code, serizlizable }
          }
        })
      },
      submitForm(formName) {
        this.$refs[formName].validate((valid) => {
          if (valid) {
            const { realname: adduserName, userId: adduser, qybm } = JSON.parse(this.$store.state.user.users)
            let data, uri
            if (this.pageType.title == '修改') {
              uri = 'update'
              data = Object.assign({}, { adduser, adduserName, id: this.pageType.id, qybm }, this.ruleForm)
            } else {
              uri = 'add'
              data = Object.assign({}, { adduser, adduserName, qybm }, this.ruleForm)
            }
            addData(data, uri).then(res => {
              if (res.code == 200 && res.message == 'SUCCESS') {
                this.$message.success('操作成功')
                this.$emit('addEvent', false)
              } else {
                this.$message.success('操作失败')
              }
            })
          } else {
            return false
          }
        })
      },
      resetForm(formName) { // ---重置
        this.$refs[formName].resetFields()
      },
      abolish() {
        this.$emit('addEvent', false)
      }
    }
  }
</script>  
<style>
  .add-dialog{
    text-align: right;
  }  
</style>