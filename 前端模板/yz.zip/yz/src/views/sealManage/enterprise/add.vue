<template>
  <div>
    <el-form :model="ruleForm" 
      :rules="rules" 
      ref="ruleForm" 
      label-width="120px" 
      :inline="true" 
      size="small" 
      class="from-k"
      >
      <el-row>
        <el-col :sm="24" :lg="12">
          <el-form-item label="单位名称">
            <el-input v-model="ruleForm.pass"    style="width: 100%;"  auto-complete="off"></el-input>
          </el-form-item>
        </el-col>
        <el-col :sm="24" :lg="12">
          <el-form-item label="单位编号">
            <el-input v-model="ruleForm.checkPass"  auto-complete="off"></el-input>
          </el-form-item>
        </el-col>
        <el-col :sm="24" :lg="12">
          <el-form-item label="单位地址">
            <el-input v-model.number="ruleForm.age" auto-complete="off"></el-input>
          </el-form-item>
        </el-col>
        <el-col :sm="24" :lg="12">
          <el-form-item label="联系电话">
            <el-input v-model.number="ruleForm.age" auto-complete="off"></el-input>
          </el-form-item>
        </el-col>
        <el-col :sm="24" :lg="12">
          <el-form-item label="法定代表人">
            <el-input v-model.number="ruleForm.age" auto-complete="off"></el-input>
          </el-form-item>
        </el-col>
        <el-col :sm="24" :lg="12">
          <el-form-item label="法人联系方式">
            <el-input v-model.number="ruleForm.age" auto-complete="off"></el-input>
          </el-form-item>
        </el-col>
        <el-col :sm="24" :lg="12">
          <el-form-item label="统一社会信用代码">
            <el-input v-model.number="ruleForm.age" auto-complete="off"></el-input>
          </el-form-item>
        </el-col>
        <el-col :sm="24" :lg="12">
          <el-form-item label="营业执照照片">
            <el-input v-model.number="ruleForm.age" auto-complete="off"></el-input>
          </el-form-item>
        </el-col>
        <el-col :sm="24" :lg="12">
          <el-form-item label="单位负责人">
            <el-input v-model.number="ruleForm.age" auto-complete="off"></el-input>
          </el-form-item>
        </el-col>
        <el-col :sm="24" :lg="12">
          <el-form-item label="负责人联系方式">
            <el-input v-model.number="ruleForm.age" auto-complete="off"></el-input>
          </el-form-item>
        </el-col>
        <el-col :sm="24" :lg="12">
          <el-form-item label="备注">
            <el-input v-model.number="ruleForm.age" auto-complete="off"></el-input>
          </el-form-item>
        </el-col>
      </el-row> 
    </el-form>
    <div class="add-btn-box add-dialog">
      <el-button type="small" class="cancel-cls" @click="abolish">取 消</el-button>
      <el-button type="small" @click="submitForm">确 定</el-button>
    </div>
  </div>
</template>
<script>
  export default {
    data() { 
      var validatePass = (rule, value, callback) => {
        if (value === '') {
          callback(new Error('内容不能为空'));
        } else {
          callback();
        }
      };
      return {
        ruleForm: {
          pass: '',
          checkPass: '',
          age: ''
        },
        rules: {
          pass: [
            { validator: validatePass, trigger: 'blur' }
          ] 
        }
      };
    },
    methods: {
      // submitForm(formName) {
      //   this.$refs[formName].validate((valid) => {
      //     if (valid) {
      //       alert('submit!');
      //     } else {
      //       console.log('error submit!!');
      //       return false;
      //     }
      //   });
      // },
      resetForm(formName) {
        this.$refs[formName].resetFields();
      },
      abolish(){
        this.$emit('addEvent', false)
      },
      submitForm(){
        this.$emit('addEvent', false)
      },
    }
  }
</script> 
<style lang="scss">
  
  
</style>
<style>
  .add-dialog{
    text-align: right;
  }  
  .from-k .el-form-item{
    width: 100%;
    display: flex;
  }
  .from-k .el-form-item__content{
    flex: 1;
    max-width: 70%;
  }
   
</style>