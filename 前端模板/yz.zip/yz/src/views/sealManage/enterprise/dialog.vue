<template>
  <el-dialog
    :title="title"
    :visible.sync="dialogVisible"
    width="60%"
    :before-close="handleClose">
    <slot name="content"></slot>
    <slot name='proviewImg'></slot>
    <!-- <span slot="footer" class="dialog-footer add-btn-box">
      <el-button type="small" class="cancel-cls" @click="abolish">取 消</el-button>
      <el-button type="small" >确 定</el-button>
    </span> -->
  </el-dialog>
</template>

<script>
  export default {
    props:['addData'],
    data() {
      return {
        dialogVisible: false,
        title:'新增',
        width:'60%'
      };
    },
    created() {
      this.dialogVisible = this.addData;
    },
    methods: {
      handleClose(done) {
        this.$confirm('确认关闭？')
          .then(_ => {
            this.$emit('cancelEven',false)
            done();
          })
          .catch(_ => {});
      },
      abolish(){
        this.$emit('cancelEven',false)
      },
    }
  }
</script>

<style lang="scss" scoped>

</style>
<style>
.el-dialog__footer{ /* 弹窗样式 */
  padding: 0 20px 16px;
}
.el-dialog__body{
  padding: 10px;
}
</style>