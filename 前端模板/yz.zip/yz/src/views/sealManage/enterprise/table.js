
var changPageSizeNum = { // 一共多少数据
  type: false,
  total: 1000
}
export function btnconfig() {
  const btn = {
    title: '操作',
    width: '180',
    btnlist: [
      {
        con: '详情',
        type: 'success',
        size: 'mini'
        // style:{//内联样式
        //   backgroundColor:'red',
        //   borderColor:'red'
        // },
        // className: "defaultBtn"//使用需要引入 new-elment-ui.scss文件 背景颜色
      },
      {
        con: '删除',
        type: 'success',
        size: 'mini'
        // className: "defaultBtn"
      }
    ]
  }
  return btn
}

export var titles = [
  { name: '信息来源', data: 'source' },
  { name: '单位名称', data: 'companyName' },
  { name: '证件类型', data: 'passport' },
  { name: '经办人姓名', data: 'operator' },
  { name: '经办人证件号', data: 'card' },
  { name: '登记时间', data: 'ctime' }
]

export function tabalInfo(data, type) { // 表单数据
  let tableData
  return new Promise((reslove, reject) => {
    // tableData = []
    tableData = [
      {
        source: '本地',
        companyName: '单位',
        passport: '身份证',
        operator: '张三',
        card: '61111111111111',
        ctime: '999999999'
      },
      {
        source: '本地',
        companyName: '单位',
        passport: '身份证',
        operator: '张三',
        card: '61111111111111',
        ctime: '999999999'
      },
      {
        source: '本地',
        companyName: '单位',
        passport: '身份证',
        operator: '张三',
        card: '61111111111111',
        ctime: '999999999'
      }
    ]
    reslove({ changPageSizeNum, tableData })
    // request.post('/seal/agent/listAgents',data).then(res=>{
    //   let data =  res.data.data;
    //   for(let item of data.list){
    //     item.ctime = dateFormat1(item.ctime)
    //   }
    //   tableData=data.list;
    //   changPageSizeNum.total=data.total;
    //   if(type == 'cx'){
    //     changPageSizeNum.type = true;
    //   }else{
    //     changPageSizeNum.type = false;
    //   }
    //   reslove({changPageSizeNum,tableData});
    // })
  })
}

