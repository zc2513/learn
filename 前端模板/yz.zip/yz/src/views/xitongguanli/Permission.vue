<template>
    <div class="pub_main">
        <el-card shadow="always">
            <div class="main_left">
                <el-tree
                    :data="dataTree"
                    :props="defaultProps"
                    :load="loadNode"
                    lazy
                    accordion
                    :highlight-current="true"
                    @current-change="handleNodeClick"
                ></el-tree>
            </div>
            
            <div class="main_right">
                <div class="pub_groupBtn">
                    <el-row>
                        <el-col :span="24"><div class="grid-content bg-purple-light">
                          <div class="add-btn-box">
                            <el-button type="small" class="index-add"   @click="toaddData">新增</el-button>
                          </div>
                        </div></el-col>
                    </el-row>
                </div>
                <div>
                    <!-- 表格 -->
                    <tablePug :msg="tableList" @sendVal="getVal"></tablePug>
                    <!-- <page @pagesend="getPageData" :totalSize="totalSize"></page> -->
                </div>
            </div>
        </el-card>
        <!-- 新增 -->
        <el-dialog title="新增" width="900px" :visible.sync="dialogadd">
            <el-form key="dataadd" :inline="true" class="demo-form-inline" size="small" :rules="rules" ref="ruleForm" :model="addData">
                <el-form-item label="菜单名称" prop="menuName">
                    <el-input v-model="addData.menuName" placeholder="" :clearable="addData.menuName ? true: false"></el-input>
                </el-form-item>
                <el-form-item label="菜单地址" prop="menuAddress">
                    <el-input v-model="addData.menuAddress" placeholder="" :clearable="addData.menuAddress ? true: false"></el-input>
                </el-form-item>
                <el-form-item label="图标" prop="icon">
                    <el-input v-model="addData.icon" placeholder="" :clearable="addData.icon ? true: false"></el-input>
                </el-form-item>
                <el-form-item label="类型" prop="type">
                    <el-select v-model="addData.type" placeholder="" :clearable="addData.type ? true: false">
                        <el-option label="类型一" value="类型一"></el-option>
                        <el-option label="类型二" value="类型二"></el-option>
                    </el-select>
                </el-form-item>
                <el-form-item label="排列顺序">
                    <el-input v-model="addData.order" placeholder="" :clearable="addData.order ? true: false"></el-input>
                </el-form-item>
                <el-form-item label="权限值">
                    <el-input v-model="addData.value" placeholder="" :clearable="addData.value ? true: false"></el-input>
                </el-form-item>
            </el-form>
            <div slot="footer" class="dialog-footer">
                <el-button @click="cancel()" size="small">取 消</el-button>
                <el-button class="btnCss successBtn" type="primary" size="small" @click="submit('ruleForm')">确 定</el-button>
            </div>
        </el-dialog>
        <!-- 修改 -->
        <el-dialog title="修改" width="900px" :visible.sync="dialogupdate">
            <el-form key="dataupdate" :inline="true" class="demo-form-inline" size="small" :rules="rules1" ref="ruleForm" :model="updateData">
                <el-form-item label="菜单名称" prop="menuName">
                    <el-input v-model="updateData.menuName" placeholder="" :clearable="updateData.menuName ? true: false"></el-input>
                </el-form-item>
                <el-form-item label="菜单地址" prop="menuAddress">
                    <el-input v-model="updateData.menuAddress" placeholder="" :clearable="updateData.menuAddress ? true: false"></el-input>
                </el-form-item>
                <el-form-item label="图标" prop="icon">
                    <el-input v-model="updateData.icon" placeholder="" :clearable="updateData.icon ? true: false"></el-input>
                </el-form-item>
                <el-form-item label="类型" prop="type">
                    <el-select v-model="updateData.type" placeholder="" :clearable="updateData.type ? true: false">
                        <el-option label="类型一" value="类型一"></el-option>
                        <el-option label="类型二" value="类型二"></el-option>
                    </el-select>
                </el-form-item>
                <el-form-item label="排列顺序">
                    <el-input v-model="updateData.order" placeholder="" :clearable="updateData.order ? true: false"></el-input>
                </el-form-item>
                <el-form-item label="权限值">
                    <el-input v-model="updateData.value" placeholder="" :clearable="updateData.value ? true: false"></el-input>
                </el-form-item>
            </el-form>
            <div slot="footer" class="dialog-footer">
                <el-button @click="cancel1()" size="small">取 消</el-button>
                <el-button class="btnCss successBtn" type="primary" size="small" @click="submit1('ruleForm')">确 定</el-button>
            </div>
        </el-dialog>
    </div>
</template>
<script>
import tablePug from 'components/Table/tablePlugin'
import page from 'components/Table/page'
import validateFun from '@/utils/validate.js'
// 接口
import { getListPost, addDataPost, updateDataPost, deleteDataPost } from 'api/xitongguanli/permission.js'
export default {
  components: {
    tablePug,
    page
  },
  data() {
    return {
      querydata: {},
      addData: {},
      updateData: {},
      dataTree: [], // 左侧树数据
      defaultProps: {
        children: 'children',
        label: 'label'
      },
      tableList: {
        // 表格所需数据
        tableData: [],
        titles: [],
        // type: true, // 有无选择框 true/false 默认为true
        btnconfig: {
          // ----------------------------按钮项配置/不传则不展示
          title: '操作',
          width: '150', // 按钮项宽度
          btnlist: [
            {
              con: '修改',
              concolor: '#1ab394',
              // backgroundColor: "#fff",
              // icon:'el-icon-check',
              type: 'text',
              size: 'samll'
            },
            {
              con: '删除', // 按钮内容 若果使用内容不使用图标，若使用图标和内容则不建议使用圆形
              concolor: '#f00', // 文字颜色
              // backgroundColor: "#fff", //按钮背景色
              // icon:'el-icon-zoom-in', //使用字体图标为按钮
              circle: false, // 控制按钮是否为圆形   false/true  默认false
              type: 'text', // 按钮模式
              size: 'samll' // 按钮大小medium / small / mini 默认为mini
            }
          ]
        }
      },
      rules: {
        menuName: [{ required: true, message: '菜单名称不能为空', trigger: 'blur' }],
        menuAddress: [{ required: true, message: '菜单地址不能为空', trigger: 'blur' }],
        icon: [{ required: true, message: '图标不能为空', trigger: 'blur' }],
        type: [{ required: true, message: '请选择一个类型', trigger: 'change' }]
      },
      rules1: {
        menuName: [{ required: true, message: '菜单名称不能为空', trigger: 'blur' }],
        menuAddress: [{ required: true, message: '菜单地址不能为空', trigger: 'blur' }],
        icon: [{ required: true, message: '图标不能为空', trigger: 'blur' }],
        type: [{ required: true, message: '请选择一个类型', trigger: 'change' }]
      },
      totalSize: 50,
      dialogdetailed: false, // 详情弹窗状态
      dialogadd: false, // 新增弹窗状态
      dialogupdate: false, // 修改弹窗状态
      dialogVisible: false,
      pidState: null
    }
  },
  mounted() {
    this.initTableData()
  },
  methods: {
    handleNodeClick(data) {
      data.children = []
      this.tableList.tableData = []
      getListPost({ pid: data.id }).then(res => {
        if (res.code == 200) {
          if (res.data.list) {
            for (const ele of res.data.list) {
              // 左侧树数据渲染
              data.children.push({
                label: ele.name,
                id: ele.permissionId,
                children: []
              })
              // 右侧树数据渲染
              this.tableList.tableData.push({
                id: ele.permissionId,
                pid: ele.pid,
                menuName: ele.name,
                menuAddress: 'views/seal/sealquery',
                icon: ele.icon,
                type: ele.type,
                order: ele.orderby
              })
            }
          }
        }
      })
    },
    loadNode(node, resolve) {
      return resolve(node.childNodes)
    },
    initTableData() {
      this.dataTree = [{
        label: '菜单管理',
        id: 0,
        children: []
      }]
      this.tableList.tableData = []
      getListPost().then(res => {
        if (res.code == 200) {
          if (res.data.list) {
            for (const ele of res.data.list) {
              // 左侧树数据渲染
              this.dataTree[0].children.push({
                label: ele.name,
                id: ele.permissionId,
                children: []
              })
              // 右侧树数据渲染
              this.tableList.tableData.push({
                id: ele.permissionId,
                pid: ele.pid,
                menuName: ele.name,
                menuAddress: ele.value,
                icon: ele.icon,
                type: ele.type,
                order: ele.orderby
              })
            }
          }
        }
      })
      this.totalSize = 60 // 一共多少数据
      this.tableList.titles = [
        { name: '菜单名称', data: 'menuName' },
        { name: '菜单地址', data: 'menuAddress' },
        { name: '图标', data: 'icon' },
        { name: '类型', data: 'type' },
        { name: '排列顺序', data: 'order' }
      ]
    },
    // 点击某一行或者双击获取的值
    getVal(val) {
        if(val.type == "修改"){
            this.dialogupdate = true;
            this.updateData = val.data;
        }else if(val.type == "删除"){
            this.$confirm('此操作将永久删除该条数据, 是否继续?', '提示', {
                confirmButtonText: '确定',
                cancelButtonText: '取消',
                type: 'warning'
                }).then(() => {
                    deleteDataPost({id:val.data.id}).then(res => {
                        if(res.code == 200){
                            this.$message({
                                type: 'success',
                                message: '删除成功!'
                            });
                            this.initTableData();
                        }
                    })
                    
                }).catch(() => {
                    this.$message({
                        type: 'info',
                        message: '已取消删除'
                    });          
            });
        }
    },
    operate() {
    },
    // 点击后分页参数
    getPageData(params) {
      this.suninfo = params
    },
    // 新增
    toaddData() {
      this.dialogadd = true
    },
    cancel() {
      this.dialogadd = false
    },
    submit(ruleForm) {
      this.$refs[ruleForm].validate(valid => {
        if (valid) {
          var data = {
            icon: this.addData.icon,
            name: this.addData.menuName,
            pid: this.tableList.tableData[0].pid,
            type: 0,
            value: this.addData.value
          }
          addDataPost(data).then(res => {
            if (res.code == 200) {
              this.$message.success("新增成功");
              this.dialogadd = false
              this.initTableData()
              this.addData = {}
            }
          })
        } else {
          return false
        }
      })
    },
    cancel1() {
      this.dialogupdate = false
    },
    submit1(ruleForm) {
      this.$refs[ruleForm].validate(valid => {
        if (valid) {
          var data = {
            permissionId: this.updateData.id,
            icon: this.updateData.icon,
            name: this.updateData.menuName,
            pid: this.tableList.tableData[0].pid,
            type: this.updateData.type,
            value: this.updateData.order
          }
          updateDataPost(data).then(res => {
            if (res.code == 200) {
              this.$message.success("修改成功");
              this.dialogupdate = false
              this.initTableData()
            }
          })
        } else {
          return false
        }
      })
    }
  }
}
</script>

<style lang="scss" scoped>
   @import "../../styles/public.scss";
   .el-card{
       overflow: hidden;
       padding-bottom:2rem;
       .main_left{
           float:left;
            width:18%;
            padding:1rem;
            border:1px solid #ccc;
            height:722px;
            overflow: scroll;
        }
        .main_right{
            float:left;
            padding-left:2%;
            width:80%;
        }
   }
 </style>