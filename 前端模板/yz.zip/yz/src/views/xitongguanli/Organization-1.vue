<template>
  <div class="pub_main">
    <el-card shadow="always">
      <div class="clearfix">
        <div class="main_left bg-purple">
          <el-tree
            :props="defaultProps"
            :load="loadNode"
            :lazy="true"
            accordion
            :highlight-current="true"
            @current-change="handleNodeClick"
          ></el-tree> 
        </div>
        <div class="main_right"> 
          <div class="pub_groupBtn"
            v-if="JSON.parse(this.$store.state.user.users).roles[0]!=='admin'">
            <el-row>
              <el-col :span="24"> 
                <div class="add-btn-box">
                  <el-button type="small" class="index-add"   @click="add">新增</el-button>
                </div>
              </el-col>
            </el-row>
          </div>
          <div>
            <tablePug :msg="tableList" @sendVal="getVal"></tablePug>
          </div>
        </div>
      </div>
    </el-card>  
    <div v-if="addType.state">
      <dialog-view :addData='addType' @cancelEven='getDialog'>
        <div slot="content">
            <add-view @addEvent='getDialog' :pageType='addType'></add-view>
        </div>
      </dialog-view>
    </div>
  </div>
</template>
<script>

/* api */
import { getListPost, deleteDataPost } from "api/xitongguanli/organization.js";
import tablePug from "components/Table/tablePlugin";
import dialogView from "components/dialog/index.vue";
import addView from './Organization/add';
import { btnconfig , titles , tabalInfo} from './Organization/table.js';
export default {
  components: {
    tablePug,
    dialogView,
    addView,
  },
  data() {
    return {
      tableList: {//版本封装问题 修改太多 所以加tableData:[] 是为了去除警告。
          tableData: [],//表格数据
      },//表格数据 
      addType:{
        state:false,
        title:'新增',//弹窗标题
        width:'50%',
        id:null
      },
      defaultProps: {//树形数据结构
        label: "name",
        children: "zones",
        isLeaf: 'leaf',//---是否为叶子节点
      }, 
      treeForData: null, //点击节点后拿到的子节点数据
      treePid:null,
      nowNode:null,
      nowResolve:null,
    };
  },
  created() {
    this.tableList['titles'] =titles; 
    this.tableList['btnconfig'] =btnconfig(this.$store.getters.roles[0]); 
  }, 
  methods: { 
    initData(params, page=0){
      let data = {
        page:page,
        size:10
      }
      if(params){
        data = {...data,...params}
      }
      tabalInfo(data).then(res=>{
        this.treeForData = res
        this.tableList['tableData'] = res
      })
    },
    add(){//---新增
      if(this.treePid){
        this.addType.id=this.treePid;
        this.addType.title='新增';
        this.addType.state=true;
      }else{
        this.$message.info('请选择')
      }
    }, 
    getVal(data) {//---表格按钮
      if (data.type === "修改") {
          this.addType.title='修改';
          this.addType['organizationId']=data.data.organizationId;
          this.addType.state=true;
      } 
      if (data.type.trim() === "删除") {
        this.deleteDataFun(data.data.organizationId);
      }
    },  
    searchData() {//---查询
      this.initData(this.searchForm)
    },
    deleteDataFun(id) {//--- 删除数据方法
      this.$confirm("此操作将永久删除该改数据, 是否继续?", "提示", {
        confirmButtonText: "确定",
        cancelButtonText: "取消",
        type: "warning"
      }).then(() => {
          deleteDataPost({ id: id }).then(res => {
            if (res.code === 200) {
              this.$message.success("删除成功!");
              this.initData({ pid: this.treePid }) 
              this.loadNode(this.nowNode,this.nowResolve)
            }
          });
        }).catch(() => {
          this.$message({
            type: "info",
            message: "已取消删除"
          });
        });
    }, 
    // 树形控件 ----------------------------------------------------------------------------------------------
    handleNodeClick(data) {
      this.treePid = data.id;
      this.initData({ pid: data.id }) 
    },
    loadNode(node, resolve) {//初始化与动态数据添加数据
      this.nowNode=node
      this.nowResolve=resolve
      if (node.level === 0) {
        let {organization_name:name, fullcode:code, organization_id:id, brevitycode:jmcode} = JSON.parse(this.$store.state.user.users);
        return resolve([{ name, code, id, jmcode}]);
      }
      if (node.level > 0) {
        let arr = [];
        setTimeout(() => {
          if (this.treeForData) {
            for (const ele of this.treeForData) {
              if(node.level == 2){
                arr.push({
                  name: ele.name,
                  id: ele.organizationId,
                  code: ele.fullcode,
                  jmcode: ele.brevitycode,
                  leaf:true
                });
              }else{
                arr.push({
                  name: ele.name,
                  id: ele.organizationId,
                  code: ele.fullcode,
                  jmcode: ele.brevitycode
                });
              }
            }
          } else {
            arr = [];
          }
          return resolve(arr);
        }, 300);
      } 
    },
    getDialog(state){//新增弹窗的状态
      if(!state) {
        this.initData({ pid: this.treePid })
        this.loadNode(this.nowNode,this.nowResolve)
      };
      this.addType.state=state
    }, 
  }
};
</script>
<style lang="scss" scoped>
@import "../../styles/public.scss";
.pub_groupBtn {
  margin-top: 10px;
} 
.el-card {
  overflow: hidden;
  .main_left {
    float: left;
    width: 18%;
    padding: 1rem;
    border: 1px solid #ccc;
    min-height: 10rem;
  }
  .main_right {
    float: left;
    padding-left: 2%;
    width: 80%;
  }
}
.bg-purple {
  height: 722px;
  overflow: scroll;
  border: 1px solid #ebeef5;
}
</style>
