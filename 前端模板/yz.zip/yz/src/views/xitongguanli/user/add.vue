<template>
<!-- 人员管理新增 -->
  <div class='new-add' >
    <el-form :model="ruleForm" 
      :rules="rules" 
      ref="ruleForm" 
      label-width="80px" 
      :inline="true" 
      size="small" 
      class="from-k"
      >
      <el-row :gutter="8">
        <el-col :sm="24" :lg="12">
          <el-form-item label="姓名" prop="realname">
            <el-input v-model="ruleForm.realname"      ></el-input>
          </el-form-item>
        </el-col>
        <el-col :sm="24" :lg="12">
          <el-form-item label="登录名" prop="username">
            <el-input v-model="ruleForm.username" ></el-input>
          </el-form-item>
        </el-col> 
        <el-col :sm="24" :lg="12">
          <el-form-item label="用户类型" prop="roleid" >
              <el-select v-model="ruleForm.roleid" placeholder="请选择">
                <el-option
                  v-for="item in userType"
                  :key="item.code"
                  :label="item.name"
                  :value="item.code">
                </el-option>
              </el-select>
          </el-form-item>
        </el-col>  
      </el-row> 
    </el-form>
    <div class="add-btn-box add-dialog">
      <el-button type="small" class="cancel-cls" @click="abolish">取 消</el-button>
      <el-button type="small" @click="submitForm('ruleForm')">确 定</el-button>
    </div>
  </div>
</template>
<script>
  import { addUserPost } from 'api/xitongguanli/user.js'
import { getUserListPost } from 'api/xitongguanli/user.js'
  import validateFun from '@/utils/validate.js'
  export default {
    props: ['pageType'],
    data() {
      return {
        ruleForm: {
          // realname: '测试' + parseInt(Math.random() * 100),
          // username: ((new Date()).getTime() + '').substr(0, 11),
          roleid: null, // 用户类型
          realname: null,//用户名
          username: null,//用户联系方式
          roleid: null,//用户类型
        },
        rules: {
          realname: [
            { required: true, message: '请输入名称', trigger: 'blur' }
          ],
          username: [
            { required: true, message: '请输入联系方式', trigger: 'blur' },
            { validator: validateFun.phoneVerification, trigger: 'blur' }
          ],
          roleid: [
            { required: true, message: '请选择用户类型', trigger: 'change' }
          ]
        },
        userType: null
      }
    },
    created() {
      if (this.pageType.title == '修改') this.init()
      this.userType = JSON.parse(this.$store.state.user.dicData)['用户类型']
    },
    methods: {
      init() {
        getUserListPost({ username: this.pageType.username }).then(res => {
          if (res.message == 'SUCCESS') {
            const { realname, username, roleid, gxdwbm } = res.data[0]
            this.ruleForm = { realname, username, roleid, gxdwbm }
          }
        })
      },
      submitForm(formName) {
        this.$refs[formName].validate((valid) => {
          if (valid) {
            let data, uri
            if (this.pageType.title == '修改') {
              uri = '/sys/user/update'
              data = Object.assign({}, this.ruleForm, { userId: this.pageType.id })
            } else {
              uri = '/sys/user/addYunzhang'
              data = Object.assign({}, this.ruleForm, { gxdwbm: this.pageType.id, qybm: JSON.parse(this.$store.state.user.users).qybm })
            }
            addUserPost(data, uri).then(res => {
              if (res.message == 'SUCCESS') {
                if (res.code == 200 && res.message == 'SUCCESS') {
                  this.$message.success('操作成功')
                  this.$emit('addEvent', false)
                } else {
                  this.$message.error('操作失败')
                }
              }
            })
          } else {
            return false
          }
        })
      },
      resetForm(formName) { // ---重置
        this.$refs[formName].resetFields()
      },
      abolish() {
        this.$emit('addEvent', false)
      }
    }
  }
</script>  
<style>
  .add-dialog{
    text-align: right;
  }  
  .new-add .el-input,.new-add .el-select,.new-add .el-cascader{
    width: 100% !important;
  } 
</style>