/* eslint-disable no-undef */
/* eslint-disable no-unused-vars */
/* eslint-disable no-empty */
// 企业管理表格数据
import { getUserListPost } from 'api/xitongguanli/user.js'
import { dateFormat } from '@/utils/tools.js'
var changPageSizeNum = { // 一共多少数据
  type: false,
  total: 0
}
export function btnconfig(vue) {
  const btn = {
    title: '操作',
    width: '180',
    btnlist: [
      {
        con: '修改',
        type: 'success',
        size: 'mini'
      },
      {
        con: '删除',
        type: 'success',
        size: 'mini'
      }
    ]
  }
  if (vue === 'admin') {
    btn.btnlist[0].con = '重置密码'
  }
  return btn
}
export var titles = [
  { name: '姓名', data: 'realname' },
  { name: '登录名', data: 'username' },
  { name: '登记时间', data: 'addtime' }
]

export function tabalInfo(data) { // 表单数据
  let tableData = []
  return new Promise((reslove, reject) => {
    getUserListPost(data).then(res => {
      if (res.message === 'SUCCESS') {
        const data = res.data
        if (data) {
          for (const item of data) {
            item.addtime = dateFormat(item.addtime)
          }
        }
        tableData = data || []
        changPageSizeNum.total = data.length || 0
        reslove({ changPageSizeNum, tableData })
      } else {
        reject(res)
      }
    })
  })
}
