<template>
  <div class="pub_main">
    <el-card shadow="always">
      <div class="pub_groupBtn">
        <el-row>
          <el-col :span="24"> 
            <div class="add-btn-box">
              <el-button type="small" class="index-add"   @click="openDialog">新增</el-button>
            </div>
          </el-col>
        </el-row>
      </div>
      <div>
        <tablePug :msg="tableList" @sendVal="getVal"></tablePug>
        <page @pagesend="getPageData" :changPageSize="changPageSizeNum" :pageSizeNum="pageSize"></page>
      </div>
      <div>
        <el-dialog
          title="新增"
          width="900"
          @close="exitAddDialog"
          :close-on-click-modal="false"
          :visible.sync="addDialog"
          class="add_dialog"
        >
          <el-form
            :inline="true"
            :model="roleAdd"
            class="demo-form-inline"
            size="small"
            label-width="80px"
            label-position="right"
            :rules="rules"
            ref="ruleForm"
          >
            <el-form-item label="角色名称" prop="name">
              <el-input
                type="text"
                v-model.trim="roleAdd.name"
                :clearable="roleAdd.name ? true: false"
              ></el-input>
            </el-form-item>
            <el-form-item label="角色描述" prop="description">
              <el-input
                type="text"
                v-model.trim="roleAdd.description"
                :clearable="roleAdd.description ? true: false"
              ></el-input>
            </el-form-item>
          </el-form>
          <div slot="footer" class="dialog-footer">
            <el-button @click="exitAddDialog" size="small">取 消</el-button>
            <el-button
              class="btnCss successBtn"
              type="primary"
              size="small"
              @click="submitForm('ruleForm')"
            >确 定</el-button>
          </div>
        </el-dialog>
      </div>
      <div>
        <el-dialog
          title="权限配置"
          width="900"
          @close="onSubmitAccessConfiguration"
          :close-on-click-modal="false"
          :visible.sync="dialogAccessConfiguration"
        >
          <el-form
            :inline="true"
            :model="accessConfiguration"
            class="demo-form-inline"
            size="small"
            label-width="80px"
            label-position="right"
            :rules="rules"
            ref="ruleForm"
          >
            <el-tree
              :data="data2"
              show-checkbox
              default-expand-all
              :default-expanded-keys="defaultType"
              :default-checked-keys="initCheckedType"
              node-key="id"
              ref="tree"
              highlight-current
              :props="defaultProps"
            ></el-tree>
          </el-form>
          <div slot="footer" class="dialog-footer">
            <el-button @click="onSubmitAccessConfiguration" size="small">取 消</el-button>
            <el-button class="btnCss successBtn" type="primary" size="small" @click="jurisdictionSave">确 定</el-button>
          </div>
        </el-dialog>
      </div>
    </el-card>
  </div>
</template>

<script>
import tablePug from "components/Table/tablePlugin";
import page from "components/Table/page";
// 接口
import {
  getRoleListApi,
  getRoleAddApi,
  getRoleDeleteApi,
  getPermissionByRoleApi,
  getPermissionUpdataApi
} from "api/xitongguanli/role.js";
export default {
  components: {
    tablePug,
    page
  },
  data() {
    return {
      addDialog: false,
      dialogAccessConfiguration: false,
      roleAdd: {
        name: null,
        description: null
      },
      roleId: null,
      accessConfiguration: {
        name: "1"
      },
      rules: {
        name: [
          { required: true, message: "请输入角色名称", trigger: "blur" },
          {
            min: 1,
            max: 50,
            message: "录入中英文，长度支持50个字符",
            trigger: "blur"
          }
        ],
        description: [
          { required: true, message: "请输入角色描述", trigger: "blur" },
          {
            min: 1,
            max: 50,
            message: "录入中英文，长度支持50个字符",
            trigger: "blur"
          }
        ]
      },
      data: {
        roleId: null,
        userId: null
      },
      data2: [],
      data3: [],
      defaultProps: {
        children: "children",
        label: "name"
      },
      addDialog: false,
      tableList: {
        // 表格所需数据
        tableData: [],
        titles: [],
        // type: true, // 有无选择框 true/false 默认为true
        btnconfig: {
          // ----------------------------按钮项配置/不传则不展示
          title: "操作",
          width: "250", // 按钮项宽度
          btnlist: [
            {
              con: "权限配置",
              type: "success",
              concolor: "#1ab394",
              backgroundColor: "#fff"
            },
            {
              con: "修改",
              concolor: "#1ab394",
              backgroundColor: "#fff",
              // icon:'el-icon-check',
              type: "primary",
              size: ""
            },
            {
              con: "删除", // 按钮内容 若果使用内容不使用图标，若使用图标和内容则不建议使用圆形
              concolor: "#f00", // 文字颜色
              backgroundColor: "#fff", // 按钮背景色
              // icon:'el-icon-zoom-in', //使用字体图标为按钮
              circle: false, // 控制按钮是否为圆形   false/true  默认false
              type: "primary", // 按钮模式
              size: "" // 按钮大小medium / small / mini 默认为mini
            }
          ]
        }
      },
      initData: [],
      suninfo: "",
      // 数组总数
      changPageSizeNum: {
        type: "",
        data: ""
      },
      pageSize: 1,
      totalData: null,
      initCheckedType: [], // 默认选中权限
      defaultType: [], // 默认展开
      roelSettingData: {
        permissionIds: []
        // 'roleId': null
      },
      userData: null,
      newCheckedList: [],
      // 分页
      pageSizeNum: null
    };
  },
  created() {
    // this.getVal(1);
    this.userData = JSON.parse(this.$store.state.user.users);
  },
  mounted() {
    this.initTableData();
  },
  methods: {
    handleChange(value) {
    },

    initTableData() {
      this.listDataPost({ pid: 0, size: 10, page: 1 });
      this.tableList.titles = [
        { name: "角色名称", data: "name" },
        { name: "角色描述", data: "description" }
      ];
    },
    getVal(val) {
      // this.suninfo = val;
      if (val.type === "权限配置") {
        this.accessConfigurationFun(val.data.roleId);
      }
      if (val.type === "修改") {
        this.roleId = val.data.roleId;
        this.openDialog(val);
        this.roleAdd.name = val.data.name;
        this.roleAdd.description = val.data.description;
      }
      if (val.type === "删除") {
        this.deleteDataFun(val.data.roleId);
      }
    },
    // 分页参数
    getPageData(params) {
      this.pageSizeNum = params;
      if (params === 1) {
        this.tableList.tableData = this.totalData.slice(
          (params - 1) * 10,
          params * 10
        );
      } else {
        this.tableList.tableData = this.totalData.slice(
          (params - 1) * 10,
          params * 10
        );
      }
    },
    // 打开弹窗
    openDialog() {
      if (this.roleId == null) {
        this.addDialog = true;
        this.roleId = null;
        this.roleAdd.name = null;
        this.roleAdd.description = null;
        document.querySelector(".add_dialog .el-dialog__title").innerHTML =
          "新增";
      }
      if (this.roleId != null) {
        this.addDialog = true;
        document.querySelector(".add_dialog .el-dialog__title").innerHTML =
          "修改";
      }
    },
    // 关闭弹框
    exitAddDialog() {
      const title = document.querySelector(".add_dialog .el-dialog__title")
        .innerHTML;
      if (title === "新增") {
        this.$refs.ruleForm.resetFields();
        // this.roleId = null;
        this.addDialog = false;
      }
      if (title === "修改") {
        this.$refs.ruleForm.resetFields();
        this.roleId = null;
        this.roleAdd.name = null;
        this.roleAdd.description = null;
        this.addDialog = false;
      }
    },

    // 确定新增事件
    submitForm(ruleForm) {
      this.$refs[ruleForm].validate(valid => {
        if (valid) {
          const title = document.querySelector(".add_dialog .el-dialog__title")
            .innerHTML;
          const data = this.roleAdd;
          data.roleId = this.roleId;
          let url = null;
          let message = null;
          if (title === "新增") {
            url = "/sys/role/add";
            message = "新增成功";
          }
          if (title === "修改") {
            url = "/sys/role/update";
            message = "修改成功";
            // data.pid = this.typePid
          }
          getRoleAddApi(data, url).then(res => {
            if (res.code === 200) {
              this.$message.success(message);
              this.$refs[ruleForm].resetFields();
              this.addDialog = false;
              this.initTableData();
            }
          });
        } else {
          return false;
        }
      });
    },
    // 删除数据方法
    deleteDataFun(id) {
      this.$confirm("此操作将永久删除该文件, 是否继续?", "提示", {
        confirmButtonText: "确定",
        cancelButtonText: "取消",
        type: "warning"
      })
        .then(() => {
          // let user = JSON.parse(this.$store.state.user.users);
          // this.data.roleId = id;
          // this.data.userId = user.userId;
          // let data = this.data;
          getRoleDeleteApi({ id: id }).then(res => {
            if (res.code === 200) {
              this.$message({
                type: "success",
                message: "删除成功!"
              });
              this.initTableData();
            }
          });
        })
        .catch(() => {
          this.$message({
            type: "info",
            message: "已取消删除"
          });
        });
    },
    // tabel表格数据处理
    listDataPost(param, type) {
      getRoleListApi(param).then(res => {
        if (res.code === 200) {
          this.changPageSizeNum = {
            type: "",
            data: res.data
          };
          this.totalData = res.data.list;
          if (this.pageSizeNum) {
            this.getPageData(this.pageSizeNum);
          } else {
            this.tableList.tableData = res.data.list.slice(0, 10);
          }
        }
      });
    },

    // 权限配置-----↓--------------↓-----------------

    // 取消权限角色设置
    onSubmitAccessConfiguration() {
      this.dialogAccessConfiguration = false;
      this.newCheckedList = [];
    },

    accessConfigurationFun(id) {
      this.newCheckedList = [];
      const user = JSON.parse(this.$store.state.user.users);
      this.data.roleId = id;
      this.data.userId = user.userId;
      const datas = this.data;
      getPermissionByRoleApi(datas).then(res => {
        if (res.code === 200) {
          this.dialogAccessConfiguration = true;
          this.data2 = res.data.treelist;
          // res.data.checked.forEach((item, index) => {
          //    if (item.length == 4) {
          //      this.newCheckedList.push(item)
          //    }
          // })
          let pidArr = [];
          res.data.treelist.forEach(item => {
            if (item.pid === "0") {
              pidArr.push(item.id);
            }
          });
          let checkedArr = res.data.checked;
          checkedArr.forEach((val, index) => {
            pidArr.forEach(ele => {
              if (val === ele) {
                checkedArr.splice(index, 1);
              }
            });
          }); 

          // let checkedArr = res.data.checked;
          for (let i = 0; i < checkedArr.length; i++) {
            for (let j = 0; j < pidArr.length; j++) {
              if (checkedArr[i] === pidArr[j]) {
                checkedArr.splice(i,1);
              }
            }
          }
          this.newCheckedList = checkedArr;
          setTimeout(() => {
            this.$refs.tree.setCheckedKeys(this.newCheckedList);
          }, 100);
        }
        if (res.code == 400) {
          this.$message.warning(res.message);
          return false;
        }
      });
    },

    // 确定权限
    jurisdictionSave() {
      // 获取key值
      // const datainfo = this.$refs.tree.getCheckedNodes().concat(this.$refs.tree.getHalfCheckedNodes());
      const datainfo = this.$refs.tree
        .getCheckedKeys()
        .concat(this.$refs.tree.getHalfCheckedKeys());

      // datainfo.forEach((item, index) => {
      //   this.roelSettingData.permissionIds.push(item.id)
      // })
      // const roelDatas = this.roelSettingData.permissionIds
      const role_Id = this.data.roleId;
      getPermissionUpdataApi({
        permissionIds: datainfo,
        roleId: role_Id
      }).then(res => {
        if (res.code == 200) {
          this.$message.success("权限配置成功！");
          this.dialogAccessConfiguration = false;
          this.newCheckedList = [];
          this.initTableData();
        }
        if (res.code == 400) {
          this.$message.warning("权限配置失败！");
          return false;
        }
      });
    }
  }
};
</script>

<style lang="scss" scoped>
@import "../../styles/public.scss";
</style>