 <template>
   <div>
     <el-card >
        <div class="search_box">
            <el-form :inline="true" :model="searchForm"   class="demo-dynamic" size="small">
              <el-form-item label='单位名称:'>
                <el-input v-model="searchForm.dwmc" placeholder="请输入..."></el-input>
              </el-form-item>
              <el-form-item label='统一社会信用代码:'>
                <el-input v-model="searchForm.tyshxydm" placeholder="请输入..."></el-input>
              </el-form-item> 
              <el-form-item label>
                <el-date-picker
                  v-model="searchFormTm"
                  type="daterange"
                  range-separator="~"
                  value-format='yyyy-MM-dd HH:mm:ss'
                  :default-time="['00:00:00', '23:59:59']"
                  start-placeholder="开始日期"
                  end-placeholder="结束日期"
                ></el-date-picker>
                <el-button  @click="searchCompanyFun">查询</el-button>
              </el-form-item> 
            </el-form>
          </div> 
          <div class="add-btn-box">
            <el-button type="small" class="index-add" @click="add">新增</el-button>
          </div>
          <div class="table_box">
            <public-table :msg="tableList" @sendVal="getBtnDataFun"></public-table>
            <public-page @pagesend="getPageSizeFun" :changPageSize="changPageSizeNum"></public-page>
          </div>
      </el-card>
      <div v-if="addType.state">
        <dialog-view :addData='addType' @cancelEven='getDialog'>
          <div slot="content">
              <add-view @addEvent='getDialog'></add-view>
          </div>
        </dialog-view>
      </div>
   </div>
 </template>
 
 <script>
import publicTable from "components/Table/tablePlugin";
import publicPage from "components/Table/page";
import dialogView from "components/dialog/index.vue";
import addView from './add';
import { deleteTableData } from 'api/xitongguanli/enterprise.js'
import { btnconfig , titles , tabalInfo} from './table.js';
   export default {
     components:{
       publicTable,
       publicPage,
       dialogView,
       addView
     },
     data(){
       return{
          searchForm:{
            dwmc:null,
            tyshxydm:null,
            djsjks:null,
            djsjjs:null,
          },
          tableList: {//版本封装问题 修改太多 所以加tableData:[] 是为了去除警告。
              tableData: [],//表格数据
          },//表格数据
          changPageSizeNum: {},
          searchFormTm:null,
          addType:{
            state:false,
            title:'新增',//弹窗标题
          }
       }
     },
     created() {
        this.tableList['titles'] =titles; 
        this.tableList['btnconfig'] =btnconfig();  
        this.initData()
     },
     methods: {
       initData(params, page=0){
         let data = {
           page:page,
           size:10
         }
         if(params){
           data = {...data,...params}
         }
         tabalInfo(data).then(res=>{
           this.changPageSizeNum = res.changPageSizeNum
           this.tableList['tableData'] = res.tableData
         })
       },
       getBtnDataFun(val){
         if(val.type == '删除'){
            this.$confirm('此操作将永久删除, 是否继续?', '提示', {
              confirmButtonText: '确定',
              cancelButtonText: '取消',
              type: 'warning'
            }).then(() => {
              this.deleteTableData(val.data.id)
            }).catch(() => {
              this.$message.info( '已取消' );
            })
         } 
       },
       deleteTableData(id){
         deleteTableData({id:id}).then(res=>{
           if(res.code == 200 && res.message == "SUCCESS"){
             for(let i = 0; this.tableList.tableData.length; i++){
               let item = this.tableList.tableData[i];
               if(item.id = id){
                 this.tableList.tableData.splice(i,1)
                 break
               }
             }
             if(this.tableList.tableData.length == 0){ 
               this.initData(this.searchForm,this.nowPage-1)
             }
             this.$message.success('操作成功')
           }else{ 
             this.$message.error('操作失败')
           }
         })
       },
       getPageSizeFun(page){//翻页
         this.nowPage = page
         this.initData(this.searchForm,page)
       },
       searchCompanyFun(){
          this.searchForm.djsjks = this.searchFormTm ? this.searchFormTm[0] : null;
          this.searchForm.djsjjs = this.searchFormTm ? this.searchFormTm[1] : null;
          this.changPageSizeNum.type= true
          this.initData(this.searchForm)
       },
       add(){//---新增
         this.addType.state=true;
       },
       getDialog(state){//新增弹窗的状态
         if(!state) this.initData();
         this.addType.state=state
       }, 
     },
   }
 </script>
 
 <style lang="scss" scoped>
 
 </style>