<template>
  <div>
    <el-form :model="ruleForm" 
      :rules="rules" 
      ref="ruleForm" 
      label-width="120px" 
      :inline="true" 
      size="small" 
      class="from-k"
      >
      <el-row :gutter="8">
        <el-col :sm="24" :lg="12">
          <el-form-item label="单位名称" prop="dwmc">
            <el-input v-model="ruleForm.dwmc"      ></el-input>
          </el-form-item>
        </el-col>
        <el-col :sm="24" :lg="12">
          <el-form-item label="法人姓名" prop="fddbr">
            <el-input v-model="ruleForm.fddbr" ></el-input>
          </el-form-item>
        </el-col> 
        <!-- <el-col :sm="24" :lg="12">
          <el-form-item label="单位编号" prop="dwbm">
            <el-input v-model="ruleForm.dwbm" ></el-input>
          </el-form-item>
        </el-col>  -->
        <el-col :sm="24" :lg="12">
          <el-form-item label="证件号码" prop="frzjhm">
            <el-input v-model="ruleForm.frzjhm" ></el-input>
          </el-form-item>
        </el-col> 
        <el-col :sm="24" :lg="12">
          <el-form-item label="单位地址" prop="dwdz">
            <el-input v-model="ruleForm.dwdz"></el-input>
          </el-form-item>
        </el-col> 
        <el-col :sm="24" :lg="12">
          <el-form-item label="联系电话" prop="frlxfs">
            <el-input v-model="ruleForm.frlxfs"></el-input>
          </el-form-item>
        </el-col> 
        <el-col :sm="24" :lg="12"> 
          <el-form-item label="社会信用代码" prop="tyshxydm">
            <el-input v-model="ruleForm.tyshxydm" ></el-input>
          </el-form-item>
        </el-col>
        <el-col :sm="24" :lg="12">
          <el-form-item label="备注">
            <el-input v-model="ruleForm.bz"></el-input>
          </el-form-item>
        </el-col>   
      </el-row> 
    </el-form>
    <div class="add-btn-box add-dialog">
      <el-button type="small" class="cancel-cls" @click="abolish">取 消</el-button>
      <el-button type="small" @click="submitForm('ruleForm')">确 定</el-button>
    </div>
  </div>
</template>
<script>
  import { postAdd } from 'api/xitongguanli/enterprise.js'
  import validateFun from '@/utils/validate.js'
  export default {
    data() {
      return {
        ruleForm: {
          // dwmc: '随机发的' + parseInt(Math.random() * 1000),
          // dwbm: '61514589122315484',
          // dwdz: '测试地址',
          // tyshxydm: '435343543545454545',
          // fddbr: '张萨姆',
          // frlxfs: '1522222' + parseInt(Math.random() * 10000),
          // frzjhm: '231003198301269820',
          // bz: '备注测试'
          dwmc: null ,
          dwbm: null ,
          dwdz: null ,
          tyshxydm: null ,
          fddbr: null ,
          frlxfs: null ,
          frzjhm:null,
          bz: null 
        },
        rules: {
          dwmc: [
            { required: true, message: '请输入单位名称', trigger: 'blur' }
          ],
          dwbm: [
            { required: true, message: '请输入单位编码', trigger: 'blur' },
            { min: 15, max: 18, message: '长度在 15 到 18 个字符', trigger: 'blur' }
          ],
          fddbr: [
            { required: true, message: '请输入姓名', trigger: 'blur' },
            { min: 2, max: 8, message: '长度在 2 到 8 个字符', trigger: 'blur' }
          ],
          frzjhm: [
            { required: true, message: '请输入法人身份证号码', trigger: 'blur' },
            { min: 18, max: 18, message: '长度为18 个字符', trigger: 'blur' },
            { validator: validateFun.IDcardVerification, trigger: 'blur' }
          ],
          frlxfs: [
            { required: true, message: '请输入法人联系方式', trigger: 'blur' },
            { validator: validateFun.phoneVerification, trigger: 'blur' }
          ],
          dwdz: [
            { required: true, message: '请输入单位地址', trigger: 'blur' },
            { validator: validateFun.checkRate }
          ],
          tyshxydm: [
            { required: true, message: '请输入统一社会信用代码', trigger: 'blur' },
            { min: 15, max: 18, message: '长度在 15 到 18 个字符', trigger: 'blur' },
            { validator: validateFun.unifyTheSocialCreditCodeVerification, trigger: 'blur' }
          ]
        }
      }
  },
    methods: {
      submitForm(formName) {
        this.$refs[formName].validate((valid) => {
          if (valid) {
            postAdd(this.ruleForm).then(res => {
              if (res.code == 200 && res.message == 'SUCCESS') {
                this.$message.success('操作成功')
                this.$emit('addEvent', false)
              }else {
                this.$message.success('操作失败')
              }
            })
          } else {
            return false
        }
        })
    },
      resetForm(formName) {
        this.$refs[formName].resetFields()
    },
      abolish() {
        this.$emit('addEvent', false)
      }
    }
  }
</script>  
<style>
  .add-dialog{
    text-align: right;
  }  
  .from-k .el-form-item{/* 输入框自适应大小 */
    box-sizing: border-box;
    width: 100%;
    display: flex;
  }
  .from-k .el-form-item__content{
    box-sizing: border-box;
    flex: 1;
    max-width: 70%;
  }
  .from-k .el-input--small .el-input__inner {
    min-height: 34px;
  }
</style>