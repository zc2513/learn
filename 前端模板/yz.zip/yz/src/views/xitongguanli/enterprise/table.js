/* eslint-disable no-undef */
/* eslint-disable no-unused-vars */
/* eslint-disable no-empty */
// 企业管理表格数据
import { getList } from 'api/xitongguanli/enterprise.js'
import { dateFormat } from '@/utils/tools.js'
var changPageSizeNum = { // 一共多少数据
  type: false,
  total: 0
}
export function btnconfig() {
  const btn = {
    title: '操作',
    // width: '180',
    btnlist: [
      {
        con: '删除',
        type: 'success',
        size: 'mini'
      }
    ]
  }
  return btn
}

export var titles = [
  { name: '统一社会信用代码', data: 'tyshxydm' },
  { name: '单位名称', data: 'dwmc' },
  { name: '法人姓名', data: 'fddbr' },
  { name: '法人证件号', data: 'frzjhm' },
  { name: '法人联系方式', data: 'frlxfs' },
  { name: '登记时间', data: 'djsj' }
]

export function tabalInfo(data) { // 表单数据
  let tableData = []
  return new Promise((reslove, reject) => {
    getList(data).then(res => {
      if (res.message === 'SUCCESS') {
        const data = res.data
        if (data.list) {
          for (const item of data.list) {
            item.djsj = dateFormat(item.djsj)
          }
        }
        tableData = data.list || []
        changPageSizeNum.total = data.total || 0
        reslove({ changPageSizeNum, tableData })
      } else {
        reject(res)
      }
    })
  })
}
