<template>
  <div class="pub_main">
    <el-card shadow="always">
      <div class="clearfix">
        <div class="main_left bg-purple">
          <el-tree
            :props="defaultProps"
            :load="loadNode"
            lazy
            accordion
            :highlight-current="true"
            @current-change="handleNodeClick"
          ></el-tree> 
        </div>
        <div class="main_right">
          <div class="searchBox">
            <el-form :inline="true" :model="searchForm" class="demo-form-inline" size="small">
              <el-form-item label="姓名">
                <el-input v-model.trim="searchForm.realname" :clearable="searchForm.username?true:false" placeholder></el-input>
              </el-form-item>
              <el-form-item label="联系方式">
                <el-input v-model.trim="searchForm.username" :clearable="searchForm.phone?true:false" placeholder></el-input>
              </el-form-item>
              <el-form-item>
                <el-button  size="small" @click="searchData">查询</el-button>
              </el-form-item>
            </el-form>
          </div>
          <div class="pub_groupBtn"
            v-if="JSON.parse(this.$store.state.user.users).roles[0]!=='admin'">
            <el-row>
              <el-col :span="24"> 
                <div class="add-btn-box">
                  <el-button type="small" class="index-add"   @click="add">新增</el-button>
                </div>
              </el-col>
            </el-row>
          </div>
          <div>
            <tablePug :msg="tableList" @sendVal="getVal"></tablePug>
          </div>
        </div>
      </div>
    </el-card>  
    <div v-if="addType.state">
      <dialog-view :addData='addType' @cancelEven='getDialog'>
        <div slot="content">
            <add-view @addEvent='getDialog' :pageType='addType'></add-view>
        </div>
      </dialog-view>
    </div>
  </div>
</template>
<script>

/* api */
import { deleteUserPost, resetPasswordPost } from 'api/xitongguanli/user.js'
import { getListPost } from 'api/xitongguanli/organization.js'
import tablePug from 'components/Table/tablePlugin'
import dialogView from 'components/dialog/index.vue'
import addView from './user/add'
import { btnconfig, titles, tabalInfo } from './user/table.js'
export default {
  components: {
    tablePug,
    dialogView,
    addView
  },
  data() {
    return {
      tableList: {// 版本封装问题 修改太多 所以加tableData:[] 是为了去除警告。
        tableData: [] // 表格数据
      }, // 表格数据
      searchForm: {
        username: null,
        realname: null,
        gxdwbm: null// //当前被点击的选项Id
      },
      addType: {
        state: false,
        title: '新增', // 弹窗标题
        width: '50%',
        id: null
      },
      defaultProps: {// 树形数据结构
        label: 'name',
        children: 'zones',
        isLeaf: 'leaf' // ---是否为叶子节点
      },
      treeForData: null // 点击节点后拿到的子节点数据
    }
  },
  created() {
    this.tableList['titles'] = titles
    this.tableList['btnconfig'] = btnconfig(this.$store.getters.roles[0])
  },
  methods: {
    initData(params, page = 0) {
      let data = {
        page: page,
        size: 10
      }
      if (params) {
        data = { ...data, ...params }
      }
      tabalInfo(data).then(res => {
        this.tableList['tableData'] = res.tableData
      })
    },
    add() { // ---新增
      if (this.searchForm.gxdwbm) {
        this.addType.id = this.searchForm.gxdwbm
        this.addType.title = '新增'
        this.addType.state = true
      } else {
        this.$message.info('请选择部门')
      }
    },
    getVal(data) { // ---表格按钮
      if (data.type === '修改') {
        this.addType.title = '修改'
        this.addType.id = data.data.userId
        this.addType['username'] = data.data.username
        this.addType.state = true
      }
      if (data.type.trim() === '重置密码') {
        this.resetPasswordFun(data.data.userId)
      }
      if (data.type.trim() === '删除') {
        this.deleteDataFun(data.data.userId)
      }
    },
    searchData() { // ---查询
      if (this.searchForm.gxdwbm) {
        this.initData(this.searchForm)
      } else {
        this.$message.info('请选择部门')
      }
    },
    deleteDataFun(id) { // --- 删除数据方法
      this.$confirm('此操作将永久删除该改数据, 是否继续?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }).then(() => {
        deleteUserPost({ id: id }).then(res => {
          if (res.code === 200) {
            this.$message.success('删除成功!')
            this.initData(this.searchForm)
          }
        })
      }).catch(() => {
        this.$message({
          type: 'info',
          message: '已取消删除'
        })
      })
    },
    resetPasswordFun(id) { // ----密码重置
      this.$confirm('此操作将重置密码, 是否继续?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }).then(() => {
        resetPasswordPost({ id: id }).then(res => {
          if (res.code === 200) {
            this.$message.success('重置成功!')
            this.initData(this.searchForm)
          }
        })
      }).catch(() => {
        this.$message({
          type: 'info',
          message: '已取消重置'
        })
      })
    },
    // 树形控件 ----------------------------------------------------------------------------------------------
    handleNodeClick(data) {
      getListPost({ pid: data.id }).then(res => {
        if (res.code === 200) {
          this.treeForData = res.data.list
        }
      })
      this.searchForm.gxdwbm = data.id
      this.initData(this.searchForm)
    },
    loadNode(node, resolve) { // 初始化与动态数据添加数据
      if (node.level === 0) {
        const { organization_name: name, fullcode: code, organization_id: id, brevitycode: jmcode } = JSON.parse(this.$store.state.user.users)
        return resolve([{ name, code, id, jmcode }])
      }
      if (node.level > 0) {
        let arr = []
        setTimeout(() => {
          if (this.treeForData) {
            for (const ele of this.treeForData) {
              if (node.level == 2) {
                arr.push({
                  name: ele.name,
                  id: ele.organizationId,
                  code: ele.fullcode,
                  jmcode: ele.brevitycode,
                  leaf: true
                })
              } else {
                arr.push({
                  name: ele.name,
                  id: ele.organizationId,
                  code: ele.fullcode,
                  jmcode: ele.brevitycode
                })
              }
            }
          } else {
            arr = []
          }
          return resolve(arr)
        }, 300)
      }
    },
    getDialog(state) { // 新增弹窗的状态
      if (!state) this.initData(this.searchForm)
      this.addType.state = state
    }
  }
}
</script>
<style lang="scss" scoped>
@import "../../styles/public.scss";
.pub_groupBtn {
  margin-top: 10px;
} 
.el-card {
  overflow: hidden;
  .main_left {
    float: left;
    width: 18%;
    padding: 1rem;
    border: 1px solid #ccc;
    min-height: 10rem;
  }
  .main_right {
    float: left;
    padding-left: 2%;
    width: 80%;
  }
}
.bg-purple {
  height: 722px;
  overflow: scroll;
  border: 1px solid #ebeef5;
}
</style>
