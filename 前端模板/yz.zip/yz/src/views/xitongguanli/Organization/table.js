
// 部门管理表格数据
import { getListPost } from 'api/xitongguanli/organization.js'
export function btnconfig(vue) {
  const btn = {
    title: '操作',
    width: '180',
    btnlist: [
      {
        con: '修改',
        type: 'success',
        size: 'mini'
      },
      {
        con: '删除',
        type: 'success',
        size: 'mini'
      }
    ]
  }
  if (vue === 'admin') {
    // btn.btnlist = [{
    //   con: '详情',
    //   type: 'success',
    //   size: 'mini'
    // }]
    btn.btnlist = []
  }
  return btn
}
export var titles = [
  { name: '名称', data: 'name' },
  { name: '描述', data: 'description' }
]

export function tabalInfo(data) { // 表单数据
  let tableData = []
  return new Promise((reslove, reject) => {
    getListPost(data).then(res => {
      if (res.message === 'SUCCESS') {
        const data = res.data.list
        tableData = data || []
        reslove(tableData)
      } else {
        reject(res)
      }
    })
  })
}
