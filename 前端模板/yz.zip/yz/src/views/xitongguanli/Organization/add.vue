<template>
<!-- 部门管理新增 -->
  <div class='new-add' >
    <el-form :model="ruleForm" 
      :rules="rules" 
      ref="ruleForm" 
      label-width="80px" 
      :inline="true" 
      size="small" 
      class="from-k"
      >
      <el-row :gutter="8">
        <el-col :sm="24" :lg="12">
          <el-form-item label="名称" prop="name">
            <el-input v-model="ruleForm.name"      ></el-input>
          </el-form-item>
        </el-col>
        <el-col :sm="24" :lg="12">
          <el-form-item label="描述" prop="description">
            <el-input v-model="ruleForm.description" ></el-input>
          </el-form-item>
        </el-col>  
      </el-row> 
    </el-form>
    <div class="add-btn-box add-dialog">
      <el-button type="small" class="cancel-cls" @click="abolish">取 消</el-button>
      <el-button type="small" @click="submitForm('ruleForm')">确 定</el-button>
    </div>
  </div>
</template>
<script>
  import { addupDataPost, detailDataPost } from "api/xitongguanli/organization.js";
  import { getUserListPost } from 'api/xitongguanli/user.js'
  import validateFun  from '@/utils/validate.js'
  export default {
    props:['pageType'],
    data() { 
      return {
        ruleForm: {  
          // name:'测试'+parseInt(Math.random()*100),
          // description:((new Date()).getTime()+'').substr(0,11),
          name:null,//名称
          description:null//描述
        }, 
        rules: {
          name: [
            { required:true ,   message: '请输入名称', trigger: 'blur' },
          ],
          description: [
            { required:true ,   message: '请输入描述内容', trigger: 'blur' },
          ],
        },
      }
    },
    created() {
      if(this.pageType.title == '修改') this.init();
    },
    methods: {
      init(){
        detailDataPost({id:this.pageType.organizationId}).then(res=>{
          if(res.message == "SUCCESS"){
            this.ruleForm = res.data 
            console.log(res.data)
          } 
        })
      }, 
      submitForm(formName) {
        this.$refs[formName].validate((valid) => {
          if (valid) {
            let data,uri  
            if(this.pageType.title == '修改') {
              uri = '/sys/organization/update'
              data = this.ruleForm
            }else{
              uri = '/sys/organization/add';
              data = Object.assign({},this.ruleForm,{pid:this.pageType.id})
            }
            addupDataPost(data,uri).then(res=>{
              if(res.message=="SUCCESS"){
                  if(res.code == 200 && res.message == "SUCCESS"){
                    this.$message.success('操作成功')
                    this.$emit('addEvent', false)
                  }else{
                    this.$message.success('操作失败')
                  }
              }
            }) 
          } else {
            return false;
          }
        });
      },
      resetForm(formName) {// ---重置
        this.$refs[formName].resetFields();
      },
      abolish(){
        this.$emit('addEvent', false)
      }, 
    }
  }
</script>  
<style>
  .add-dialog{
    text-align: right;
  }  
  .new-add .el-input,.new-add .el-select,.new-add .el-cascader{
    width: 100% !important;
  } 
</style>