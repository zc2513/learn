<template>
    <div class="pub_main">
        <el-card shadow="always">
            <div class="pub_groupBtn">
                <el-row>
                    <el-col :span="4">
                        <div class="grid-content bg-purple">
                            <el-tree
                                :props="defaultProps"
                                :load="loadNode1"
                                lazy
                                accordion
                                :highlight-current="true"
                                @current-change="handleNodeClick"
                                @check-change="handleCheckChange"
                            ></el-tree>
                        </div>
                    </el-col>
                    <el-col :span="20">
                      <div class="add-btn-box" style="padding-left:20px;">
                        <el-button type="small" class="index-add"   @click="openDialog">新增</el-button>
                      </div>
                        <div class="grid-content bg-purple-light">
                            <!-- <el-button
                                class="btnCss successBtn"
                                type="primary"
                                @click="openDialog"
                                size="small"
                            >新增</el-button> -->
                            <tablePug :msg="tableList" @sendVal="getVal"></tablePug>
                            <page @pagesend="getPageData" :changPageSize="changPageSizeNum"></page>
                        </div>
                    </el-col>
                </el-row>
            </div>
            <div>
                <el-dialog
                    title="新增"
                    width="900"
                    @close="exitAddDialog"
                    :close-on-click-modal="false"
                    :visible.sync="addDialog"
                    class="add_dialog"
                >
                    <el-form
                        :inline="true"
                        :model="dataDictionaryAdd"
                        class="demo-form-inline"
                        size="small"
                        label-width="80px"
                        label-position="right"
                        :rules="rules"
                        ref="ruleForm"
                    >
                        <el-form-item label="名称" prop="name">
                            <el-input
                                type="text"
                                v-model.trim="dataDictionaryAdd.name"
                                :clearable="dataDictionaryAdd.name ? true: false"
                            ></el-input>
                        </el-form-item>
                        <el-form-item label="代码" prop="code">
                            <el-input
                                type="text"
                                v-model.trim="dataDictionaryAdd.code"
                                :clearable="dataDictionaryAdd.code ? true: false"
                            ></el-input>
                        </el-form-item>
                        <el-form-item label="附加值1" prop="value1">
                            <el-input
                                type="text"
                                v-model.trim="dataDictionaryAdd.value1"
                                :clearable="dataDictionaryAdd.value1 ? true: false"
                            ></el-input>
                        </el-form-item>
                        <el-form-item label="附加值2" prop="value2">
                            <el-input
                                type="text"
                                v-model.trim="dataDictionaryAdd.value2"
                                :clearable="dataDictionaryAdd.value2 ? true: false"
                            ></el-input>
                        </el-form-item>
                        <!-- <el-form-item label="排列序号" prop="remark">
                            <el-input
                                type="text"
                                v-model.trim="dataDictionaryAdd.remark"
                                :clearable="dataDictionaryAdd.remark ? true: false"
                            ></el-input>
                        </el-form-item>-->
                    </el-form>
                    <div slot="footer" class="dialog-footer">
                        <el-button @click="exitAddDialog" size="small">取 消</el-button>
                        <el-button
                            class="btnCss successBtn"
                            type="primary"
                            size="small"
                            @click="submitForm('ruleForm')"
                        >确 定</el-button>
                    </div>
                </el-dialog>
            </div>
        </el-card>
    </div>
</template>

<script>
import tablePug from 'components/Table/tablePlugin'
import page from 'components/Table/page'
// 接口
import {
  getDicListApi,
  getDicAddApi,
  getDicDeleteApi,
  getDicDetailApi
} from 'api/xitongguanli/dic.js'
export default {
  components: {
    tablePug,
    page
  },
  data() {
    return {
      addForm: {
        name: '',
        zjhm: ''
      },
      defaultProps: {
        children: 'children',
        label: 'label'
      },
      dataDictionaryAdd: {
        name: null,
        code: null,
        value1: null,
        value2: null
        //    remark: null,
      },
      // dataDictionaryAddsss: {
      //    name: null,
      //    code: null,
      //    value1: null,
      //    value2: null,
      // //    remark: null,
      // },
      rules: {
        name: [
          { required: true, message: '请输入名称', trigger: 'blur' },
          {
            min: 1,
            max: 20,
            message: '支持中英文10位汉字或20位英文',
            trigger: 'blur'
          }
        ],
        code: [
          { required: true, message: '请输入代码', trigger: 'blur' },
          { min: 1, max: 20, message: '数字最大为20位', trigger: 'blur' }
        ],
        // value1: [{ required: true, message: '请输入附加值1', trigger: 'blur' }],
        // value2: [{ required: true, message: '请输入附加值2', trigger: 'blur' }]
        // remark: [{ required: true, message: "请输入排列序号", trigger: "blur" },
        //     { min: 0, max: 2, message: "数字最大为2位", trigger: "blur" }
        // ],
      },
      addDialog: false,
      dataTree: [],
      defaultProps: {
        label: 'name',
        children: 'zones'
      },
      treeIdData: null,
      id: null,
      code: null,
      addPid: null,
      typePid: null,
      dicId: null,
      tableList: {
        // 表格所需数据
        tableData: [],
        titles: [],
        // type: true, // 有无选择框 true/false 默认为true
        btnconfig: {
          // ----------------------------按钮项配置/不传则不展示
          title: '操作',
          width: '250', // 按钮项宽度
          btnlist: [ 
            {
              con: '修改',
              concolor: '#1ab394',
              backgroundColor: '#fff',
              // icon:'el-icon-check',
              type: 'primary',
              size: ''
            },
            {
              con: '删除', // 按钮内容 若果使用内容不使用图标，若使用图标和内容则不建议使用圆形
              concolor: '#f00', // 文字颜色
              backgroundColor: '#fff', // 按钮背景色
              // icon:'el-icon-zoom-in', //使用字体图标为按钮
              circle: false, // 控制按钮是否为圆形   false/true  默认false
              type: 'primary', // 按钮模式
              size: '' // 按钮大小medium / small / mini 默认为mini
            }
          ]
        }
      },
      suninfo: '',
      // 数组总数
      changPageSizeNum: {
        type: '',
        data: ''
      },
      pageSize: 1,
      totalData: null,
      treeForData: null,
      treeIdData: null,
      pageSizeNum:null
    }
  },
  created() {
    // this.getVal(1);
  },
  mounted() {
    this.initTableData()
  },
  methods: {
    // ...mapMutations({
    //   // ddd: 0
    // }),
    qxReadonly(ev) {
      ev.target.removeAttribute('readonly')
    },
    initTableData() {
      this.listDataPost({ pid: 0, size: 10, page: 1 })

      this.tableList.titles = [
        { name: '名称', data: 'name' },
        { name: '代码', data: 'code' },
        { name: '附加值1', data: 'value1' },
        { name: '附加值2', data: 'value2' }
        // { name: "排列顺序", data: "remark" }
      ]
    },
    // 操作按钮
    getVal(data) {
      // this.suninfo = val;
      if (data.type === '修改') {
        // this.dataDictionaryAddsss = data.data;
        this.typePid = data.data.pid
        this.id = data.data.id
        this.code = data.data.code
        this.openDialogUpdat(data.data.id)
      }
      if (data.type === '删除') {
        this.deleteDataFun(data.data.id)
      }
    },

    // 分页参数
    getPageData(params) {
      this.pageSizeNum = params;
      // let arr = [];
      // let d = 1;
      // for (let i = 0; i < this.totalData.length / 10; i++) {
      //   arr.push(d++);
      // }
      if (params === 1) {
        this.tableList.tableData = this.totalData.slice(
          (params - 1) * 10,
          params * 10
        )
      } else {
        this.tableList.tableData = this.totalData.slice(
          (params - 1) * 10,
          params * 10
        )
      }
    },
    // 新增打开弹窗
    openDialog() {
      if (this.addPid != null) {
        this.addDialog = true
        document.querySelector('.add_dialog .el-dialog__title').innerHTML =
          '新增'
        this.dataDictionaryAdd.name = null
        this.dataDictionaryAdd.code = null
        this.dataDictionaryAdd.value1 = null
        this.dataDictionaryAdd.value2 = null
      } else {
        this.$message({
          message: '请先选择数据字典！',
          type: 'warning'
        })
      }
    },
    // 修改弹窗
    openDialogUpdat(id) {
      if (this.typePid != null) {
        document.querySelector('.add_dialog .el-dialog__title').innerHTML =
          '修改'

        getDicDetailApi({ id: id }).then(res => {
          if (res.code == 200) {
            this.dataDictionaryAdd = res.data
            this.addDialog = true
          }
        })
      }
    },
    // 关闭弹框
    exitAddDialog() {
      const title = document.querySelector('.add_dialog .el-dialog__title')
        .innerHTML
      if (title === '新增') {
        // this.addPid = null;
        this.$refs.ruleForm.resetFields()
        this.dataDictionaryAdd.name = null
        this.dataDictionaryAdd.code = null
        this.dataDictionaryAdd.value1 = null
        this.dataDictionaryAdd.value2 = null
        this.addDialog = false
      }
      if (title === '修改') {
        this.typePid = null
        this.$refs.ruleForm.resetFields()
        this.dataDictionaryAdd.name = null
        this.dataDictionaryAdd.code = null
        this.dataDictionaryAdd.value1 = null
        this.dataDictionaryAdd.value2 = null
        this.addDialog = false
      }
    },
    // 确定新增事件
    submitForm(ruleForm) {
      this.$refs[ruleForm].validate(valid => {
        if (valid) {
          const title = document.querySelector('.add_dialog .el-dialog__title')
            .innerHTML
          const data = this.dataDictionaryAdd
          let url = null
          let message = null
          if (title === '新增') {
            url = '/sys/dic/add'
            message = '新增成功'
            data.pid = this.addPid
          }
          if (title === '修改') {
            url = '/sys/dic/update'
            message = '修改成功'
            // data.pid = this.typePid
            data.id = this.id
          }
          getDicAddApi(data, url).then(res => {
            if (res.code === 200) {
              this.$message.success(message)
              // this.$refs[ruleForm].resetFields();
              this.addDialog = false
              this.listDataPost({ pid: this.typePid });
            }
          })
        } else {
          return false
        }
      })
    },
    // 删除数据方法
    deleteDataFun(id) {
      this.$confirm('此操作将永久删除该文件, 是否继续?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      })
        .then(() => {
          getDicDeleteApi({ id: id }).then(res => {
            if (res.code === 200) {
              this.$message({
                type: 'success',
                message: '删除成功!'
              })
              this.initTableData()
            }
          })
        })
        .catch(() => {
          this.$message({
            type: 'info',
            message: '已取消删除'
          })
        })
    },

    // 树形控件
    handleCheckChange(data, checked, indeterminate) {
    },
    handleNodeClick(data) {
      this.listDataPost({ pid: data.id })
      this.treeIdData = data.id
      this.addPid = data.id
      //   alert(this.addPid);
    },
    loadNode1(node, resolve) {
      if (node.level === 0) {
        return resolve([{ name: '数据字典', code: 0, id: 0 }])
      }
      if (node.level > 0) {
        let arr = []
        setTimeout(() => {
          if (this.treeForData) {
            for (const ele of this.treeForData) {
              arr.push({
                name: ele.name,
                id: ele.id,
                code: ele.code
              })
            }
            // let paramData = {
            //   pid: this.treeIdData,
            //   size: 10,
            //   pages: 1
            // };
            // this.listDataPost(paramData, "page");
          } else {
            arr = []
          }
          return resolve(arr)
        }, 500)
      }
      if (node.data.name === '数据字典') {
        setTimeout(() => {
          var data
          data = [
            {
              name: this.tableList.tableData[0].name,
              code: this.tableList.tableData[0].code,
              id: this.tableList.tableData[0].id
            }
          ]
          resolve(data)
        }, 50)
      }
    },
    // tabel表格数据处理
    listDataPost(param, type) {
      getDicListApi(param).then(res => {
        if (res.code === 200) {
          this.treeForData = res.data.list
          this.totalData = res.data.list
          this.changPageSizeNum = {
            type: '',
            data: res.data
          }
          if (this.pageSizeNum) {
            this.getPageData(this.pageSizeNum);
          }else {
            this.tableList.tableData = res.data.list.slice(0, 10)
          }
        }
      })
    }
  }
}
</script>

<style lang="scss" scoped>
@import "../../styles/public.scss";
.pub_groupBtn {
  margin-top: 20px;
}
.btnCss {
  margin-bottom: 10px;
}
.bg-purple {
  height: 533px;
  overflow: scroll;
  border: 1px solid #ebeef5;
}
.bg-purple-light {
  margin-left: 20px;
  height: 100%;
}
</style>