<template>
  <div class="home-cls"> 
    <h2>云印章</h2>
    <p class="home-p-title">通过全程数字化的印控方案，让纸质合同和电子合同的用印都得到规范、合理和高效的控制</p> 
    <el-row :gutter="2">
      <el-col :md="8">
        <div class="home-content-box">
          <div class="box-f">
            <div class="box-svg"><svg-icon icon-class="user" style="font-size:50px;"/></div>
            <h3>昱鑫集团</h3>
            <p>此处放置30个汉子以内广告语为最佳，此处放置30个汉子以内广告语为最佳。</p>
          </div>
        </div>
      </el-col>  
      <el-col :md="8">
        <div class="home-content-box">
          <div class="box-f">
            <div class="box-svg"><svg-icon icon-class="user" style="font-size:50px;"/></div>
            <h3>昱鑫集团</h3>
            <p>此处放置30个汉子以内广告语为最佳，此处放置30个汉子以内广告语为最佳。</p>
          </div>
        </div>
      </el-col>  
      <el-col :md="8">
        <div class="home-content-box">
          <div class="box-f">
            <div class="box-svg"><svg-icon icon-class="user" style="font-size:50px;"/></div>
            <h3>昱鑫集团</h3>
            <p>此处放置30个汉子以内广告语为最佳，此处放置30个汉子以内广告语为最佳。</p>
          </div>
        </div>
      </el-col>  
      <el-col :md="8">
        <div class="home-content-box">
          <div class="box-f">
            <div class="box-svg"><svg-icon icon-class="user" style="font-size:50px;"/></div>
            <h3>昱鑫集团</h3>
            <p>此处放置30个汉子以内广告语为最佳，此处放置30个汉子以内广告语为最佳。</p>
          </div>
        </div>
      </el-col>  
      <el-col :md="8">
        <div class="home-content-box">
          <div class="box-f">
            <div class="box-svg"><svg-icon icon-class="user" style="font-size:50px;"/></div>
            <h3>昱鑫集团</h3>
            <p>此处放置30个汉子以内广告语为最佳，此处放置30个汉子以内广告语为最佳。</p>
          </div>
        </div>
      </el-col>  
      <el-col :md="8">
        <div class="home-content-box">
          <div class="box-f">
            <div class="box-svg"><svg-icon icon-class="user" style="font-size:50px;"/></div>
            <h3>昱鑫集团</h3>
            <p>此处放置30个汉子以内广告语为最佳，此处放置30个汉子以内广告语为最佳。</p>
          </div>
        </div>
      </el-col>  
    </el-row>
  </div>
</template>

<script>
  export default {
    name:'newHome'
  }
</script>

<style lang="scss" scoped>
.home-cls{
  padding-bottom: 100px;
  >h2{
    color: #515769;
  }
  .home-p-title{
    color:#a6a7aa;
    margin-bottom: 40px;
  }
  margin: 50px;
  .home-content-box{
    margin-bottom: 2px;
    box-sizing: border-box;
    background-color: #4bc1ff;
    border: 1px solid #4bc1ff;
    height: 100%;
    min-height: 260px;
    color: #fff;
    cursor: pointer;
    position: relative;
    animation:myfirst 5s;
    .box-svg{
      height: 40px;
      line-height: 40px;
      overflow: hidden;
      opacity:1;
      color: #fff;
      transition: color 0.3s linear;
    }
    .box-f{
      position:absolute;
      background-color: transparent; 
      top: 50px;
      left: 50px;
      right: 50px;
      bottom: 50px;
      transition: all 0.3s ease-out;
    } 
    P{
      line-height: 24px;
    }
  } 
  .home-content-box:hover .box-f{
    top: 20px;
  }
  .home-content-box:hover .box-svg{
    color: #4bc1ff;
  }
  @keyframes myfirst {
    // from { background: #f00;}
    // to {  background: #4bc1ff; }
    0%   {background: red;}
    25%  {background: yellow;}
    50%  {background: blue;}
    75% {background: green;}
    100% {background-color: #4bc1ff}  
  }
} 
</style>