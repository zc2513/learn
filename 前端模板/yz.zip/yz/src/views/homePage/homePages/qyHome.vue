<template>
  <div class="pub_main">
    <el-card shadow="always">
      <div class="notice">
        <div class="notice_title">通知公告</div>
        <ul>
          <li v-for="(item,index) in noticeList" :key='index' @click="openNoticeInfo(item)">{{ item.title }}</li>
        </ul>
      </div>
        
      <div class="enterpriseInfo">
        <div class="enterpriseInfo_title">企业信息</div>
        <div class="enterpriseInfo_table">
          <div class="enterpriseInfo_table_left">
            <div>
              <ul class="table_left_row">
                <li>行业类型</li>
                <li>企业编号</li>
                <li>企业名称</li>
                <li>管辖单位</li>
              </ul>
              <ul class="table_left_info">
                <li :title="enterprise.hylbbm">{{enterprise.hylbbm}}</li>
                <li :title="enterprise.dwbm">{{enterprise.dwbm}}</li>
                <li :title="enterprise.dwmc">{{enterprise.dwmc}}</li>
                <li :title="enterprise.organization_name">{{enterprise.organization_name}}</li>
              </ul>
            </div>
            <div>
              <ul class="table_left_row">
                <li>企业状态</li>
                <li>统一社会信用代码</li>
                <li>特行许可证编号</li>
                <li>成立日期</li>
              </ul>
              <ul class="table_left_info">
                <li :title="enterprise.zt">{{enterprise.zt}}</li>
                <li :title="enterprise.tyshxydm">{{enterprise.tyshxydm}}</li>
                <li :title="enterprise.thxkzbh">{{enterprise.thxkzbh}}</li>
                <li >{{new Date(enterprise.clrq).toLocaleString()}}</li>
              </ul>
            </div>
            <div class="table_left_last">
              <ul class="table_left_row">
                <li>单位电话</li>
                <li>单位地址</li>
                <li>登记时间</li>
                <li></li>
              </ul>
              <ul class="table_left_info">
                <li :title="enterprise.lxdh">{{enterprise.lxdh}}</li>
                <li :title="enterprise.dwdz">{{enterprise.dwdz}}</li>
                <li>{{new Date(enterprise.djsj).toLocaleString()}}</li>
                <li> </li>
              </ul>
            </div>
          </div>
          <div class="enterpriseInfo_table_right">
            <div>
              <div class="table_right_row">
                <div>营业执照照片</div>
              </div>
              <div class="table_right_info">
                <img @click="imgPreview(imgUrl+enterprise.yyzzzp)" :src="imgUrl+enterprise.yyzzzp"/>
              </div>
            </div>
            <div>
              <div class="table_right_row">
                <div>特行许可证照片</div>
              </div>
              <div class="table_right_info">
                <img @click="imgPreview(imgUrl+enterprise.thxkzzp)" :src="imgUrl+enterprise.thxkzzp"/>
              </div>
            </div>
          </div>
        </div>
      </div>
    </el-card>
    <!-- 详情 -->
    <el-dialog title="详情" modal width="900px" :visible.sync="dialogdetailed" @close="closeDialog">
        <ul class='toadd'>
            <li>
                <label for="">接受方:</label>
                <span>{{detaildata.jshy}}</span>
            </li>
            <li>
                <label for="">标题:</label>
                <span>{{detaildata.xctgbt}}</span>
            </li>
            <li>
                <label for="">内容:</label>
                <span>{{detaildata.xctgnr}}</span>
            </li>
            <li>
                <label for="">附件:</label>
                <a class='download' :href="imgBaseUrl+detaildata.xctgfj" :download="detaildata.xctgfj">{{detaildata.xctgfj}}</a>
            </li>
            <li>
                <label for="">发布单位:</label>
                <span>{{detaildata.fbdw}}</span>
            </li>
            <li>
                <label for="">发布人:</label>
                <span>{{detaildata.fbr}}</span>
            </li>
            <li>
                <label for="">发布时间:</label>
                <span>{{detaildata.fbsj}}</span>
            </li>
        </ul>
    </el-dialog>
    <el-dialog title :visible.sync="imgEnlargeD" top="20vh" center id="imgenlarge">
        <img :src="imgEnlargeDUrl" alt>
    </el-dialog>
  </div>
</template>

<script>
import tablePug from "components/Table/tablePlugin";
import page from "components/Table/page";
// 接口
 export default {
    components: {
      
    },
    data() {
      return {
        noticeList:[],
        enterprise:{},
        detaildata:{},
        imgUrl: "/fileserver/file/preview?filename=",
        lSData: {
          hylxData:[],
          qyztData:[]
        },
        dialogdetailed:false,
        detaildata: {
          jshy:null,
          xctgbt:null,
          xctgnr:null,
          xctgfj:null,
          fbdw:null,
          fbr:null,
          time:null,
        },
        option1:[],//行业类型
        imgBaseUrl: '/fileserver/file/preview?filename=',
        imgEnlargeD: false,
        imgEnlargeDUrl: null,
      };
    },

    created() {
      this.initTableData();
    },  
  methods: {
      initTableData(){
        let usersData = JSON.parse(this.$store.state.user.users);
        this.enterprise = usersData;

        let dataLS = JSON.parse(this.$store.state.user.dicData);
        this.lSData.hylxData = dataLS["行业类型"];
        this.lSData.qyztData = dataLS["企业状态"];
        var arr1 = [];
        if(this.lSData.hylxData){
            this.lSData.hylxData.forEach((k,v)=>{
                arr1.push({
                    value:k.code,
                    label:k.name
                });
            })
            this.option1 = arr1;
        }

        for (const ele of this.lSData.hylxData) {
          if(this.enterprise.hylbbm == ele.code){
            this.enterprise.hylbbm = ele.name;
          }
        };
        for (const ele of this.lSData.qyztData) {
          if(this.enterprise.zt == ele.code){
            this.enterprise.zt = ele.name;
          }
        };
        var data = {
            hylb:JSON.parse(this.$store.state.user.users).hylbbm
        };
        qishowgetlistPost(data).then(res => {
           for (let ele of res.data) {
              //行业编码转名称
              var arr = ele.jshy.split(",");
              var result = [];
              for(var i = 0; i < this.option1.length; i++){
                  var obj = this.option1[i];
                  var num = obj.value;
                  var isExist = false;
                  for(var j = 0; j < arr.length; j++){
                      var n = arr[j];
                      if(n == num){
                          isExist = true;
                          break;
                      }
                  }
                  if(isExist){
                      result.push(obj);
                  }
              }
              var arr1=[];
              result.forEach((item,index)=>{
                  arr1.push(item.label)
              });
              var str = arr1.join(",")
              ele.jshy = str;
              
              this.noticeList.push({
                id:ele.id,
                title:ele.xctgbt,
                fbdw:ele.fbdw,
                fbr:ele.fbr,
                fbsj:this.$dateFormat(ele.fbsj),
                jshy:ele.jshy,
                xctgbt:ele.xctgbt,
                xctgfj:ele.xctgfj,
                xctgnr:ele.xctgnr,                   
              })
            }
        })
      },
      openNoticeInfo(val){
          this.detaildata = val;
          // 附件改名
          if(val.xctgfj){
              this.fileFormat = "."+this.detaildata.xctgfj.split(".")[1];
              this.detaildata.xctgfj = this.detaildata.xctgbt+this.fileFormat;
          }
          this.dialogdetailed = true;
      },
      closeDialog() {
        this.detaildata = {};
          this.dialogdetailed = false;
      },
      imgPreview(ev) {
        this.imgEnlargeD = true;
        this.imgEnlargeDUrl = ev;
      } 
    }
};
</script>

<style lang="scss" scoped>
@import "../../../styles/public.scss";
.notice {
  border: 1px solid;
  border-color: rgba(228, 228, 228, 1);
  .notice_title {
    width: 100%;
    height: 36px;
    background-color: rgba(228, 228, 228, 1);
    line-height: 36px;
    padding-left: 20px;
    font-size: 14px;
    color: #333333;
  }
  ul {
    margin: 0px;
    padding: 0;
    list-style: none;
    li {
      height: 43px;
      line-height: 43px;
      font-size: 14px;
      color: #666666;
      padding: 0 20px;
      border-bottom: 1px solid;
      border-color: rgba(228, 228, 228, 1);
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
      cursor: pointer;
    }
    li:last-child {
      border-bottom: none;
    }
  }
}
.enterpriseInfo {
  height: auto;
  margin-top: 30px;
  border: 1px solid;
  border-color: rgba(228, 228, 228, 1);
  .enterpriseInfo_title {
    width: 100%;
    height: 36px;
    background-color: rgba(228, 228, 228, 1);
    line-height: 36px;
    padding-left: 20px;
    font-size: 14px;
    color: #333333;
  }
  .enterpriseInfo_table {
    width: 100%;
    min-height: 300px;
    .enterpriseInfo_table_left {
      width: 80%;
      // min-height: 300px;
      height: auto;
      float: left;
      .table_left_row {
        width: 100%;
        height: auto;
        min-height: 50px;
        list-style: none;
        border-bottom: 1px solid;
        border-color: rgba(228, 228, 228, 1);
        padding: 0px;
        margin: 0;
        text-align: center;
        line-height: 50px;
        font-weight: 700;
        font-style: normal;
        color: #333333;
        li {
          float: left;
          width: 25%;
          // min-height: 50px;
          height: auto;
          border-right: 1px solid;
          border-color: rgba(228, 228, 228, 1);
        }
      }
      .table_left_info {
        width: 100%;
        min-height: 50px;
        // height: auto;
        list-style: none;
        border-bottom: 1px solid;
        border-color: rgba(228, 228, 228, 1);
        padding: 0px;
        margin: 0;
        text-align: center;
        line-height: 49px;
        font-weight: 400;
        font-style: normal;
        font-size: 14px;
        color: #666666;
        li {
          float: left;
          width: 25%;
          height: auto;
          border-right: 1px solid;
          border-color: rgba(228, 228, 228, 1);
          overflow: hidden;
          text-overflow: ellipsis;
          white-space: nowrap;
        }
      }
      .table_left_last .table_left_info {
        border-bottom: none;
      }
    }
    .enterpriseInfo_table_right {
      width: 20%;
      min-height: 300px;
      float: left;
      .table_right_row {
        clear: both;
        width: 100%;
        height: 49px;
        list-style: none;
        padding: 0px;
        margin: 0;
        text-align: center;
        line-height: 49px;
        font-weight: 700;
        font-style: normal;
        color: #333333;
        div {
          width: 100%;
          min-height: 49px;
          border-bottom: 1px solid;
          border-color: rgba(228, 228, 228, 1);
        }
      }
      .table_right_info {
        width: 100%;
        height:101px;
        list-style: none;
        border: 1px solid;
        border-color: rgba(228, 228, 228, 1);
        padding: 0px;
        margin: 0;
        text-align: center;
        font-weight: 400;
        font-style: normal;
        font-size: 14px;
        color: #666666;
        overflow: hidden;
        img {
          height: 100%;
        }
      }
    }
  }
  
}
.toadd{
       li{
           list-style: none;
           overflow: hidden;
           padding:0.3rem 0;
           label{
               float:left;
               width:10%;
               text-align: right;
               line-height: 2rem;
           }
           a{
               color:#1bb493;
            }
           .el-checkbox-group,.el-input,.el-textarea,span,.download{
               float:left;
               width:88%;
               padding-left:2%;
               line-height: 2rem;
           }
           #upload_box{
               float:left;
               width:88%;
               padding-left:2%;
               line-height: 2rem;
               position:relative;
               .el-input{
                   width:30%;
                   padding-left:0;
               }
               .el-upload{
                   width:30%;
                   a{
                       margin-left:1rem;
                   }
               }
           }
       }
   }
</style>
