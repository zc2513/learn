 <template>
   <div>
     <el-card >
        <div class="search_box">
            <el-form :inline="true" :model="searchForm"   class="demo-dynamic" size="small">
              <el-form-item label='输入:'>
                <el-input v-model="searchForm.nameOrCode" placeholder="提示..."></el-input>
              </el-form-item>
              <el-form-item label='输入:'>
                <el-input v-model="searchForm.nameOrCode" placeholder="提示..."></el-input>
              </el-form-item> 
              <el-form-item label>
                <el-date-picker
                  v-model="searchFormTm"
                  type="daterange"
                  range-separator="~"
                  value-format='yyyy-MM-dd HH:mm:ss'
                  :default-time="['00:00:00', '23:59:59']"
                  start-placeholder="开始日期"
                  end-placeholder="结束日期"
                ></el-date-picker>
              </el-form-item>
              <el-form-item>
                <el-button  @click="searchCompanyFun">查询</el-button>
              </el-form-item>
            </el-form>
          </div> 
          <div class="table_box">
            <public-table :msg="tableList" @sendVal="getBtnDataFun"></public-table>
            <public-page @pagesend="getPageSizeFun" :changPageSize="changPageSizeNum"></public-page>
          </div>
      </el-card>
   </div>
 </template>
 
 <script>
import publicTable from "components/Table/tablePlugin";
import publicPage from "components/Table/page";
import { btnconfig , titles , tabalInfo} from './adminTable.js';
   export default {
     name:'gahome',
     components:{
       publicTable,
       publicPage
     },
     data(){
       return{
          searchForm:{
            startTime:null,
            endTime:null,
          },
          // tableList: {},//表格数据
          tableList: {//版本封装问题 修改太多 所以加tableData:[] 是为了去除警告。
              tableData: [],//表格数据
          },//表格数据
          changPageSizeNum: {},
          searchFormTm:null,
       }
     },
     created() {
        this.tableList['titles'] =titles; 
        this.tableList['btnconfig'] =btnconfig();  
        this.initData()
     },
     methods: {
       initData(){
         tabalInfo().then(res=>{
           console.log(res)
           this.changPageSizeNum = res.changPageSizeNum
           this.tableList['tableData'] = res.tableData
         })
       },
       getBtnDataFun(val){
         console.log(val)
       },
       getPageSizeFun(val){
         console.log(val)
       },
       searchCompanyFun(){
          this.searchForm.startTime = this.searchFormTm ? this.searchFormTm[0] : null;
          this.searchForm.endTime = this.searchFormTm ? this.searchFormTm[1] : null;
          console.log(this.searchForm)
          this.changPageSizeNum={
              type:true,//是否返回第一页
              total:166,
              page:10
          }
       },
     },
   }
 </script>
 
 <style lang="scss" scoped>
 
 </style>