<template>
  <div :class="className" :style="{height:height,width:width}"/>
</template>

<script>
import echarts from 'echarts'
require('echarts/theme/macarons') // echarts theme
// import { debounce } from '@/utils'

const animationDuration = 6000

export default {
  props: {
    className: {
      type: String,
      default: 'chart'
    },
    width: {
      type: String,
      default: '100%'
    },
    height: {
      type: String,
      default: '300px'
    }
  },
  data() {
    return {
      chart: null
    }
  },
  mounted() {
    this.initChart()
    // this.__resizeHandler = debounce(() => {
    //   if (this.chart) {
    //     this.chart.resize()
    //   }
    // }, 100)
    // window.addEventListener('resize', this.__resizeHandler)
  },
  beforeDestroy() {
    if (!this.chart) {
      return
    }
    window.removeEventListener('resize', this.__resizeHandler)
    this.chart.dispose()
    this.chart = null
  },
  methods: {
    initChart() {
      this.chart = echarts.init(this.$el, 'macarons')

      this.chart.setOption({
        // title:{
        //   text:"行业统计"
        // },
        tooltip: {
          trigger: 'axis',
          axisPointer: { // 坐标轴指示器，坐标轴触发有效
            type: 'shadow' // 默认为直线，可选为：'line' | 'shadow'
          }
        },
        grid: {
          top: 10,
          left: '2%',
          right: '2%',
          bottom: '3%',
          containLabel: true
        },
        xAxis: [{
          type: 'category',
          data: ['印章行业', '开锁行业', '机修行业', '二手车行业', '二手手机', '汽车租赁', '典当行业', '旅游行业', '废旧物品'],
          axisTick: {
            alignWithLabel: true
          }
        }],
        yAxis: [{
          type: 'value',
          axisTick: {
            show: false
          }
        }],
        series: [{
          name: '企业总数',
          type: 'bar',
          stack: 'vistors',
          barWidth: '60%',
          data: [320, 155, 194, 145, 51, 56, 47,21,33,10],
          animationDuration
        }, {
          name: '上传数',
          type: 'bar',
          stack: 'vistors',
          barWidth: '60%',
          data: [50, 0, 1, 0, 40, 0, 0, 0, 0,10],
          animationDuration
        }, {
          name: '未上传数',
          type: 'bar',
          stack: 'vistors',
          barWidth: '60%',
          data: [270, 155, 193, 145, 11, 56, 47 , 21 , 5,20],
          animationDuration
        }]
      })
    }
  }
}
</script>
