<template>
    <el-form :inline="true" :model="formInline" size="small" class="demo-form-inline">
        <el-form-item label="管辖单位">
            <el-cascader
                filterable
                @focus="($event.target.removeAttribute('readonly'))"
                :options="options"
                size="small"
                :show-all-levels="false"
                change-on-select
                clearable
                @change="handleChange">
            </el-cascader>
        </el-form-item>
        <el-form-item label="统计时间">
            <el-date-picker
                v-model="formInline.time"
                type="daterange"
                value-format='yyyy-MM-dd HH:mm:ss'
                :default-time="['00:00:00', '23:59:59']"
                range-separator="至"
                start-placeholder="开始日期"
                end-placeholder="结束日期"
            ></el-date-picker>
        </el-form-item>
        <el-form-item>
            <el-button class="btnCss successBtn" type="primary" @click="postSearchData">查询</el-button>
            <el-button class="btnCss successBtn" type="primary" @click="postExport" size="small">导出</el-button>
        </el-form-item>
    </el-form>
</template>

<script>
export default {
  data() {
    return {
      formInline: {
        gxdwbm: "",
        time: ""
      },
      options: [],
      flag:false
    };
  },
  mounted() {
    this.initData();
  },
  methods: {
    initData(){
        let data = this.$store.state.user.organizations;
        this.options = data;
    },
    handleChange(val){
        const usersData = JSON.parse(this.$store.state.user.users);
        var str = val[val.length-1];
        if(str){
            this.formInline.gxdwbm = str.substring(str.lastIndexOf("-")+1).split(",")[0];
        }else {
            this.formInline.gxdwbm = usersData.brevitycode;
        }
    },
    postSearchData(){
        if(!this.formInline.time){
            this.$message({
              type: "warning",
              message: "请先选择统计时间!"
            });
            return false;
        }
        this.$emit('searchData',this.formInline);
        this.flag = true;
    },
    postExport(){
        if(!this.flag){
            this.$message({
              type: "warning",
              message: "请先查询获取数据!"
            });
            return false;
        }
        this.$emit('exportExcel',this.formInline);
    }
  }
};
</script>

<style lang="scss" scoped>
@import "../../../styles/public.scss";
// .el-form-item__content{
//     line-height: 0px!important;
// }
</style>
