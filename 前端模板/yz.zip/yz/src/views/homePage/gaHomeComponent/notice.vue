<template>
    <div class="notice">
        <div style="font-size:14px;background-color: rgba(242, 242, 242, 1);padding:0.5rem;">通知公告</div>
        <marquee align="left" behavior="scroll" scrollamount="10"  scrolldelay="1" onMouseOver="this.stop()" onMouseOut="this.start()">
             <ul>
                <li v-for="(item,index) in noticeList" :key='index' @click="openNoticeInfo(item.id)">{{ item.title }}</li>
              </ul>
        </marquee>
       <!-- 详情 -->
        <el-dialog title="详情" modal width="900px" :visible.sync="dialogdetailed">
            <ul class='toadd'>
                <li>
                    <label for="">接受方:</label>
                    <span>{{detaildata.jshy}}</span>
                </li>
                <li>
                    <label for="">标题:</label>
                    <span>{{detaildata.xctgbt}}</span>
                </li>
                <li>
                    <label for="">内容:</label>
                    <span>{{detaildata.xctgnr}}</span>
                </li>
                <li>
                    <label for="">附件:</label>
                    <a class='download' href="#">{{detaildata.xctgfj}}</a>
                </li>
                <li>
                    <label for="">发布单位:</label>
                    <span>{{detaildata.fbdw}}</span>
                </li>
                <li>
                    <label for="">发布人:</label>
                    <span>{{detaildata.fbr}}</span>
                </li>
                <li>
                    <label for="">发布时间:</label>
                    <span>{{new Date(detaildata.fbsj).toLocaleString()}}</span>
                </li>
            </ul>
        </el-dialog>
    </div>
    
</template>

<script>
import tablePug from "components/Table/tablePlugin";
import page from "components/Table/page";
// 接口
export default {
  data() {
    return {
       noticeList: [],
       dialogdetailed:false,
       detaildata:{},
       option1:[],//行业类型
    };
  },
  created() {
    this.initTableData();
  },
  methods: {
    initTableData(){
       showgetlistPost().then(res => {
           for (let ele of res.data) {
                  this.noticeList.push({
                    id:  ele.id,
                    title:ele.xctgbt
                  })
             }
         })
         let usersData = JSON.parse(this.$store.state.user.users);
        var hylx = JSON.parse(this.$store.state.user.dicData)["行业类型"];
        var arr1 = [];
        if(hylx){
            hylx.forEach((k,v)=>{
                arr1.push({
                    value:k.code,
                    label:k.name
                });
            })
            this.option1 = arr1;
        }
      },
      openNoticeInfo(val){
        this.dialogdetailed = true;
        let data = {
            id: val	//记录id
        }
        xqshowgetlistPost(data).then(res => {
            this.detaildata = res.data.list[0];
            if(res.data.list[0].xctgfj){
                this.fileFormat = "."+this.detaildata.xctgfj.split(".")[1];
                this.detaildata.xctgfj = this.detaildata.xctgbt+this.fileFormat;
            }
            this.detaildata.time = this.$dateFormat(res.data.list[0].fbsj);
            var arr=[];
            if(res.data.list[0].jshy){
                arr = res.data.list[0].jshy.split(",");
            }
            var result = [];
            for(var i = 0; i < this.option1.length; i++){
                var obj = this.option1[i];
                var num = obj.value;
                var isExist = false;
                for(var j = 0; j < arr.length; j++){
                    var n = arr[j];
                    if(n == num){
                        isExist = true;
                        break;
                    }
                }
                if(isExist){
                    result.push(obj);
                }
            }
            var arr1=[];
            result.forEach((item,index)=>{
                arr1.push(item.label)
            });
            var str = arr1.join(",")
            this.detaildata.jshy = str;
        })
      }
    }
};
</script>

<style lang="scss" scoped>
@import "../../../styles/public.scss";
  
   .toadd{
       li{
           list-style: none;
           overflow: hidden;
           padding:0.3rem 0;
           label{
               float:left;
               width:10%;
               text-align: right;
               line-height: 2rem;
           }
           a{
               color:#1bb493;
            }
           .el-checkbox-group,.el-input,.el-textarea,span,.download{
               float:left;
               width:88%;
               padding-left:2%;
               line-height: 2rem;
               label{
                    float:left;
                    width:16%;
                    text-align: left;
                    line-height: 2rem;
                    margin-left:0;
               }
           }
           #upload_box{
               float:left;
               width:88%;
               padding-left:2%;
               line-height: 2rem;
               position:relative;
               .el-input{
                   width:30%;
                   padding-left:0;
               }
               .el-upload{
                   width:30%;
                   a{
                       margin-left:1rem;
                   }
               }
           }
       }
   }
.notice{
    width: 100%;
    margin: 0px auto 25px;
   
    marquee{
      width: 100%;
      height: 100%;
      margin: 0 auto;
      ul{
        width: 100%;
      height: 100%;
      list-style: none;
        li{
          width: 18%;
          padding: 0 10px;
          float: left;
          font-size: 14px;
          overflow: hidden;
          text-overflow:ellipsis;
          white-space: nowrap;
          line-height: 14px;
          cursor: pointer;
          color: #606266;
        }
      }
    }

}
</style>
