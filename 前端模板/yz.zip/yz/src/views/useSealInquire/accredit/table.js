//  用章记录
import { getList } from 'api/useSealInquire/accredit.js'
import { dateFormat } from '@/utils/tools.js'
var changPageSizeNum = { // 一共多少数据
  type: false,
  total: 0
}
export function btnconfig() {
  const btn = {
    title: '操作',
    width: '',
    btnlist: [
      {
        con: '详情',
        type: 'success',
        size: 'mini'
      }
    ]
  }
  return btn
}

export var titles = [
  { name: '申请人', data: 'applyUserName' },
  { name: '审批人', data: 'approverName' },
  { name: '申请用章次数', data: 'count' },
  // { name: '申请事由', data: 'applyOption' },
  { name: '状态', data: 'status' },
  { name: '申请时间', data: 'applyTime' },
  { name: '审批时间', data: 'approverTime' }
]

export function tabalInfo(data) { // 表单数据
  let tableData = []
  return new Promise((reslove, reject) => {
    getList(data).then(res => {
      if (res.message === 'SUCCESS') {
        const data = res.data
        if (data.list) {
          for (const item of data.list) {
            // item.approverTime = dateFormat(item.approverTime)
            // item.applyTime = dateFormat(item.applyTime)
            item.status = item.status === 0 ? '待审批' : (item.status === 1 ? '审批通过' : (item.status === -1 ? '未通过' : '已完成'))
          }
        }
        tableData = data.list || []
        changPageSizeNum.total = data.total || 0
        reslove({ changPageSizeNum, tableData })
      } else {
        reject(res)
      }
    })
  })
}

