<template>
<!-- 用章记录/详情 -->
  <div class="pass-Info-box">
    <div class="pass-Info" v-if="infoData">
      <div class="pass-title">
        基本信息
      </div>
      <div>
        <div>印章编码</div>
        <div v-text="infoData.sealcode"></div>
      </div>
      <div>
        <div>申请人</div>
        <div v-text="infoData.applyUserName"></div>          
      </div>
      <div>
        <div>申请事由</div>
        <div v-text="infoData.applyOption"></div>
      </div>
      <div>
        <div>状态</div>
        <div v-text="infoData.status"></div>
      </div> 
      <div>
        <div>申请用章次数</div>
        <div v-text="infoData.count"></div>
      </div> 
      <div>
        <div>申请时间</div>
        <div v-text="infoData.applyTime"></div>
      </div>
      <div>
        <div>审批时间</div>
        <div v-text="infoData.approverTime"></div>
      </div>
      <div>
        <div>有效时间</div>
        <div v-text="infoData.effectiveTime"></div>
      </div>
      <div>
        <div>已盖章次数</div>
        <div v-text="infoData.ygzcs"></div>
      </div>
      <div>
        <div>审批人</div>
        <div v-text="infoData.approverName"></div>
      </div>
      <div class="accredit-last-div last-spyj">
        <div>审批意见</div>
        <div v-text="infoData.approverOpinion"></div>
      </div>
    </div>
    <div class="gz-fileList-cls" v-if="infoData">
      <div class="gz-title">盖章前文件图片</div>
      <div class="gz-img-box" v-if="infoData.gzqpic">
        <div v-for="(item,index) in infoData.gzqpic" :key='index'>
          <img :src="baseUri+item" @click="previewImg(item)">
        </div>  
      </div>
      <div class="gz-img-box" v-else>
        <div>
          <img src="../../../assets/No.jpg">
        </div>
      </div>  
    </div>
    <div class="gz-fileList-cls" v-if="infoData">
      <div class="gz-title">盖章后图片</div>
      <div class="gz-img-box" v-if="infoData.gzhpic"> 
        <div v-for="(item,index) in infoData.gzhpic" :key='index' >
          <img :src="baseUri+item" @click="previewImg(item)">
        </div> 
      </div>
      <div class="gz-img-box" v-else>
        <div>
          <img src="../../../assets/No.jpg">
        </div>
      </div>  
    </div>
    <preview :imgObj='preImg'></preview>  
  </div>
  
</template>

<script>
  import { getInfo } from 'api/useSealInquire/accredit.js'
  import { dateFormat } from '@/utils/tools.js'
  import preview from '@/components/preview.vue'
  export default {
    props: ['detailId'],
    components: {
      preview
    },
    data() {
      return {
        infoData: null,
        baseUri: '/file/preview?filename=',
        preImg: null // 预览图片地址
      }
    },
    created() {
      this.init(this.detailId)
    },
    methods: {
      init(id) {
        getInfo({ id: id }).then(res => {
          if (res.message == 'SUCCESS') {
            res.data.status = res.data.status === 0 ? '待审批' : (res.data.status === 1 ? '审批通过' : (res.data.status === -1 ? '未通过' : '已完成'))
            if (res.data.gzqpic) res.data.gzqpic = res.data.gzqpic.split('/')
            if (res.data.gzhpic) res.data.gzhpic = res.data.gzhpic.split('/')
            this.infoData = res.data
          }
        })
      },
      previewImg(src) { // ---照片预览
        this.preImg = {
          img: src,
          time: new Date()
        }
      }
    }
  }
</script>

<style lang="scss" scoped>
@import '../../../styles/particulars.scss';
.accredit-last-div{
  width: 66.66% !important;
}
.gz-fileList-cls{
  margin-bottom: 20px;
  .gz-title{
    line-height: 40px;
    background-color: #e2e2e2;
    font-size: 1.1rem;
    padding: 0 4px;
    font-weight: 700;
  }
  .gz-img-box{
    border: 1px solid  #e2e2e2;
    display: flex;
    div{
      box-sizing: border-box;
      padding: 2px;
      width: 80px;
      height: 60px;
      min-height: 40px;
      margin-right: 4px;
      display: flex;
      justify-content: center;
      align-items: center;
      cursor: pointer;
      img{
        width: 100%;
        max-height: 60px;
      }
    }
  }
}
</style>