 <template>
 <!-- 用章记录 -->
   <div>
     <el-card >
        <div class="search_box">
            <el-form :inline="true" :model="searchForm"   class="demo-dynamic" size="small">
              <el-form-item label='申请人:'>
                <el-input v-model="searchForm.applyUserName" placeholder="请输入..."></el-input>
              </el-form-item>
              <el-form-item label='审批人:'>
                <el-input v-model="searchForm.approverName" placeholder="请输入..."></el-input>
              </el-form-item> 
              <el-form-item label>
                <el-date-picker
                  v-model="searchFormTm"
                  type="daterange"
                  range-separator="~"
                  value-format='yyyy-MM-dd HH:mm:ss'
                  :default-time="['00:00:00', '23:59:59']"
                  start-placeholder="开始日期"
                  end-placeholder="结束日期"
                ></el-date-picker>
                <el-button  @click="searchCompanyFun">查询</el-button>
              </el-form-item> 
            </el-form>
          </div> 
          <div class="table_box">
            <public-table :msg="tableList" @sendVal="getBtnDataFun"></public-table>
            <public-page @pagesend="getPageSizeFun" :changPageSize="changPageSizeNum"></public-page>
          </div>
      </el-card>
      <div v-if="addType.state">
          <dialog-view :addData='addType' @cancelEven='getDialog'>
            <div slot="content">
                <details-view @addEvent='getDialog' :detailId='detailId'></details-view>
            </div>
          </dialog-view>
      </div>
   </div>
 </template>
 
 <script>
import publicTable from 'components/Table/tablePlugin'
import publicPage from 'components/Table/page'
import dialogView from 'components/dialog/index.vue'
import detailsView from './details.vue'
import { btnconfig, titles, tabalInfo } from './table.js'
export default {
  components: {
    publicTable,
    publicPage,
    dialogView,
    detailsView
  },
  data() {
    return {
      searchForm: {
        applyUserName: null,
        approverName: null,
        startTime: null,
        endTime: null
      },
      tableList: {// 版本封装问题 修改太多 所以加tableData:[] 是为了去除警告。
        tableData: [] // 表格数据
      }, // 表格数据
      changPageSizeNum: {},
      searchFormTm: null,
      nowPage: 1,
      addType: {
        state: false,
        title: '详情' // 弹窗标题
      }, 
      detailId: null
    }
  },
  created() {
    this.tableList['titles'] = titles
    this.tableList['btnconfig'] = btnconfig()
    this.initData()
  },
  methods: {
    initData(params, page = 0) {
      let data = {
        qybm: JSON.parse(this.$store.state.user.users).qybm,
        page: page,
        size: 10
      }
      if (params) {
        data = { ...data, ...params }
      }
      tabalInfo(data).then(res => {
        console.log(res, 99)
        this.changPageSizeNum = res.changPageSizeNum
        this.tableList['tableData'] = res.tableData
      })
    },
    getBtnDataFun(val) {
      if(val.type == '详情'){
        this.detailId = val.data.id
        this.addType.state = true
      }
    },
    getPageSizeFun(page) { // ---分页
      this.nowPage = page
      this.initData(this.searchForm, page)
    },
    searchCompanyFun() {
      this.searchForm.startTime = this.searchFormTm ? this.searchFormTm[0] : null
      this.searchForm.endTime = this.searchFormTm ? this.searchFormTm[1] : null
      this.changPageSizeNum.type = true
      this.initData(this.searchForm)
    },
    getDialog(state) { // 详情弹窗的状态
      if (!state) this.initData(this.searchForm, this.nowPage)
      this.addType.state = state
    }
  }
}
 </script>
 
 <style lang="scss" scoped>
 
 </style>