<template>
  <div class="setting-box">
        <div class="addUpData_box" >
            <el-form
            :model="formData"
            :rules="Rules"
            ref="leftForm"
            label-width="100px"
            class="demo-ruleForm"
            size="small"
            >
              <el-row :gutter="8" v-if="pageType=='账户信息'">
                 <el-col :lg="12">
                   <el-form-item label="登录名称:">
                        <div v-text="formData.username" class="setting-label-cs"></div>
                        <!-- <el-input v-model.trim="formData.username" readonly="readonly"></el-input> -->
                    </el-form-item>
                 </el-col>
                 <el-col :lg="12">
                   <el-form-item label="用户角色:">
                        <div v-text="formData.role_name" class="setting-label-cs"></div> 
                    </el-form-item> 
                 </el-col>
                 <el-col :lg="12">
                   <el-form-item label="单位名称:" v-if="formData.roleType=='qiye'">
                        <div v-text="formData.dwmc" class="setting-label-cs"></div> 
                    </el-form-item>
                 </el-col>
                 <el-col :lg="12">
                   <el-form-item label="组织机构:">
                      <div v-text="formData.organization_name" class="setting-label-cs"></div> 
                  </el-form-item>
                 </el-col>
              </el-row> 
              <div v-if="pageType=='修改密码'">
                <el-form-item label="旧密码:" prop="oldpword">
                    <el-input
                    type="text"
                    onfocus="this.type='password'"
                    v-model.trim="formData.oldpword"
                    placeholder="请输入"
                    :clearable="formData.oldpword?true:false"
                    ></el-input>
                </el-form-item>
                <el-form-item label="新密码:" prop="newpword">
                    <el-input
                    type="text"
                    onfocus="this.type='password'"
                    v-model.trim="formData.newpword"
                    placeholder="请输入"
                    :clearable="formData.newpword?true:false"
                    ></el-input>
                </el-form-item>
                <el-form-item label="确认密码:" prop="pword">
                    <el-input
                    type="text"
                    onfocus="this.type='password'"
                    v-model.trim="formData.pword"
                    placeholder="请输入"
                    :clearable="formData.pword?true:false"
                    ></el-input>
                </el-form-item>
                <el-form-item>
                  <el-button type="primary" style="width:100%;" @click.native.prevent="save('leftForm')">
                    提交
                  </el-button>
                </el-form-item>
              </div>
            </el-form>
        </div>
  </div>
</template>

<script>
import { revision } from 'api/userSetting/passRevision.js'
  export default {
    props:['pageType'],
    data(){
      var validateOldPass = (rule, value, callback) => {
        if( this.formData.newpword === this.formData.oldpword){
          callback(new Error('新密码不能与旧密码相同'))
        }else{
          callback()
        }
      }; 
      var validatePass = (rule, value, callback) => {
        if(this.formData.newpword != this.formData.pword){
          callback(new Error('新密码和确认密码不一致'))
        }else{
          callback()
        }
      };
      return{
        formData:{
          oldpword:null,
          newpword:null,
          pword:null,
        },
        Rules: {
          oldpword: [{ required: true, message: "旧密码不能为空", trigger: "blur" }],
          newpword: [
            { required: true, message: "新密码不能为空", trigger: "blur" },
            { required:true, validator: validateOldPass, trigger:"blur" }
          ],
          pword: [
            { required: true, message: "确认密码不能为空", trigger: "blur" },
            { required:true, validator: validatePass, trigger:"blur" }
          ]
        },
      }
    },
    created() {
      let {role_name, username, dwmc, organization_name, roles:[roleType]} = JSON.parse(this.$store.state.user.users) 
      this.formData['role_name'] = role_name
      this.formData['username'] = username
      this.formData['organization_name'] = organization_name
      this.formData['dwmc'] = dwmc
      this.formData['roleType'] = roleType
    },
    methods:{
      save(formName) {// 确定修改密码
        this.$refs[formName].validate((valid) => {
          if (valid) {
            let data = {
              id : JSON.parse(this.$store.state.user.users).userId,
              newPwd : this.formData.newpword,
              oldPwd : this.formData.oldpword

            }
            revision(data).then(res => {
              if (res.code === 200) {
                this.$message({
                  type: 'success',
                  message: '密码修改成功,请重新登录!'
                })
                setTimeout(()=>{
                  this.$store.dispatch('LogOut').then(() => {
                    location.reload() // 为了重新实例化vue-router对象 避免bug
                  })
                },1500)
              } 
            })
          } else {
            return false
          }
        })
      },
    }
  }
</script>

<style lang="scss" scoped>
.setting-box{
  width: 500px;
  min-width: 300px;
  margin: 10px auto;
  .setting-label-cs{
    padding-left:10px; 
  }
}
</style>