// 用户信息修改
import request from '@/utils/request'

export function revision(data) {
  return request({
    url: '/sys/user/updatePassword',
    method: 'post',
    data: data,
    headers: {
      'Content-Type': 'application/json;charset=UTF-8'
    }
  })
}
