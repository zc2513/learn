/* eslint-disable no-undef */
import request from '@/utils/request'
import qs from 'qs'

export function getList(data) {
  return request({
    url: 'zh/qiye/list',
    method: 'post',
    data: data,
    headers: {
      'Content-Type': 'application/json;charset=UTF-8'
    }
  })
}

export function postAdd(data) {
  return request({
    url: 'zh/qiye/addByYunzhang',
    method: 'post',
    data: data,
    headers: {
      'Content-Type': 'application/json;charset=UTF-8'
    }
  })
}

export function deleteTableData(data) {
  return request({
    url: 'zh/qiye/deleteByYunzhang',
    method: 'post',
    data: qs.stringify(data)
  })
}
