import request from '@/utils/request'
import qs from 'qs'

export function getListPost(param) { // 获取左侧树列表
  return request({
    url: '/sys/permission/list',
    method: 'post',
    data: qs.stringify(param)
  })
}
export function addDataPost(param) { // 新增
  return request({
    url: '/sys/permission/add',
    method: 'post',
    data: param,
    headers: {
      'Content-Type': 'application/json;charset=UTF-8'
    }
  })
}
export function updateDataPost(param) { // 修改
  return request({
    url: '/sys/permission/update',
    method: 'post',
    data: param,
    headers: {
      'Content-Type': 'application/json;charset=UTF-8'
    }
  })
}
export function deleteDataPost(param) { // 删除
  return request({
    url: '/sys/permission/delete',
    method: 'post',
    data: qs.stringify(param)
  })
}
