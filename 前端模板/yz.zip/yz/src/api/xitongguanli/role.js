import request from '@/utils/request'
import qs from 'qs'

export function getRoleListApi(param) {
  return request({
    url: '/sys/role/list',
    method: 'post',
    data: qs.stringify(param)
  })
}

export function getRoleAddApi(data, url) {
  return request({
    url: url,
    method: 'post',
    data: data,
    headers: {
      'Content-Type': 'application/json;charset=UTF-8'
    }
  })
}

export function getRoleDeleteApi(param) {
  return request({
    url: '/sys/role/delete',
    method: 'post',
    data: qs.stringify(param)
  })
}

export function getPermissionByRoleApi(data) {
  return request({
    url: '/sys/role/permissionByRole',
    method: 'post',
    data: data,
    headers: {
      'Content-Type': 'application/json;charset=UTF-8'
    }
  })
}

export function getPermissionUpdataApi(data) {
  return request({
    url: '/sys/role/permission/update',
    method: 'post',
    data: data,
    headers: {
      'Content-Type': 'application/json;charset=UTF-8'
    }
  })
}

