import request from '@/utils/request'
import qs from 'qs'

export function getDicListApi(param) {
  return request({
    url: '/sys/dic/list',
    method: 'post',
    data: qs.stringify(param)
  })
}

export function getDicAddApi(data, url) {
  return request({
    url: url,
    method: 'post',
    data: data,
    headers: {
      'Content-Type': 'application/json;charset=UTF-8'
    }
  })
}

export function getDicDeleteApi(param) {
  return request({
    url: '/sys/dic/delete',
    method: 'post',
    data: qs.stringify(param)
  })
}

export function getDicDetailApi(param) {
  return request({
    url: '/sys/dic/detail',
    method: 'post',
    data: qs.stringify(param)
  })
}

