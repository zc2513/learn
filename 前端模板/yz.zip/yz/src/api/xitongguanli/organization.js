import request from '@/utils/request'
import qs from 'qs'

export function getListPost(param) {
  return request({
    url: '/sys/organization/list',
    method: 'post',
    data: qs.stringify(param)
  })
}
export function addupDataPost(param, url) {
  return request({
    url: url,
    method: 'post',
    data: param,
    headers: {
      'Content-Type': 'application/json;charset=UTF-8'
    }
  })
}

export function detailDataPost(param) {
  return request({
    url: '/sys/organization/detail',
    method: 'post',
    data: qs.stringify(param)
  })
}

export function deleteDataPost(param) {
  return request({
    url: '/sys/organization/delete',
    method: 'post',
    data: qs.stringify(param)
  })
}
