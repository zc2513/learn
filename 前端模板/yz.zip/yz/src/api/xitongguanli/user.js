import request from '@/utils/request'
import qs from 'qs'

export function getUserListPost(param) {
  return request({
    url: '/sys/user/list',
    method: 'post',
    data: param,
    headers: {
      'Content-Type': 'application/json;charset=UTF-8'
    }

  })
}
export function addUserPost(param, url) {
  return request({
    url: url,
    method: 'post',
    data: param,
    headers: {
      'Content-Type': 'application/json;charset=UTF-8'
    }
  })
}
export function deleteUserPost(param) {
  return request({
    url: '/sys/user/delete',
    method: 'post',
    data: qs.stringify(param)
  })
}
export function resetPasswordPost(param) {
  return request({
    url: '/sys/user/resetPassword',
    method: 'post',
    data: qs.stringify(param)
  })
}
export function roleUpdatePost(param) {
  return request({
    url: '/sys/user/role/update',
    method: 'post',
    data: param,
    headers: {
      'Content-Type': 'application/json;charset=UTF-8'
    }
  })
}
export function updatePassword(param) {
  return request({
    url: '/sys/user/updatePassword',
    method: 'post',
    data: param,
    headers: {
      'Content-Type': 'application/json;charset=UTF-8'
    }
  })
}
export function detilUserPost(param) {
  return request({
    url: '/sys/user/detail',
    method: 'post',
    data: qs.stringify(param)
  })
}

