import request from '@/utils/request'

export function uploadFile(param) {
  return request({
    url: '/file/upload',
    method: 'post',
    data: param,
    processData: false,
    contentType: false
  })
}
export function previewFile(param) {
  return request({
    url: '/preview?filename=' + param,
    method: 'get'
  })
}
