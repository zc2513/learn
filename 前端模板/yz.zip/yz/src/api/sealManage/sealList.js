// 云章列表
import request from '@/utils/request'
import qs from 'qs'
export function getList(data) { // ---表格
  return request({
    url: 'seal/info/list',
    method: 'post',
    data: data,
    headers: {
      'Content-Type': 'application/json;charset=UTF-8'
    }
  })
}

export function addData(data, uri) { // ---新增-修改
  return request({
    url: `seal/info/${uri}`,
    method: 'post',
    data: data,
    headers: {
      'Content-Type': 'application/json;charset=UTF-8'
    }
  })
}

export function getInfo(data) { // ---详情
  return request({
    url: '/seal/info/detail',
    method: 'post',
    data: qs.stringify(data)
  })
}

export function deleteTableData(data) { // ---删除
  return request({
    url: '/seal/info/delete',
    method: 'post',
    data: qs.stringify(data)
  })
}
