// 我的申请
import request from '@/utils/request'
import qs from 'qs'
export function getList(data) { // ---表格
  return request({
    url: 'seal/apply/selectByApplyUser',
    method: 'post',
    data: data,
    headers: {
      'Content-Type': 'application/json;charset=UTF-8'
    }
  })
}

export function getInfo(data) { // ---详情
  return request({
    url: 'seal/apply/detail',
    method: 'post',
    data: qs.stringify(data)
  })
}
