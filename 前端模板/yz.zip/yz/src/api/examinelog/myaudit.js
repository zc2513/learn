// 我的审批
import request from '@/utils/request'
import qs from 'qs'
export function getList(data) {
  return request({
    url: 'seal/apply/selectByApprover',
    method: 'post',
    data: data,
    headers: {
      'Content-Type': 'application/json;charset=UTF-8'
    }
  })
}

export function getInfo(data) {
  return request({
    url: 'seal/apply/detail',
    method: 'post',
    data: qs.stringify(data)
  })
}

export function postUpdata(data) {
  return request({
    url: 'seal/apply/update',
    method: 'post',
    data: data,
    headers: {
      'Content-Type': 'application/json;charset=UTF-8'
    }
  })
}
