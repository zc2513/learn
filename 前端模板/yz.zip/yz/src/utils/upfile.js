/* eslint-disable no-unexpected-multiline */
/* eslint-disable no-trailing-spaces */
import {
  uploadFile
} from 'api/upload.js'
import defaultImg from '@/assets/No.jpg'
export default {
  createFile(imgid) {
    //   //本地图片上传
    document.querySelector('#file_id').setAttribute('data-id', imgid)
    document.querySelector('#file_id').click()
  },

  fileInputChange(fileId) {
    var imgid = document.querySelector('#file_id').getAttribute('data-id')
    var fileReader = new FileReader()
    // console.log(fileId.files[0],'fileId');
    fileReader.readAsDataURL(fileId.files[0])
    var param = new FormData()
    param.append('file', fileId.files[0])
    fileReader.onload = function() {
      var img = fileReader.result
      uploadFile(param).then((res) => {
        if (res.code === 200 && res.message === 'SUCCESS') {
          document.querySelector('#file_id').setAttribute('data-id', '')
          document.querySelector('#file_id').value = ''
          const imgEle = document.querySelector(imgid)
          imgEle.src = img
          var inputEle = imgEle.nextElementSibling
          if (res.data) {
            inputEle.value = res.data
          }
        }
      })

      //   $(imgid).next().val(res.newname);
      //             $(imgid).next().attr('path',res.real_path);//作为删除的本地路径标识
      //             $('#file_id').val('');
      //             successMsg('上传成功');
      //             $(imgid).parent().next('.imgBtnBox').find('.deleteImgBtn').addClass('redColor');
      //             // $('.imgBtnBox .deleteImgBtn');
      //         }else{
      //             successMsg('上传失败');
      //             $(imgid).parent().next('.imgBtnBox').find('.deleteImgBtn').removeClass('redColor');
      //         }
      //     },
      //     error: function (msg) {
      //         successMsg('请求失败');
      //         document.querySelector(imgid).src='';
      //         $(imgid).next().val('');
      //         $('#file_id').val('');
      //     }
      // });
    }
  },

  //  ajaxFile64(param,imgId) {//硬件base-64照片码上传---
  //     $.ajax({
  //         type: "post",
  //         url:"../../../common/attachmentUploadByBase64",
  //         data:{
  //             "picData":param,
  //             "picExt":'.jpg'
  //         },
  //         async:true,
  //         dataType:'json',
  //         success: function (res) {
  //             // if(res.code == 200){
  //             $(imgId).attr('src','../../../common/images?filename='+res.newname);
  //             $(imgId).next().val(res.newname);
  //             $(imgId).next().attr('path',res.real_path);//作为删除的本地路径标识
  //             successMsg('上传成功');
  //             // }
  //         },
  //         error: function (msg) {
  //             successMsg('请求失败');
  //             document.querySelector(imgId).src='';
  //             $(imgid).next().val('');
  //             $(imgid).parent().next('.imgBtnBox').find('.deleteImgBtn').removeClass('redColor');
  //         }
  //     });
  // },

  deleteImg(imgid) {
    // 删除img
    // $.ajax({
    //     type: "post",
    //     url:"../../../qyjbxx/deleteFileMsg",
    //     data:{realPath:$(imgid).next().attr('path')},
    //     success: function (res) {
    //         console.log(res);
    //         successMsg('删除成功');
    //     },
    //     error: function (msg) {
    //         successMsg('请求失败');
    //         document.querySelector(imgid).src='';
    //         $(imgid).next().val('');
    //     }
    // });
    const imgElement = document.querySelector(imgid)
    const imgData = imgElement.src
    const inputElement = imgElement.nextElementSibling
    const inputImgData = imgElement.nextElementSibling.value
    if (imgData && inputImgData) {
      imgElement.src = defaultImg
      inputElement.value = ''
      // successMsg('删除成功!');
      console.log('删除成功')
      // $(imgid).parent().next('.imgBtnBox').find('.deleteImgBtn').removeClass('redColor');
    } else {
      // warnningMsg("请上传图片");
      return false
    }
  }
  // //高拍仪拍照------------------------------------------- 弹窗 --------------------------------------------------------------
  // function zcGpypzQx(flag,param){//淡出
  //     if(flag == 1){
  //         CloseVideoAssist();
  //     }
  //     if(flag == 2){
  //         CloseVideoMain();
  //     }
  //     $(".zcPSBoxPerView").fadeOut();
  // };
  // function zcGpypzQxShow(flag) {//淡入
  //     $(".zcPSBoxPerView").fadeIn(500);
  //     Load();
  //     if(flag == 1){
  //         OpenVideoAssist();
  //     }
  //     if(flag == 2){
  //         OpenVideoMain();
  //     }
  // }
  // function zcMug(param,type) {//页面拍摄按钮事件 --公用
  //     var u = navigator.userAgent;
  //     if ( u.indexOf('Trident') == -1){
  //         warnningMsg("请使用ie浏览器进行拍照!");
  //         return false;
  //     }
  //     zcGpypzQxShow(type,param);
  //     $('#zcGpypzPz').attr('zcMugId',param);
  //     $('#zcGpypzPz').attr('zcMugType',type);

  // };

  // //弹窗拍照方法--处理公用
  // $("#zcGpypzPz").on('click',function(){
  //     var zcMugId = $('#zcGpypzPz').attr('zcMugId');
  //     Scan(zcMugId,function (param,imgId,zcMugType) {
  //         ajaxFile64(param,imgId);
  //         zcGpypzQx(zcMugType);
  //     })
  // });

  // //高拍仪-前摄像头 拍照函数------------------------------------------------------------------------------------------------
  // var DeviceAssist;//副头
  // var VideoAssist;//副头
  // var DeviceMain;//主头
  // var VideoMain;//主头
  // function plugin() { return document.getElementById('viewFront');}

  // function MainView() {return document.getElementById('viewFront');}

  // function addEvent(obj, name, func) {
  //     if (obj.attachEvent) {
  //         obj.attachEvent("on" + name, func);
  //     } else {
  //         obj.addEventListener(name, func, false);
  //     }
  // }
  // function CloseVideoAssist(){//关闭高拍仪 -- 平拍
  //     if (VideoAssist){
  //         plugin().Video_Release(VideoAssist);
  //         VideoAssist = null;
  //         plugin().View_SetText("", 0);
  //     }
  // }

  // function OpenVideoAssist() {//打开高拍仪 -- 平拍
  //     CloseVideoAssist();
  //     VideoAssist = plugin().Device_CreateVideo(DeviceAssist, -1, 1);
  //     if (VideoAssist) {
  //         plugin().View_SelectVideo(VideoAssist);
  //         plugin().View_SetText("视频打开中，请等待...", 0);
  //     }
  // }

  // function OpenVideoMain(){//打开高拍仪-下头
  //     CloseVideoMain();
  //     VideoMain = plugin().Device_CreateVideo(DeviceMain, 0, 1);
  //     if (VideoMain){
  //         plugin().View_SelectVideo(VideoMain);
  //         plugin().View_SetText("打开视频中，请等待...", 0);
  //     }
  // }
  // function CloseVideoMain(){//关闭-下头
  //     if (VideoMain){
  //         plugin().Video_Release(VideoMain);
  //         VideoMain = null;
  //         plugin().View_SetText("", 0);
  //     }
  // }

  // function Load() { //设备接入和丢失 //type设备类型， 1 表示视频设备， 2 表示音频设备 //idx设备索引 //dbt 1 表示设备到达， 2 表示设备丢失
  //     addEvent(plugin(), 'DevChange', function (type, idx, dbt) {
  //         if (1 == type){//视频设备
  //             if (1 == dbt){//设备到达
  //                 var deviceType = plugin().Global_GetEloamType(1, idx);
  //                 if (2 == deviceType || 3 == deviceType) {//辅摄像头
  //                     if (null == DeviceAssist) {
  //                         DeviceAssist = plugin().Global_CreateDevice(1, idx);
  //                     }
  //                 }
  //                 if(1 == deviceType){//主摄像头
  //                     if(null == DeviceMain){
  //                         DeviceMain = plugin().Global_CreateDevice(1, idx);
  //                     }
  //                 }
  //             }
  //             else if (2 == dbt){//设备丢失
  //                 if (DeviceAssist) {
  //                     if (plugin().Device_GetIndex(DeviceAssist) == idx) {
  //                         CloseVideoAssist();
  //                         plugin().Device_Release(DeviceAssist);
  //                         DeviceAssist = null;
  //                     }
  //                 }
  //             }
  //         }
  //     });

  //     var title = document.title;
  //     document.title = title + plugin().version;
  //     MainView().Global_SetWindowName("view");
  //     plugin().Global_InitDevs();
  // }

  // function Unload() {//高拍仪刷新页面调用的方法
  //     if (VideoAssist) {
  //         VideoAssist = null;
  //     }
  //     if (DeviceAssist) {
  //         DeviceAssist = null;
  //     }
  //     if(DeviceMain){
  //         DeviceMain = null;
  //     }
  //     if(VideoMain){
  //         VideoMain = null;
  //     }
  //     plugin().Global_DeinitDevs();
  // }

  // //拍照
  // function Scan(domId,callback,Type){

  //     var imgList2;
  //     if (VideoAssist) {
  //         imgList2 = plugin().Video_CreateImageList(VideoAssist, 0, 0);
  //     }
  //     if (VideoMain) {
  //         imgList2 = plugin().Video_CreateImageList(VideoMain, 0, 0);
  //     }
  //     if(imgList2) {
  //         var len = plugin().ImageList_GetCount(imgList2);
  //         for (var i = 0; i < len; i++) {
  //             var img = plugin().ImageList_GetImage(imgList2, i);
  //             var base64_data =plugin().Image_GetBase64(img, 2, 0);
  //             if(callback){
  //                 var zcMugType = $('#zcGpypzPz').attr('zcMugType');
  //                 callback(base64_data,domId,zcMugType);
  //             }
  //             plugin().Image_Release(img);
  //         }
  //         plugin().ImageList_Release(imgList2);
  //     }
  // }

  // function ReadIDCard(id,callback){
  //     var u = navigator.userAgent;
  //     if ( u.indexOf('Trident') == -1){
  //         warnningMsg("请使用ie浏览器进行读证!");
  //         return false;
  //     }
  //     var view = document.getElementById(id);
  //     view.Global_InitDevs();
  //     if(view.Global_InitIdCard()){
  //         var ret = view.Global_ReadIdCard();
  //         if(ret){
  //             var str = '';
  //             for(var i = 0; i < 16; i++){
  //                 str += view.Global_GetIdCardData(i + 1);
  //                 str += ";";
  //             }
  //             var image = view.Global_GetIdCardImage(1);//1表示头像， 2表示正面， 3表示反面 ...
  //             var strs = str.split(';');
  //             var personInfo = {
  //                 name:strs[0],
  //                 sex:strs[1],
  //                 nation:strs[2],
  //                 birthday:strs[3]+'-'+strs[4]+'-'+strs[5],
  //                 address:strs[6],
  //                 idCard:strs[7],
  //                 IssuingAuthority:strs[8],
  //                 usefulLife:strs[9]+'.'+strs[10]+'.'+strs[11]+'-'+strs[12]+'.'+strs[13]+'.'+strs[14],
  //             };
  //             var base64_data = view.Image_GetBase64(image, 2, 0);
  //             if(callback){
  //                 view.Global_DeinitDevs();
  //                 callback(personInfo,base64_data);
  //             }

  //         }else{
  //             warnningMsg("读取二代证失败！");
  //         }

  //         view.Global_DeinitIdCard();
  //     }else{
  //         warnningMsg("初始化二代证阅读器失败！");
  //     }
  // }
}
// document.querySelector('#file_id').change(function(){
//       var imgid = $('#file_id').data("id");
//       var fileReader=new FileReader();
//       fileReader.readAsDataURL(this.files[0]);
//       var param = new FormData();
//       param.append('file',this.files[0]);
//       fileReader.onload = function(){
//           var img = this.result;
//           // $.ajax({
//           //     type: "post",
//           //     url:"../../../common/attachmentUpload",
//           //     data:param,
//           //     processData: false,
//           //     contentType: false,
//           //     success: function (res) {
//           //         if(res.state == 'OK'){
//           //             $(imgid).attr('src',img);
//           //             $(imgid).next().val(res.newname);
//           //             $(imgid).next().attr('path',res.real_path);//作为删除的本地路径标识
//           //             $('#file_id').val('');
//           //             successMsg('上传成功');
//           //             $(imgid).parent().next('.imgBtnBox').find('.deleteImgBtn').addClass('redColor');
//           //             // $('.imgBtnBox .deleteImgBtn');
//           //         }else{
//           //             successMsg('上传失败');
//           //             $(imgid).parent().next('.imgBtnBox').find('.deleteImgBtn').removeClass('redColor');
//           //         }
//           //     },
//           //     error: function (msg) {
//           //         successMsg('请求失败');
//           //         document.querySelector(imgid).src='';
//           //         $(imgid).next().val('');
//           //         $('#file_id').val('');
//           //     }
//           // });
//       }
//   })
