/* eslint-disable eqeqeq */
import { isIDcardFun } from './tools.js'
export default {

  // 手机号验证
  phoneVerification(rule, value, callback) {
    const phoneReg = /^(13[0-9]|14[579]|15[0-3,5-9]|16[6]|17[0135678]|18[0-9]|19[89])\d{8}$/
    const regEnN = /[`~!@#$%^&*()_+""''<>?:'{},.\/'[\]]/im
    const regCnN = /[·！#￥（——）：；“”‘、，|《。》？、【】[\]]/im
    const startReg = /^1/
    const rtrim = /^\S*$/
    if (rtrim.test(value)) {
      if (startReg.exec(value)) {
        if (value.length < 11 || value.length > 11) {
          callback(new Error('长度' + value.length + '位,长度不对'))
        } else {
          setTimeout(() => {
            if (phoneReg.test(value)) {
              if (regEnN.test(value) || regCnN.test(value)) {
                callback(new Error('不能包含特殊字符'))
              } else {
                callback()
              }
            } else {
              callback(new Error('手机号格式不正确'))
            }
          }, 30)
        }
      } else {
        if (value.indexOf('-') !== -1) {
          const telReg = /([0-9]{3,4}-)?[0-9]{7,8}/
          if (telReg.test(value)) {
            const str1 = value.substr(0, value.indexOf('-'))
            const str2 = value.substr(value.indexOf('-') + 1, value.length)
            if (str1.length === 3 || str1.length === 4) {
              if (str1.length === 4) {
                if (str2.length == 7 || str2.length == 8) {
                  callback()
                } else {
                  callback(new Error('固话长度错误'))
                }
              } else if (str1.length === 3 && str2.length !== 8) {
                callback(new Error('固话长度错误'))
              } else {
                if (regEnN.test(value) || regCnN.test(value)) {
                  callback(new Error('不能包含特殊字符'))
                } else {
                  callback()
                }
              }
            } else {
              callback(new Error('区号长度错误'))
            }
          } else {
            callback(new Error('固话格式不正确'))
          }
        } else {
          callback(new Error('请在区号后面加-'))
        }
      }
    } else {
      callback(new Error('不能包含空格'))
    }
  },
  // 身份证验证
  IDcardVerification(rule, value, callback) {
    // const IDcardReg = /^[1-9]\d{5}(18|19|([23]\d))\d{2}((0[1-9])|(10|11|12))(([0-2][1-9])|10|20|30|31)\d{3}[0-9Xx]$/
    //   根据证件类型判断身份证号是否正确
    if (value) {
      if (isIDcardFun(value)) {
        callback()
      } else {
        callback(new Error('身份证号格式不正确'))
      }
    } else {
      callback(new Error('身份证号不能为空'))
    }
  },
  // 特殊字符验证
  tszfVerification(rule, value, callback) {
    const regEn = /[`~!@#$%^&*()_+<>?:'{},.\/'[\]]/im
    const regCn = /[·！#￥（——）：；“”‘、，|《。》？、【】[\]]/im
    if (regEn.test(value) || regCn.test(value)) {
      callback(new Error('不能包含特殊字符'))
    } else {
      callback()
    }
  },
  // 身份证姓名验证
  chineseVerificationName(rule, value, callback) {
    if (!value) {
      return callback(new Error('姓名不能为空'))
    } else {
      var chineseReg = /^[\u4e00-\u9fa5]{2,4}$/
      if (!chineseReg.test(value)) {
        callback(new Error('姓名必须为2到4位中文'))
      } else {
        callback()
      }
    }
  },
  /* 企业名称是否为中文 */
  chineseVerification(rule, value, callback) {
    if (!value) {
      return callback(new Error('不能为空'))
    } else {
      var chineseReg = /^[\u4e00-\u9fa5]{2,25}$/
      if (!chineseReg.test(value)) {
        callback(new Error('必须为中文'))
      } else {
        callback()
      }
    }
  },

  /* 不为空验证 */
  notNull(rule, value, callback) {
    if (!value) {
      return callback(new Error('证件号不能为空'))
    } else {
      callback()
    }
  },

  /* 数字字母中文 */
  commonlyVerification(rule, value, callback) {
    if (!value) {
      return callback(new Error('不能为空'))
    } else {
      var chineseReg = /^[\u4e00-\u9fa5a-zA-Z0-9]+$/
      if (!chineseReg.test(value)) {
        callback(new Error('必须为中、英文字母和数字'))
      } else {
        callback()
      }
    }
  },

  /* 统一社会信用代码 */
  unifyTheSocialCreditCodeVerification(rule, value, callback) {
    if (!value) {
      return callback(new Error('不能为空'))
    } else {
      // var chineseReg = /^(?![0-9]+$)(?![A-Z]+$)(?![a-z]+$)[0-9A-Za-z]{15,18}$/
      var chineseReg = /^[0-9A-Z]{15,18}$/
      if (!chineseReg.test(value)) {
        callback(new Error('15-18位数字或大写字母组合'))
      } else {
        callback()
      }
    }
  },

  /* 地址验证  ****—**-**              */
  checkRate(rule, value, callback) {
    // if (!value) {
    //   return callback(new Error('地址不能为空'))
    // }else{
    var chineseReg = /^[0-9]+.?[0-9]*$/
    if (chineseReg.test(value)) {
      callback(new Error('不能全为数字，请重输入！'))
    } else {
      callback()
    }
    // }
  },

  /* 纯数字 */
  pureNumbers(rule, value, callback) {
    if (value) {
      var chineseReg = /^[0-9]+$/
      if (!chineseReg.test(value)) {
        callback(new Error('必须数字'))
      } else {
        callback()
      }
    } else {
      callback()
    }
  },
  // 数字和小数点
  decimals(rule, value, callback) {
    if (value) {
      var numReg = /^\d+(\.\d+)?$/
      if (!numReg.test(value)) {
        callback(new Error('请输入正确的数字！'))
      } else {
        callback()
      }
    } else {
      callback()
    }
  },
  /* 车牌号验证 */
  isLicenseNo(rule, value, callback) {
    if (!value) {
      return callback(new Error('车牌号不能为空'))
    } else {
      var chineseReg = /(^[京津沪渝冀豫云辽黑湘皖鲁新苏浙赣鄂桂甘晋蒙陕吉闽贵粤青藏川宁琼使领A-Z]{1}[A-Z]{1}[A-Z0-9]{4,5}[A-Z0-9挂学警港澳]{1}$)/
      if (!chineseReg.test(value)) {
        callback(new Error('车牌号错误，请重新输入！'))
      } else {
        callback()
      }
    }
  },

  // 金额输入验证规则
  checkFloatNum(rule, value, callback) {
    if (!value) {
      return callback(new Error('金额不能为空'))
    } else {
      var chineseReg = /^(([1-9][0-9]*)|(([0]\.\d{1,2}|[1-9][0-9]*\.\d{1,2})))$/
      if (!chineseReg.test(value)) {
        callback(new Error('金额输入错误，请重新输入！'))
      } else {
        callback()
      }
    }
  },
  validateFloatNum(rule, value, callback) {
    var chineseReg = /^(([1-9][0-9]*)|(([0]\.\d{1,2}|[1-9][0-9]*\.\d{1,2})))$/
    if (value) {
      if (!chineseReg.test(value)) {
        return callback(new Error('必须为数字,小数最多两位！'))
      } else {
        callback()
      }
    } else {
      callback()
    }
  },
  // 典当数量正整数验证
  numZzsValidate(rule, value, callback) {
    const zZsReg = /^\+?[1-9][0-9]*$/
    if (zZsReg.test(value)) {
      callback()
    } else {
      callback(new Error('输入一个正整数'))
    }
  },
  /* 不能为中文验证 */
  noChinaVerification(rule, value, callback) {
    if (!value) {
      return callback(new Error('不能为空'))
    } else {
      var chineseReg = /[\u4e00-\u9fa5]/gm
      if (chineseReg.test(value)) {
        callback(new Error('不能为中文'))
      } else {
        callback()
      }
    }
  },
  // 英文姓名验证
  englishName(rule, value, callback) {
    if (!value) {
      return callback(new Error('不能为空'))
    } else {
      var englishNameReg = /^[A-Za-z ]+$/
      if (!englishNameReg.test(value)) {
        callback(new Error('只允许输入英文'))
      } else {
        callback()
      }
    }
  }
}
