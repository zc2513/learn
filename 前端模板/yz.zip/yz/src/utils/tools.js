/* eslint-disable prefer-const */
/* 时间格式转换 */
export function dateFormat(value, type) {
  // 接收的参数类型：'YYYY-MM-DD HH:MM:SS'   'yyyy/mm/dd'    '年'
  const dateType = type || 'YYYY-MM-DD HH:MM:SS'
  if (!value) return ''
  // value = Number(value);
  value = JSON.parse(value)
  const dateTime = new Date(value)
  let Y, M, D, Hours, Minutes, Seconds
  Y = dateTime.getFullYear()
  M = (dateTime.getMonth() + 1 < 10 ? '0' + (dateTime.getMonth() + 1) : dateTime.getMonth() + 1)
  D = dateTime.getDate() + 1 < 10 ? '0' + dateTime.getDate() : dateTime.getDate()
  Hours = (dateTime.getHours() < 10 ? '0' + dateTime.getHours() : dateTime.getHours())
  Minutes = (dateTime.getMinutes() < 10 ? '0' + dateTime.getMinutes() : dateTime.getMinutes())
  Seconds = (dateTime.getSeconds() < 10 ? '0' + dateTime.getSeconds() : dateTime.getSeconds())

  if (dateType && dateType !== '年' && dateType !== '修改') {
    const face = dateType.toLowerCase().trim()
    let str
    const zfc = face.slice(4, 5)
    if (face === 'yyyy' + zfc + 'mm' + zfc + 'dd') {
      str = Y + zfc + M + zfc + D
    } else if (face.indexOf('hh:mm:ss') !== -1) {
      str = Y + zfc + M + zfc + D + ' ' + Hours + ':' + Minutes + ':' + Seconds
    }
    return str
  }
  if (dateType && dateType === '修改') {
    return Y + '-' + M + '-' + D
  }
  if (dateType && dateType === '年') {
    return Y + '年' + M + '月' + D + ' ' + Hours + '时' + Minutes + '分' + Seconds + '秒'
  }
  return Y + '年' + M + '月' + D
}

export function isIDcardFun(sId) {
  const aCity = {
    11: '北京',
    12: '天津',
    13: '河北',
    14: '山西',
    15: '内蒙古',
    21: '辽宁',
    22: '吉林',
    23: '黑龙江',
    31: '上海',
    32: '江苏',
    33: '浙江',
    34: '安徽',
    35: '福建',
    36: '江西',
    37: '山东',
    41: '河南',
    42: '湖北',
    43: '湖南',
    44: '广东',
    45: '广西',
    46: '海南',
    50: '重庆',
    51: '四川',
    52: '贵州',
    53: '云南',
    54: '西藏',
    61: '陕西',
    62: '甘肃',
    63: '青海',
    64: '宁夏',
    65: '新疆',
    71: '台湾',
    81: '香港',
    82: '澳门',
    91: '国外'
  }
  var iSum = 0
  if (!/^\d{17}(\d|x)$/i.test(sId)) return false
  sId = sId.replace(/x$/i, 'a')
  if (aCity[parseInt(sId.substr(0, 2))] === null) return false
  var sBirthday = sId.substr(6, 4) + '-' + Number(sId.substr(10, 2)) + '-' + Number(sId.substr(12, 2))
  var d = new Date(sBirthday.replace(/-/g, '/'))
  if (sBirthday !== d.getFullYear() + '-' + (d.getMonth() + 1) + '-' + d.getDate()) {
    return false
  }
  for (var i = 17; i >= 0; i--) {
    iSum += (Math.pow(2, i) % 11) * parseInt(sId.charAt(17 - i), 11)
  }
  if (iSum % 11 !== 1) return false

  // return aCity[parseInt(sId.substr(0, 2))] + ',' + sBirthday + ',' + (sId.substr(16, 1) % 2 ? '男' : '女')
  return true
}

export function getBrowserInfo() {
  const ua = navigator.userAgent.toLocaleLowerCase()
  let browserType = ''
  let browserVersion = ''
  if (ua.match(/msie/) != null || ua.match(/trident/) != null) {
    browserType = 'IE'
    browserVersion = ua.match(/msie ([\d.]+)/) != null ? ua.match(/msie ([\d.]+)/)[1] : ua.match(/rv:([\d.]+)/)[1]
  }
  return browserType
}
