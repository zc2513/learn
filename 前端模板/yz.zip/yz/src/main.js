import Vue from 'vue'

import 'normalize.css/normalize.css'// A modern alternative to CSS resets

import ElementUI from 'element-ui'
import 'element-ui/lib/theme-chalk/index.css'
import locale from 'element-ui/lib/locale/lang/zh-CN' // lang i18n
import 'babel-polyfill' // 兼容 ie
import '@/styles/index.scss' // global css
import { Message } from 'element-ui'
import App from './App'
import router from './router'
import store from './store'

import '@/icons' // icon
import '@/permission' // permission control

Vue.use(ElementUI, { locale })
Vue.prototype.$message = Message

/* 公用的方法*/

import { dateFormat, getBrowserInfo } from '@/utils/tools.js'
Vue.prototype.$dateFormat = dateFormat
Vue.prototype.$getBrowserInfo = getBrowserInfo
Vue.config.productionTip = false

new Vue({
  el: '#app',
  store,
  router,
  render: h => h(App)
})
