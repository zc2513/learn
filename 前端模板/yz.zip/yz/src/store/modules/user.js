import { login, logout, getInfo } from '@/api/login'
import { getToken, setToken, removeToken } from '@/utils/auth'
// import { CLIENT_RENEG_LIMIT } from 'tls'

const user = {
  state: {
    token: getToken(),
    name: '',
    avatar: '',
    roles: [],
    users: '1',
    dicData: null,
    organizations: null
  },

  mutations: {
    SET_TOKEN: (state, token) => {
      state.token = token
    },
    SET_NAME: (state, name) => {
      state.name = name
    },
    SET_AVATAR: (state, avatar) => {
      state.avatar = avatar
    },
    SET_ROLES: (state, roles) => {
      state.roles = roles
    },
    SET_USERS: (state, users) => {
      state.users = users
    },
    DIC_DATA: (state, dictionarydata) => {
      state.dicData = dictionarydata
    },
    ZZJG_DATA: (state, organizations) => {
      state.organizations = organizations
    }
  },

  actions: {
    // 登录
    Login({ commit }, userInfo) {
      const username = userInfo.username.trim()
      return new Promise((resolve, reject) => {
        login(username, userInfo.password).then(response => {
          setToken(response.token)
          commit('SET_TOKEN', response.token)
          resolve()
        }).catch(error => {
          reject(error)
        })
      })
    },

    // 获取用户信息
    GetInfo({ commit, state }) {
      return new Promise((resolve, reject) => {
        getInfo(state.token).then(response => {
          const data = response.user
          commit('SET_USERS', JSON.stringify(data))
          // console.log(response.dictionaryRecord);
          var dictionarydata = response.dictionaryRecord
          // var dictionarydata = dictionarydata;
          var newList = {}
          if (dictionarydata) {
            for (var ele of dictionarydata) {
              if (ele.pid === '0') {
                var name = ele.name
                var dictId = ele.id
                var typeList = []
                for (var item of dictionarydata) {
                  if (dictId === item.pid) {
                    typeList.push({
                      name: item.name,
                      code: item.code
                    })
                  }
                }
                newList[name] = typeList
              }
            }
          }
          // localStorage.setItem('dicData', JSON.stringify(newList))
          commit('DIC_DATA', JSON.stringify(newList))

          // var organizations = response.organizations
          // eslint-disable-next-line no-unused-vars
          var organizationsData = response.organizations
          var areaData = []
          organizationsData.forEach(item => {
            if (item.pid === data.pid) {
              const twoSdt = []
              organizationsData.forEach(ele => {
                if (ele.pid === item.organizationId) {
                  const threeSdt = []
                  organizationsData.forEach(el => {
                    if (el.pid === ele.organizationId) {
                      const fourSdt = []
                      organizationsData.forEach(val => {
                        if (val.pid === el.organizationId) {
                          const fiveSdt = []
                          organizationsData.forEach(v => {
                            if (v.pid === val.organizationId) {
                              fiveSdt.push({
                                value: v.organizationId + '-' + v.brevitycode + ',' + v.fullcode,
                                label: v.name
                                // children: fiveSdt || ''
                              })
                            }
                          })
                          fourSdt.push({
                            value: val.organizationId + '-' + val.brevitycode + ',' + val.fullcode,
                            label: val.name,
                            children: fiveSdt.length > 0 ? fiveSdt : null
                          })
                        }
                      })
                      threeSdt.push({
                        value: el.organizationId + '-' + el.brevitycode + ',' + el.fullcode,
                        label: el.name,
                        children: fourSdt.length > 0 ? fourSdt : null
                      })
                    }
                  })
                  twoSdt.push({
                    value: ele.organizationId + '-' + ele.brevitycode + ',' + ele.fullcode,
                    label: ele.name,
                    children: threeSdt.length > 0 ? threeSdt : null
                  })
                }
              })
              areaData.push({
                value: item.organizationId + '-' + item.brevitycode + ',' + item.fullcode,
                label: item.name,
                children: twoSdt.length > 0 ? twoSdt : null
              })
            }
          })
          var organizations = areaData
          commit('ZZJG_DATA', organizations)
          if (data.roles && data.roles.length > 0) { // 验证返回的roles是否是一个非空数组
            commit('SET_ROLES', data.roles)
          } else {
            reject('getInfo: roles must be a non-null array !')
          }
          commit('SET_NAME', data.role_name)
          commit('SET_AVATAR', data.avatar)
          resolve(response)
        }).catch(error => {
          reject(error)
        })
      })
    },

    // 登出
    LogOut({ commit, state }) {
      return new Promise((resolve, reject) => {
        logout(state.token).then(() => {
          commit('SET_TOKEN', '')
          commit('SET_ROLES', [])
          removeToken()
          resolve()
        }).catch(error => {
          reject(error)
        })
      })
    },

    // 前端 登出
    FedLogOut({ commit }) {
      return new Promise(resolve => {
        commit('SET_TOKEN', '')
        removeToken()
        resolve()
      })
    }
  }
}

export default user
