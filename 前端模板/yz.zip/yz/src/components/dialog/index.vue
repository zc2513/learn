<template>
  <el-dialog
    :title="addData.title"
    :visible.sync="addData.state"
    :width="addData.width ? addData.width:'60%'"
    :before-close="handleClose">
    <slot name="content"></slot>
    <slot name='proviewImg'></slot>
    <!-- <span slot="footer" class="dialog-footer add-btn-box">
      <el-button type="small" class="cancel-cls" @click="abolish">取 消</el-button>
      <el-button type="small" >确 定</el-button>
    </span> -->
  </el-dialog>
</template>

<script>
  export default {
    props:['addData'], 
    methods: {
      handleClose(done) {
        if(this.addData.title == '详情' || this.addData.title == '账户信息'){
          done()
        }else{
          this.$confirm('确认关闭？')
            .then(_ => {
              this.$emit('cancelEven',false)
              done();
            })
            .catch(_ => {});
        }
      },
      abolish(){
        this.$emit('cancelEven',false)
      },
    }
  }
</script>

<style lang="scss" scoped>

</style>
<style>
.el-dialog__footer{ /* 弹窗样式 */
  padding: 0 20px 16px;
}
.el-dialog__body{
  padding: 10px;
}
</style>