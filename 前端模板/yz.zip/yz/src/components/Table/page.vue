<template>
  <div>
    <div class="block">
      <el-pagination
        @current-change="handleCurrentChange"
        :current-page.sync="currentPage"
        :page-size="pageSize"
        background=""
        layout="total , prev, pager, next, jumper"
        :total="totalSizeNum"
      ></el-pagination> 
    </div>
  </div>
</template>

<script>
/* 
changPageSize : {  //父组件参数格式
  type:"false" //---是否跳转到第一页 true/false
  page:10,  //---每页数据个数 与请求个数对应
  total:88  //---数据总个数
}
 */
export default {
  data() {
    return {
      currentPage: 1,
      totalSizeNum: 0,
      pageSize: 10,//---每页数据个数 默认10
    };
  },
  props: ['changPageSize'], 
  watch: { 
    changPageSize: {//对象深度监测
      handler(val, oldVal) {
        this.totalSizeNum = val.total;
        if(val.type){
          this.currentPage = 1;
        }
        if(val.page){
          this.pageSize = val.page
        }
        if(val.nowPage){//删除数据 页面停留配置
          this.currentPage = val.nowPage
        }
      },
      deep: true
    }
  },
  created() {
    // console.log(this.changPageSize.type)
    this.totalSizeNum=this.changPageSize.total
  },
  methods: {
    handleCurrentChange(val) {
      this.$emit("pagesend", this.currentPage);
    }
  }
};
</script>

<style scoped>
.block {
  text-align: right;
}
</style>