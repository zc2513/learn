<template>
<!-- 图片放大视图 -->
  <div>
    <el-dialog :visible.sync="enlargeDialog" append-to-body  class="enlargeDialog">
      <img :src="enlargeimgUrl">
    </el-dialog>
  </div>
</template>

<script>
  export default {
    props:['imgObj'],
    data(){
      return{
        enlargeDialog:false,
        enlargeimgUrl:null,
        baseUri:'/file/preview?filename='
      }
    },
    watch: {
      imgObj(val,old){
        if(val.img){
          this.enlargeimgUrl=this.baseUri+val.img;
          this.enlargeDialog = true;
        }
      }
    },
  }
</script>

<style lang="scss" scoped>
.enlargeDialog{
  text-align: center;
  img{
    max-width: 100%;
  }
}
</style>