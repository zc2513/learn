/* eslint-disable no-undef */
import Vue from 'vue'
import Router from 'vue-router'
Vue.use(Router)

/* Layout */
import Layout from '../views/layout/Layout'

/**
* hidden: true                   if `hidden:true` will not show in the sidebar(default is false)
* alwaysShow: true               if set true, will always show the root menu, whatever its child routes length
*                                if not set alwaysShow, only more than one route under the children
*                                it will becomes nested mode, otherwise not show the root menu
* redirect: noredirect           if `redirect:noredirect` will no redirct in the breadcrumb
* name:'router-name'             the name is used by <keep-alive> (must set!!!)
* meta : {
    title: 'title'               the name show in submenu and breadcrumb (recommend set)
    icon: 'svg-name'             the icon show in the sidebar,
  }
**/
export const constantRouterMap = [
  { path: '/login', component: () => import('@/views/login/index'), hidden: true },
  {
    path: '',
    component: Layout,
    redirect: 'home',
    meta: {
      title: '首页',
      icon: 'people'
    },
    children: [
      {
        path: 'home',
        component: () => import('@/views/homePage/index'),
        name: 'home',
        // hidden: true,
        meta: { title: '首页', icon: 'shouye' }
      }
    ]
  },
  // {
  //   path: '/useSealInquire',
  //   component: Layout,
  //   redirect: 'noredirect',
  //   name: 'useSealInquire',
  //   meta: {
  //     title: '用印查询',
  //     icon: 'people'
  //   },
  //   children: [
  //     {
  //       path: 'monitoring',
  //       component: () => import('@/views/useSealInquire/monitoring/index'),
  //       name: 'monitoring',
  //       meta: {
  //         title: '监控模式'
  //       }
  //     },
  //     {
  //       path: 'accredit',
  //       component: () => import('@/views/useSealInquire/accredit/index'),
  //       name: 'accredit',
  //       meta: {
  //         title: '授权模式'
  //       }
  //     }
  //   ]
  // },
  // {
  //   path: '/examinelog',
  //   component: Layout,
  //   redirect: 'noredirect',
  //   name: 'examinelog',
  //   meta: {
  //     title: '审批记录',
  //     icon: 'people'
  //   },
  //   children: [
  //     {
  //       path: 'myaudit',
  //       component: () => import('@/views/examinelog/myaudit/index'),
  //       name: 'myaudit',
  //       meta: {
  //         title: '我的申请'
  //       }
  //     },
  //     {
  //       path: 'pass',
  //       component: () => import('@/views/examinelog/pass/index'),
  //       name: 'pass',
  //       meta: {
  //         title: '我的审批'
  //       }
  //     }
  //   ]
  // },
  // {
  // path: '/sealManage',
  // component: Layout,
  // redirect: 'noredirect',
  // name: 'sealManage',
  // meta: {
  //   title: '印章管理',
  //   icon: 'people'
  // },
  // children: [
  //   {
  //     path: 'sealList',
  //     component: () => import('@/views/sealManage/sealList/index'),
  //     name: 'sealList',
  //     meta: {
  //       title: '云章列表'
  //     }
  //   },
  //   {
  //     path: 'qyList',
  //     component: () => import('@/views/sealManage/qylist/index'),
  //     name: 'qyList',
  //     meta: {
  //       title: '云章列表（管理端）'
  //     }
  //   },
  //   {
  //     path: 'ceshiye',
  //     component: () => import('@/views/xitongguanli/Organization-1.vue'),
  //     name: 'ceshiye',
  //     meta: {
  //       title: '部门管理-test'
  //     }
  //   }
  // {
  //   path: 'installSeal',
  //   component: () => import('@/views/sealManage/installSeal/index'),
  //   name: 'installSeal',
  //   meta: {
  //     title: '安装印章'
  //   }
  // },
  // {
  //   path: 'enterprise',
  //   component: () => import('@/views/sealManage/enterprise/index'),
  //   name: 'enterprise',
  //   meta: {
  //     title: '企业管理'
  //   }
  // }
  // ]
  // },
  { path: '*', component: () => import('@/views/404') }
]
export default new Router({
  // mode: 'history', //后端支持可开
  scrollBehavior: () => ({ y: 0 }),
  routes: constantRouterMap
})

// export const asyncRouterMap = [{ path: '*', redirect: '/404', hidden: true }]
